package com.CucumberCraft.stepDefinitions;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.CucumberCraft.pageObjects.Applyphase;
import com.CucumberCraft.pageObjects.EposAddProspectPage;
import com.CucumberCraft.pageObjects.LoginEPOSAppPage;
import com.CucumberCraft.supportLibraries.DriverManager;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.AppiumDriver;

public class Apply5 extends MasterStepDefs {
	AppiumDriver driver = DriverManager.getDriver();
	
	@Given("^I am in Supporting documents task card$")
	public void i_am_in_Supporting_documents_task_card() throws Throwable {
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.context("NATIVE");
		if (driver.findElementByXPath("//UIAStaticText[contains(@label,'Supporting Documents')]").isDisplayed()) {
			ReportGeneration("Navigated to supporting documents taskcard", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Navigation to supporting documents taskcard failed", "Fail", "Yes", driver);
		}

	}

	@Then("^I will capture  docs for \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_will_capture_docs_for_and(String doc1, String doc2) throws Throwable {
		driver.context("NATIVE");

		Applyselectdocs(doc1, driver);

		Applyselectdocs(doc2, driver);
		if (driver.findElementByXPath(Applyphase.btn_Proceed).isEnabled()) {
			ReportGeneration("Documents uploaded in Apply page", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Document upload failed in Apply page", "Fail", "Yes", driver);
		}

	}
	
	@Then("^I will capture  docs for \"([^\"]*)\"$")
	public void i_will_capture_docs_for(String docname) throws Throwable {
		driver.context("NATIVE");

		Applyselectdocs(docname, driver);

	   
	}

	
	

	@Then("^I will capture  docs for \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_will_capture_docs_for_and(String doc1, String doc2, String doc3, String doc4, String doc5)
			throws Throwable {
		driver.context("NATIVE");
		Applyselectdocs(doc1, driver);

		Applyselectdocs(doc2, driver);

		Applyselectdocs(doc3, driver);

		if (driver.findElementByXPath(Applyphase.btn_Proceed).isEnabled()) {
			ReportGeneration("Documents uploaded in Apply page", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Document upload failed in Apply page", "Fail", "Yes", driver);
		}

		// Applyselectdocs(doc4,driver);

		// Applyselectdocs(doc5,driver);

	}

	@When("^I click on proceed in E-Disclosure$")
	public void i_click_on_proceed_in_E_Disclosure() throws Throwable {
		if (driver
				.findElementByXPath("//UIAButton[contains(@label,'PROCEED')] | //UIAButton[contains(@label,'Proceed')]")
				.isDisplayed()) {
			ReportGeneration("Documents uploaded in supporting documents  taskcard", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Documents upload failed in taskcard", "Fail", "Yes", driver);
		}

		driver.findElementByXPath("//UIAButton[contains(@label,'PROCEED')] | //UIAButton[contains(@label,'Proceed')]")
				.click();

	}

	@Then("^I will capture user Identity card/Passport$")
	public void i_will_capture_user_Identity_card_Passport() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@Then("^I will select payment mode as \"([^\"]*)\"$")
	public void i_will_select_payment_mode_as(String pymt_mode) throws Throwable {
		WebDriverWait wait=new WebDriverWait(driver, 30);
		Waitforloading(Applyphase.ldg_Gen_PDF, driver);
		driver.context("WEBVIEW");
		SetPageContext("WEBVIEW_2", driver);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Payment Mode']")));
		Applypaymentmode(pymt_mode, driver);

	}

	@Then("^I will select \"([^\"]*)\" for Third Party payment$")
	public void i_will_select_for_Third_Party_payment(String type) throws Throwable {
		Applythirdpartypaymentmode(type, driver);

	}

	@Then("^I will select Payment Currency as \"([^\"]*)\"$")
	public void i_will_select_Payment_Currency_as(String currency) throws Throwable {
		Applythirdpartypaymentcurrency(currency, driver);
	}

	@Then("^I will select Payment Method as \"([^\"]*)\"$")
	public void i_will_select_Payment_Method_as(String method) throws Throwable {
		Applythirdpartypaymentmethod(method, driver);
	}
	
	@Then("^I will be verify the Subsequent Payment method is defaulted to \"([^\"]*)\"$")
	public void i_will_be_verify_the_Subsequent_Payment_method_is_defaulted_to(String subpymtval) throws Throwable {
	   WebElement subpayment=driver.findElementByXPath(Applyphase.txt_DirectDebit_Subpayment);
	   String subpaymentvalue=subpayment.getText();
	   	   
	   if (subpaymentvalue.equalsIgnoreCase(subpymtval)) {
			ReportGeneration("Subsequent payment is defaulted correctly", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Subsequent payment is defaulted in-correctly", "Fail", "Yes", driver);
		}
	   
	   
	   
	}

	@Then("^I will click on DDA Section$")
	public void i_will_click_on_DDA_Section() throws Throwable {
	   driver.findElementByXPath(Applyphase.btn_DDA).click();
	}

	@Then("^I will select Bank Name as \"([^\"]*)\"$")
	public void i_will_select_Bank_Name_as(String bankname) throws Throwable {
		driver.context("WEBVIEW");
		SetPageContext("WEBVIEW_2",driver);
		SetPageContext("WEBVIEW_3",driver);
		WebDriverWait wait=new WebDriverWait(driver,30);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Applyphase.txt_DirectDebit_Bankname)));
		Directdebitbankname(bankname,driver);
	}

	@Then("^I will enter Branch Name as \"([^\"]*)\"$")
	public void i_will_enter_Branch_Name_as(String branchname) throws Throwable {
		driver.findElementByXPath(Applyphase.txt_DirectDebit_Branchname).sendKeys(branchname);
	}

	@Then("^I will enter Account No as \"([^\"]*)\"and \"([^\"]*)\"$")
	public void i_will_enter_Account_No_as_and(String accbr, String accno) throws Throwable {
		DirectdebitAccNo(accbr,accno,driver);
	}

	
	
	
	@Then("^I will enter Account No as \"([^\"]*)\"$")
	public void i_will_enter_Account_No_as(String arg1) throws Throwable {
		
	}

	@Then("^I will enter Name as \"([^\"]*)\"$")
	public void i_will_enter_Name_as(String accname) throws Throwable {
		driver.findElementByXPath(Applyphase.txt_DirectDebit_Accname).sendKeys(accname);
	}

	@Then("^I will select ID Type as \"([^\"]*)\"$")
	public void i_will_select_ID_Type_as(String IDtype) throws Throwable {
		DirectdebitAccIDType(IDtype,driver);
	}

	@Then("^I will enter ID as \"([^\"]*)\"$")
	public void i_will_enter_ID_as(String accid) throws Throwable {
		driver.findElementByXPath(Applyphase.txt_DirectDebit_AccID).sendKeys(accid);
	}

	@Then("^I will enter contact no as \"([^\"]*)\"$")
	public void i_will_enter_contact_no_as(String contactno) throws Throwable {
	//	driver.findElementByXPath(Applyphase.txt_DirectDebit_AccCtno).click();
	//	driver.findElementByXPath(Applyphase.txt_DirectDebit_AccCtno).sendKeys(contactno);
		
		Map<String, Object> params9 = new HashMap<>();
		params9.put("location", "749,1269");
		Object result9 = driver.executeScript("mobile:touch:tap", params9);
		driver.getKeyboard().sendKeys(contactno);
		HideKeyboard(driver);
	}

	@Then("^I will select Account holder under policy as \"([^\"]*)\"$")
	public void i_will_select_Account_holder_under_policy_as(String policyqn) throws Throwable {
		DirectdebitAccholderqn(policyqn,driver);
	}

	@Then("^I will select \"([^\"]*)\" for Joint Account holder question$")
	public void i_will_select_for_Joint_Account_holder_question(String option) throws Throwable {
		DirectdebitJntholderqn(option,driver);
	}

	@Then("^I will click on Save$")
	public void i_will_click_on_Save() throws Throwable {
		driver.findElementByXPath(Applyphase.btn_Save).click();
	  
	}

	@Then("^I will click on Proceed in Payment page$")
	public void i_will_click_on_Proceed_in_Payment_page() throws Throwable {
		driver.context("NATIVE");
		driver.findElementByXPath(Applyphase.btn_Proceed).click();
	}


	
	
	

	@Then("^I will select Subsequent Payment as \"([^\"]*)\"$")
	public void i_will_select_Subsequent_Payment_as(String arg1) throws Throwable {

		driver.findElementByXPath(Applyphase.btn_Payment).click();
		driver.findElementByXPath("//*[@class='selectize-input focus']").click();
		WebElement option = driver.findElementByXPath(Applyphase.btn_Direct_Bill);
		option.click();
		driver.context("NATIVE_APP");
		// driver.findElementByXPath("//UIAButton[contains(@label,'PROCEED')] |
		// //UIAButton[contains(@label,'Proceed')]").click();

	}

	@Then("^i will click on OK in the popup$")
	public void i_will_click_on_OK_in_the_popup() throws Throwable {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.context("NATIVE");
		driver.findElementByXPath(Applyphase.btn_OK).click();

	}
	
	@Given("^I will select \"([^\"]*)\" for Left/Right question$")
	public void i_will_select_for_Left_Right_question(String value) throws Throwable {
		applyHanded(value,driver);
	}

	@Given("^I will verify the Error message \"([^\"]*)\" is displayed in Insured section$")
	public void i_will_verify_the_Error_message_is_displayed_in_Insured_section(String arg1) throws Throwable {
		if(driver.findElementByXPath(Applyphase.lbl_Error_Handed).isDisplayed()){
			ReportGeneration("Error message for field left blank validated successfully", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Error message for field left blank validation failed", "Fail", "Yes", driver);
		}
	 
	}
	
	
	@Then("^I will enter witness as \"([^\"]*)\" and click on Next button$")
	public void i_will_enter_witness_as_and_click_on_Next_button(String witnessname) throws Throwable {
		driver.context("NATIVE_APP");
		driver.findElementByXPath(Applyphase.txt_Witnessname).sendKeys(witnessname);
		driver.findElementByXPath(Applyphase.btn_Next).click();

	}

	@Then("^I will be navigated to generated pdf$")
	public void i_will_be_navigated_to_generated_pdf() throws Throwable {

		Waitforloading(Applyphase.ldg_Gen_PDF, driver);

	}
	
	
	@Then("^I will sign all the signature fields in all the pages in PAP$")
	public void i_will_sign_all_the_signature_fields_in_all_the_pages_in_PAP() throws Throwable {
		WebDriverWait wait=new WebDriverWait(driver,6);
		driver.context("NATIVE_APP");
	try{
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Applyphase.lbl_PDF_Apply)));
		while (driver.findElementByXPath(Applyphase.lbl_PDF_Apply).isDisplayed()) {
			log.info("Trying to sign across PDFs");
			SignAcrossPDFApply(driver);
		}
	}catch(Exception ex){}
	try{
		if(driver.findElementByXPath(Applyphase.btn_SubmitApplication).isDisplayed()){
			SignAcrossDeclrPDF(driver);
		}
	}catch(Exception ex){}
		
	
	}

	
	
	
	@Then("^I will sign all the signature fields in all the pages in ManuGuard$")
	public void i_will_sign_all_the_signature_fields_in_all_the_pages_in_ManuGuard() throws Throwable {
		WebDriverWait wait=new WebDriverWait(driver,6);
		driver.context("NATIVE_APP");
	try{
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Applyphase.lbl_PDF_Apply)));
		while (driver.findElementByXPath(Applyphase.lbl_PDF_Apply).isDisplayed()) {
			log.info("Trying to sign across PDFs");
			SignAcrossPDFApply(driver);
		}
	}catch(Exception ex){}
	try{
		if(driver.findElementByXPath(Applyphase.btn_SubmitApplication).isDisplayed()){
			SignAcrossDeclrPDF(driver);
		}
	}catch(Exception ex){}
	/*
		if (driver.findElementByXPath(Applyphase.lbl_PDF).isDisplayed()) {
			
			ReportGeneration("Failed to sign all pages of PDF", "Fail", "Yes", driver);
		} else {
			ReportGeneration("Signed all pages in PDF", "Pass", "Yes", driver);
		}
	*/	
	}

	
	

	@Given("^I will sign all the signature fields in all the pages in apply phase$")
	public void i_will_sign_all_the_signature_fields_in_all_the_pages_in_apply_phase() throws Throwable {
		driver.context("NATIVE_APP");
		try {
			while (driver.findElementByXPath(Applyphase.btn_Next).isDisplayed()) {

				SignAcrossPDF(driver);
			}
		} catch (Exception ex) {
		}
	}

	@Then("^I will sign all the signature fields in all the pages$")
	public void i_will_sign_all_the_signature_fields_in_all_the_pages() throws Throwable {
		WebDriverWait wait=new WebDriverWait(driver,6);
		driver.context("NATIVE_APP");
	try{
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Applyphase.lbl_PDF_Apply)));
		while (driver.findElementByXPath(Applyphase.lbl_PDF_Apply).isDisplayed()) {
			log.info("Trying to sign across PDFs");
			SignAcrossPDFApply(driver);
		}
	}catch(Exception ex){}
		if (driver.findElementByXPath(Applyphase.lbl_MCV).isDisplayed()) {
			ReportGeneration("Signed all pages in PDF", "Pass", "Yes", driver);
			
		} else {
			ReportGeneration("Failed to sign all pages of PDF", "Fail", "Yes", driver);
		}
	}

	@Then("^I will be navigated to Declaration form of Insirance application by non HK residents$")
	public void i_will_be_navigated_to_Declaration_form_of_Insirance_application_by_non_HK_residents()
			throws Throwable {

	}

	@Then("^I will select \"([^\"]*)\" for first question$")
	public void i_will_select_for_first_question(String option) throws Throwable {
		MCVfield(option, driver);
	}

	@Then("^I will select \"([^\"]*)\" in MCV page$")
	public void i_will_select_in_MCV_page(String option) throws Throwable {
		MCVfield(option, driver);
	}

	@Then("^I will enter \"([^\"]*)\" in MCV reference number$")
	public void i_will_enter_in_MCV_reference_number(String option) throws Throwable {
		MCVfield("Text", option, driver);
	}

	@And("^I will click on Next in apply phase$")
	public void i_will_click_on_Next_in_apply_phase() throws Throwable {
		driver.findElementByXPath(Applyphase.btn_Next).click();
	}

	@Then("^click on next in declaration page$")
	public void click_on_next_in_declaration_page() throws Throwable {

	}

	@Then("^I will sign in Declaration form of Insirance application by non HK residents page$")
	public void i_will_sign_in_Declaration_form_of_Insirance_application_by_non_HK_residents_page() throws Throwable {
		
		SignAcrossDeclrPDF(driver);
	/*	
		if (driver.findElementByXPath(Applyphase.lbl_PDF).isDisplayed()) {
			ReportGeneration("Failed to sign Declaration form PDF", "Fail", "Yes", driver);
		} else {
			ReportGeneration("Signed all pages in Declaration form PDF", "Pass", "Yes", driver);
		}
	*/
	}

	@Then("^I will click on SUBMIT APPLICATION$")
	public void i_will_click_on_SUBMIT_APPLICATION() throws Throwable {
		/*
		 * driver.context("NATIVE_APP");
		 * driver.findElementByXPath(Applyphase.btn_SubmitApplication).click();
		 * driver.findElementByXPath("//*[@label=\"Ok\"]").click(); textClick(
		 * "Tap to sign here",5,driver);
		 * 
		 * drawLetter("P", driver); driver.context("NATIVE");
		 * driver.findElementByXPath(EposAddProspectPage.btn_confirm).click();
		 * driver.findElementByXPath(Applyphase.btn_SubmitApplication).click();
		 * driver.findElementByXPath("//*[@label=\"Ok\"]").click(); textClick(
		 * "Tap to sign here",5,driver);
		 * 
		 * drawLetter("P", driver); driver.context("NATIVE");
		 * driver.findElementByXPath(EposAddProspectPage.btn_confirm).click();
		 * driver.findElementByXPath(Applyphase.btn_SubmitApplication).click();
		 * driver.findElementByXPath("//*[@label=\"Ok\"]").click(); textClick(
		 * "Tap to sign here",5,driver);
		 * 
		 * drawLetter("P", driver); driver.context("NATIVE");
		 * driver.findElementByXPath(EposAddProspectPage.btn_confirm).click();
		 * driver.findElementByXPath(Applyphase.btn_SubmitApplication).click();
		 */
		SignAcrossDeclrPDF(driver);
		Waitforloading(Applyphase.ele_Ldg_PDF, driver);

	}

	@Then("^click on Confirm in the popup$")
	public void click_on_Confirm_in_the_popup() throws Throwable {
		try {
			driver.findElementByXPath(Applyphase.btn_Confirm).click();
		} catch (Exception ex) {
		}
		Waitforloading(Applyphase.ele_Ldg_PDF, driver);

	}

	@Then("^I will be navigated to Application Overview$")
	public void i_will_be_navigated_to_Application_Overview() throws Throwable {
		driver.context("WEBVIEW");
		SetPageContext("WEBVIEW_2",driver);
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath(Applyphase.lbl_Appl_Overview)));
		if (driver.findElementByXPath(Applyphase.lbl_Appl_Overview).isDisplayed()) {
			ReportGeneration("Navigated to Application Overview Page", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Navigation to Application Overview Page failed", "Fail", "Yes", driver);
		}

	}

	@Then("^Click on Advisors statement task card$")
	public void click_on_Advisors_statement_task_card() throws Throwable {
		SetPageContext("WEBVIEW_2", driver);
		//WaitForObject("Submitted", driver);
		WaitForObject(Applyphase.Ele_Submitted, driver);
		driver.findElementByXPath("//*[text()=\"Advisor's Statement\"]").click();

	}

	@Then("^I will enter passcode as \"([^\"]*)\"$")
	public void i_will_enter_passcode_as(String arg1) throws Throwable {
		driver.context("WEBVIEW");
		SetPageContext("WEBVIEW_2",driver);
		SetPageContext("WEBVIEW_3",driver);
		WebDriverWait wait=new WebDriverWait(driver,60);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Applyphase.lbl_Password)));
		driver.context("NATIVE");
		Passwordentry(driver);

	}

	@Then("^I will select witness question as \"([^\"]*)\"$")
	public void i_will_select_witness_question_as(String arg1) throws Throwable {
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		driver.context("WEBVIEW");
		SetPageContext("WEBVIEW_2", driver);
		ApplyPhaseQns("Wit_Qn", arg1, driver);

	}

	@Then("^I will select Any factor question as \"([^\"]*)\"$")
	public void i_will_select_Any_factor_question_as(String arg1) throws Throwable {

		ApplyPhaseQns("Fac_Qn", arg1, driver);

	}

	@Then("^I will enter receipt no as \"([^\"]*)\"$")
	public void i_will_enter_receipt_no_as(String arg1) throws Throwable {
		driver.findElementByXPath(Applyphase.txt_Rcpt_No).sendKeys(arg1);

	}

	@Then("^I will enter Advisor code as \"([^\"]*)\"$")
	public void i_will_enter_Advisor_code_as(String arg1) throws Throwable {
		driver.findElementByXPath(Applyphase.txt_Adv_code).sendKeys(arg1);

	}

	@Then("^click on CONFIRM$")
	public void click_on_CONFIRM() throws Throwable {
		WebDriverWait wait=new WebDriverWait(driver, 60);
		driver.context("NATIVE_APP");
		driver.findElementByXPath(Applyphase.btn_Confirm).click();
		Waitforloading(Applyphase.ldg_Gen_Results, driver);
		driver.context("WEBVIEW");
		SetPageContext("WEBVIEW_2",driver);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Applyphase.lbl_Status)));
		if(driver.findElementByXPath(Applyphase.lbl_Status).isDisplayed()){
			ReportGeneration("Completed user journey successfully", "Pass", "Yes", driver);
		}else{
			ReportGeneration("User journey faild to complete", "Fail", "Yes", driver);
		}

	}

}
