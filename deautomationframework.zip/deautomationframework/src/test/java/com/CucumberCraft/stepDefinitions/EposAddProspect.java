package com.CucumberCraft.stepDefinitions;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.CucumberCraft.pageObjects.Applyphase;
import com.CucumberCraft.pageObjects.EposAddProspectPage;
import com.CucumberCraft.supportLibraries.DriverManager;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.AppiumDriver;

public class EposAddProspect extends MasterStepDefs {
	
	public boolean resultBool;
	@SuppressWarnings("rawtypes")
	AppiumDriver driver = DriverManager.getDriver();
	WebDriverWait wait=new WebDriverWait(driver,60);
	static Logger log;

	static {
		log = Logger.getLogger(EPoslogin.class);
	}

	@Given("^I am in home Screen$")
	public void i_am_in_home_Screen() throws Throwable {
		//Adding code for generating random names for EPOS products
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		String surname=randomString(4);
		String middlename=randomString(3);
		String capSurname=surname.substring(0, 1).toUpperCase()+surname.substring(1, 4);
		String capMiddlename=middlename.substring(0, 1).toUpperCase()+middlename.substring(1, 3);		
		String name=capSurname+" "+capMiddlename;
		writePropertiesFile("surname", surname);
		writePropertiesFile("middlename", middlename);
		writePropertiesFile("name", name);

		log.info("Started");
		driver.context("NATIVE_APP");

	}

	@When("^I will click Add Prospect button$")
	public void i_will_click_Add_Prospect_button() throws Throwable {
			
		driver.findElementByXPath(EposAddProspectPage.btn_addprospect).click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//UIAStaticText[contains(@label,'PICS - Personal Information Collection Statement')]")));
		if (driver.findElementByXPath("//UIAStaticText[contains(@label,'PICS - Personal Information Collection Statement')]").isDisplayed()){
			ReportGeneration("Navigated to Prospect screen", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Navigation to Prospect screen failed", "Fail", "Yes", driver);
		}

	}

	@When("^I will enter Surname as \"([^\"]*)\"$")
	public void i_will_enter_Surname_as(String surname) throws Throwable {

		driver.context("WEBVIEW");

		
		driver.findElementByXPath(EposAddProspectPage.txt_surname).sendKeys(surname);

		// Hide the keyboard
		// HideKeyboard(driver);
	}

	@When("^I enter  Middle Name as \"([^\"]*)\"$")
	public void i_enter_Middle_Names_as(String middlename) throws Throwable {

		driver.findElementByXPath(EposAddProspectPage.txt_givenname).sendKeys(middlename);

		// Hide the keyboard
		// HideKeyboard(driver);
	}


@When("^I will enter Surname$")
public void i_will_enter_Surname() throws Throwable {
	driver.context("WEBVIEW");

	
	driver.findElementByXPath(EposAddProspectPage.txt_surname).sendKeys(readPropertiesFile("surname"));
}

@When("^I enter  Middle Name$")
public void i_enter_Middle_Name() throws Throwable {
	



	driver.findElementByXPath(EposAddProspectPage.txt_givenname).sendKeys(readPropertiesFile("middlename"));
}

	
	
	@When("^I enter Country Code as \"([^\"]*)\",Phone Number as \"([^\"]*)\",Email as \"([^\"]*)\"$")
	public void i_enter_Country_Code_as_Phone_Number_as_Email_as(String countrycode, String phoneno, String email)
			throws Throwable {

		Countrycode(countrycode, driver);
		driver.findElementByXPath(EposAddProspectPage.txt_phonenumber).sendKeys(phoneno);

		// Hide the keyboard
		// HideKeyboard(driver);

		driver.findElementByXPath(EposAddProspectPage.txt_email).sendKeys(email);
		driver.findElementByXPath(EposAddProspectPage.txt_phonenumber).click();
		visualScroll(driver);

		// Hide the keyboard
		// HideKeyboard(driver);

	}

	@When("^select Gender as \"([^\"]*)\"$")
	public void select_Gender_as(String gender) throws Throwable {

		Gender_Select(gender, driver);

	}

	@When("^check the box I have read and agree to the PICS notice$")
	public void check_the_box_I_have_read_and_agree_to_the_PICS_notice() throws Throwable {

		driver.findElementByXPath(EposAddProspectPage.chk_agreetext).click();

	}

	@When("^click on continue button$")
	public void click_on_continue_button() throws Throwable {

		driver.findElementByXPath(EposAddProspectPage.btn_continue).click();

	}

	@Then("^I will be navigated to e-Consent page$")
	public void i_will_be_navigated_to_e_Consent_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@Then("^click on Skip this step for now$")
	public void click_on_Skip_this_step_for_now() throws Throwable {
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(EposAddProspectPage.lnk_ignore)));
	    driver.findElementByXPath(EposAddProspectPage.lnk_ignore).click();
	    
	}
	
	@Then("^click on signture box provided for customer and Agent name and sign in the box provided click on confirm button$")
	public void click_on_signture_box_provided_for_customer_and_Agent_name_and_sign_in_the_box_provided_click_on_confirm_button()
			throws Throwable {
		Signaddprospect(driver);
		/*
		driver.context("NATIVE");
		textClick("Tap to sign here", 5, driver);
		drawLetter("P", driver);
		driver.findElementByXPath(EposAddProspectPage.btn_confirm).click();

		textClick("Tap to sign here", 5, driver);
		drawLetter("P", driver);
		driver.findElementByXPath(EposAddProspectPage.btn_confirm).click();
		*/
	}

	@Then("^click on submit button$")
	public void click_on_submit_button() throws Throwable {

		driver.findElementByXPath(EposAddProspectPage.btn_submit).click();

	}

	@Then("^click on the ok button in the pop-up box displayed$")
	public void click_on_the_ok_button_in_the_pop_up_box_displayed() throws Throwable {

		driver.context("NATIVE_APP");
		driver.findElementByXPath(EposAddProspectPage.btn_OK).click();

	}

	@Then("^prospect is created$")
	public void prospect_is_created() throws Throwable {
		driver.context("NATIVE");
		try{
			
		}catch(Exception ex){}
		driver.context("WEBVIEW");
	 
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@label='Profile'] | //*[text()='Profile']")));
			
		
		if (driver.findElementByXPath(EposAddProspectPage.pge_header).isDisplayed()) {
			ReportGeneration("Prospect is created", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Prospect creation failed", "Fail", "Yes", driver);
		}

		log.info("Ended");
	}

}
