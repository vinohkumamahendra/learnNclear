package com.CucumberCraft.stepDefinitions;

import java.awt.Desktop.Action;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.CucumberCraft.pageObjects.Applyphase;
import com.CucumberCraft.pageObjects.EposAddFNAPage;
import com.CucumberCraft.pageObjects.EposCreateProposalPage;
import com.CucumberCraft.pageObjects.EposDrawerMenu;
import com.CucumberCraft.pageObjects.LoginEPOSAppPage;
import com.CucumberCraft.supportLibraries.DriverManager;
import com.itextpdf.text.log.SysoCounter;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.AppiumDriver;

public class CreateProposal_2 extends MasterStepDefs {

	AppiumDriver driver = DriverManager.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 30);

	@Then("^I will search for the customer \"([^\"]*)\" for whom FNA is completed and for which prospect is pending$")
	public void i_will_search_for_the_customer_for_whom_FNA_is_completed_and_for_which_prospect_is_pending(
			
			String custname) throws Throwable {
			driver.context("NATIVE_APP");
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		try {
			if (driver.findElementByXPath(EposCreateProposalPage.tab_Drawer_Menu).isDisplayed()) {

				driver.findElementByXPath(EposCreateProposalPage.tab_Drawer_Menu).click();

				// To click on Customer List
				//textClick("Customer List", 5, driver);
				Customerlistclick(driver);
				// If password window pop-up
				Passwordentry(driver);
				driver.context("NATIVE_APP");
				System.out.println("Entered native and search for txt field");
				driver.findElementByXPath(EposAddFNAPage.txt_cust).sendKeys(custname);
				driver.findElementByXPath(EposAddFNAPage.btn_Key_GO).click();

				
				CustomerClick(custname, driver);
				// If password window pop-up
				Passwordentry(driver);

				// do nothing
				driver.context("NATIVE_APP");
				driver.findElementByXPath(EposCreateProposalPage.tab_Drawer_Menu).click();
				driver.findElementByXPath(EposCreateProposalPage.tab_Proposal).click();

				// To handle download button
				try {

					if (driver.findElementByXPath(EposCreateProposalPage.btn_Download).isDisplayed()) {
						driver.findElementByXPath(EposCreateProposalPage.btn_Download).click();
					}

				} catch (Exception ex) {
						System.out.println("Entered Exception");
				}
				// To handle sync time
				try {

					do {

					} while (driver.findElementByXPath(EposCreateProposalPage.ldg_Create_Prop).isDisplayed());
				} catch (Exception e) {

				}

			} else // If proposal pop-Up is present
			{
				Proposalbuttonclick(driver);
			}
		} catch (Exception ex) {
			Proposalbuttonclick(driver);
		}

		driver.findElementByXPath(EposCreateProposalPage.btn_Create_Proposal).click();

	}
	
	@Then("^I will search for the customer for whom FNA is completed and for which prospect is pending$")
	public void i_will_search_for_the_customer_for_whom_FNA_is_completed_and_for_which_prospect_is_pending() throws Throwable {
		driver.context("NATIVE_APP");

		try {
			if (driver.findElementByXPath(EposCreateProposalPage.tab_Drawer_Menu).isDisplayed()) {

				driver.findElementByXPath(EposCreateProposalPage.tab_Drawer_Menu).click();

				// To click on Customer List
				//textClick("Customer List", 5, driver);
				Customerlistclick(driver);
				
				driver.context("NATIVE");
				
				try{
					driver.findElementByXPath(EposAddFNAPage.txt_cust).sendKeys(readPropertiesFile("name"));
					driver.findElementByXPath(EposAddFNAPage.btn_Key_GO).click();
					CustomerClick(readPropertiesFile("name")+" ", driver);
				}catch(Exception ex){
					// If password window pop-up
					Passwordentry(driver);
					driver.context("NATIVE");
					driver.findElementByXPath(EposAddFNAPage.txt_cust).sendKeys(readPropertiesFile("name"));
					driver.findElementByXPath(EposAddFNAPage.btn_Key_GO).click();
					CustomerClick(readPropertiesFile("name")+" ", driver);
								
					
				}
															

				// do nothing
				driver.context("NATIVE_APP");
				driver.findElementByXPath(EposCreateProposalPage.tab_Drawer_Menu).click();
				driver.findElementByXPath(EposCreateProposalPage.tab_Proposal).click();

				
				// To handle sync time
				try {

					do {

					} while (driver.findElementByXPath(EposCreateProposalPage.ldg_Create_Prop).isDisplayed());
				} catch (Exception e) {

				}

			} else // If proposal pop-Up is present
			{
				Proposalbuttonclick(driver);
			}
		} catch (Exception ex) {
			Proposalbuttonclick(driver);
		}

		driver.findElementByXPath(EposCreateProposalPage.btn_Create_Proposal).click();

	}
	
	
	

	@When("^I will click on Proposals from the drawer menu$")
	public void i_will_click_on_Proposals_from_the_drawer_menu() throws Throwable {

	}

	@Then("^I will click on \\+ icon$")
	public void i_will_click_on_icon() throws Throwable {

	}

	@Then("^I will be asking for Password and enter \"([^\"]*)\"$")
	public void i_will_be_asking_for_Password_and_enter(String password) throws Throwable {
		try {
			do {

			} while (driver.findElementByXPath(EposCreateProposalPage.Ldg_Comp_Prop).isDisplayed());
		} catch (Exception e) {
			// Do nothing
		}

		// Function to kill Manutouch
		// ManutouchKill(driver);

		// Function to login Comprop Application
		CompropLoginTest(password, driver);
		// CompropLogin(password,driver);
		driver.context("WEBVIEW");
		// To handle Pop-Up message
		
	}

	@Then("^Click on OK in the popup$")
	public void click_on_OK_in_the_popup() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@Then("^I will select Smoker Status as \"([^\"]*)\" in Insured section$")
	public void i_will_select_Smoker_Status_as_in_Insured_section(String arg1) throws Throwable {

		if (driver.findElementByXPath(EposCreateProposalPage.btn_Smoker_Stat).isDisplayed()) {
			ReportGeneration("Successfully navigated to owner details in comprop", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Navigation to owner details in comprop failed", "Fail", "Yes", driver);
		}

		driver.findElementByXPath(EposCreateProposalPage.btn_Smoker_Stat).sendKeys(arg1);

	}

	@Then("^I will select Smoker Status as \"([^\"]*)\" in Owner section$")
	public void i_will_select_Smoker_Status_as_in_Owner_section(String arg1) throws Throwable {

		driver.findElementByXPath(EposCreateProposalPage.btn_Dep_Smoker_Stat).sendKeys(arg1);

	}

	@Then("^I will click Basic Plan tab$")
	public void i_will_click_Basic_Plan_tab() throws Throwable {
		driver.context("WEBVIEW");
		//driver.findElementByXPath(EposCreateProposalPage.tab_Basic_Plan).click();
		proposalBasicNav(driver.findElementByXPath(EposCreateProposalPage.tab_Basic_Plan),driver);

	}

	@Then("^I will select Basic Plan as \"([^\"]*)\"$")
	public void i_will_select_Basic_Plan_as(String planname) throws Throwable {
		driver.context("WEBVIEW");
		WebDriverWait wait =new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(EposCreateProposalPage.tab_Basicplan)));
		//wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath(EposCreateProposalPage.tab_Selected)));
		Plan_Selector_Comprop(planname, driver);
		

	}

	@Then("^I will enter Notional Amount as \"([^\"]*)\"$")
	public void i_will_enter_Notional_Amount_as(String notional_amt) throws Throwable {
		driver.context("WEBVIEW");
		if (driver
				.findElementByXPath(
						"//TR/TD[contains(text(),'Basic Premium')]/following-sibling::TD/INPUT | //*[@name='face_amount']")
				.isDisplayed()) {
			// if(driver.findElementByXPath("//*[@name='face_amount']").isDisplayed()){
			ReportGeneration("Successfully navigated basic tab in comprop", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Navigation to basic tab in comprop failed", "Fail", "Yes", driver);
		}

		driver.findElementByXPath(
				"//TR/TD[contains(text(),'Basic Premium')]/following-sibling::TD/INPUT | //*[@name='face_amount']")
				.clear();
		driver.findElementByXPath(
				"//TR/TD[contains(text(),'Basic Premium')]/following-sibling::TD/INPUT | //*[@name='face_amount']")
				.sendKeys(notional_amt);

		HideKeyboard(driver);

	}

	@Then("^Select Payment mode as \"([^\"]*)\"$")
	public void select_Payment_mode_as(String paymentmode) throws Throwable {

		ProposalPaymentMode(paymentmode, driver);
		// Comprop_PaymentMode(paymentmode,driver);
		/*
		 * textClick("Annual",5,driver); driver.context("NATIVE_APP");
		 * Comprop_PaymentMode(paymentmode,driver);
		 */

	}

	
	@Then("^I will select Occupation class as \"([^\"]*)\"$")
	public void i_will_select_Occupation_class_as(String occ_class) throws Throwable {
		proposalOccupationClass(occ_class,driver);
	}

	@Then("^I will select \"([^\"]*)\" and enter value as \"([^\"]*)\"$")
	public void i_will_select_and_enter_value_as(String policyname, String amount) throws Throwable {
		CheckBoxValue(policyname,amount,driver);
	}

	
	
	
	@Then("^I will select Cash Assistance Benefit-CA(\\d+)$")
	public void i_will_select_Cash_Assistance_Benefit_CA(int arg1) throws Throwable {
		driver.context("WEBVIEW");
		textClick("Supplementary Benefit", 5, driver);

		if (driver.findElementByXPath(EposCreateProposalPage.chk_CA475).isDisplayed()) {
			ReportGeneration("Successfully navigated to supplementary tab in comprop", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Navigation to supplementary tab in comprop failed", "Fail", "Yes", driver);
		}

		driver.findElementByXPath(EposCreateProposalPage.chk_CA475).click();
		driver.findElementByXPath(EposCreateProposalPage.btn_RCC).click();
	}

	@Then("^Enter Protection Amount as \"([^\"]*)\"$")
	public void enter_Protection_Amount_as(String amt1) throws Throwable {
		driver.findElementByXPath(EposCreateProposalPage.txt_CA475).sendKeys(amt1);

	}

	@Then("^check with IPO option for CA(\\d+)$")
	public void check_with_IPO_option_for_CA(int arg1) throws Throwable {
		driver.findElementByXPath(EposCreateProposalPage.chk_IPOCA475).click();

	}

	@Then("^I will select Premier Life Critical Illness Benefit-CIB$")
	public void i_will_select_Premier_Life_Critical_Illness_Benefit_CIB() throws Throwable {
		driver.findElementByXPath(EposCreateProposalPage.chk_CIB).click();

	}

	@Then("^Enter Protection Amount for CIB as \"([^\"]*)\"$")
	public void enter_Protection_Amount_for_CIB_as(String amt2) throws Throwable {
		driver.findElementByXPath(EposCreateProposalPage.txt_CIB).sendKeys(amt2);

	}

	@Then("^check with IPO option for CIB$")
	public void check_with_IPO_option_for_CIB() throws Throwable {
		driver.findElementByXPath(EposCreateProposalPage.chk_IPOCIB).click();

	}

	@Then("^I will select Accident Assistance Benefit-AAB$")
	public void i_will_select_Accident_Assistance_Benefit_AAB() throws Throwable {
		driver.findElementByXPath(EposCreateProposalPage.chk_AAB).click();

	}

	@Then("^Enter Protection amount as \"([^\"]*)\"$")
	public void enter_Protection_amount_as(String amt3) throws Throwable {
		driver.findElementByXPath(EposCreateProposalPage.txt_AAB).sendKeys(amt3);

	}

	@Then("^I will select Personal Accident Benefit-AH(\\d+)$")
	public void i_will_select_Personal_Accident_Benefit_AH(int arg1) throws Throwable {
		driver.findElementByXPath(EposCreateProposalPage.chk_AH75).click();

	}

	@Then("^Enter Protection amount for benifit  as \"([^\"]*)\"$")
	public void enter_Protection_amount_for_benifit_as(String amt4) throws Throwable {
		driver.findElementByXPath(EposCreateProposalPage.txt_AH75).sendKeys(amt4);

	}

	@Then("^I will select Medical Indemnity Benefit-AJ(\\d+)$")
	public void i_will_select_Medical_Indemnity_Benefit_AJ(int arg1) throws Throwable {
		driver.findElementByXPath(EposCreateProposalPage.chk_AJ75).click();

	}

	@Then("^Enter Protection amount for Medical  as \"([^\"]*)\"$")
	public void enter_Protection_amount_for_Medical_as(String amt5) throws Throwable {
		driver.findElementByXPath(EposCreateProposalPage.txt_AJ75).sendKeys(amt5);

	}

	@Then("^I will select ManuMaster Healthcare Benefit-HQ(\\d+)$")
	public void i_will_select_ManuMaster_Healthcare_Benefit_HQ(int arg1) throws Throwable {
		driver.findElementByXPath(EposCreateProposalPage.chk_HQ99).click();

	}

	@Then("^I will click on Preview button$")
	public void i_will_click_on_Preview_button() throws Throwable {
		// driver.findElementByXPath(EposCreateProposalPage.btn_Preview).click();

		driver.context("WEBVIEW");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(EposCreateProposalPage.btn_Preview)));
		driver.findElementByXPath(EposCreateProposalPage.btn_Preview).click();

	}

	@Then("^I will be navigated to Premium Summary tab$")
	public void i_will_be_navigated_to_Premium_Summary_tab() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@Then("^I will click on Print button$")
	public void i_will_click_on_Print_button() throws Throwable {
		driver.context("WEBVIEW");
		SetPageContext("WEBVIEW_2",driver);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(EposCreateProposalPage.btn_print)));
		driver.findElementByXPath(EposCreateProposalPage.btn_print).click();

	}

	@Then("^I will click on English in Proposal Language$")
	public void i_will_click_on_English_in_Proposal_Language() throws Throwable {
		WebDriverWait wait =new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Print Options']")));
		if(driver.findElementByXPath(EposCreateProposalPage.btn_English).isDisplayed()){
		driver.findElementByXPath(EposCreateProposalPage.btn_English).click();
		}

	}

	@Then("^Click on PRINT button$")
	public void click_on_PRINT_button() throws Throwable {
		driver.context("WEBVIEW");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@name=\"btnPrint\"]")));
		driver.findElementByXPath("//*[@name=\"btnPrint\"]").click();

	}

	@Then("^I will click on SAVE button$")
	public void i_will_click_on_SAVE_button() throws Throwable {
		driver.context("WEBVIEW");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(EposCreateProposalPage.btn_Save)));
		driver.findElementByXPath(EposCreateProposalPage.btn_Save).click();

	}

	@Then("^I will click on OK in the popup$")
	public void i_will_click_on_OK_in_the_popup() throws Throwable {
		try {
			driver.context("NATIVE");
			driver.findElementByXPath(EposCreateProposalPage.btn_Popup).click();
		} catch (Exception ex) {
		}

	}

	@Then("^I will click on Close button from top left corner$")
	public void i_will_click_on_Close_button_from_top_left_corner() throws Throwable {
		Waitforloading(Applyphase.ele_Ldg_PDF, driver);
		driver.context("NATIVE");
		driver.findElementByXPath(EposCreateProposalPage.btn_Close).click();

	}

}
