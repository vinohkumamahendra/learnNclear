package com.CucumberCraft.stepDefinitions;

import java.awt.Desktop.Action;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.List;

import org.apache.commons.lang.ArrayUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.appium.java_client.TouchAction;

import com.CucumberCraft.pageObjects.Applyphase;
import com.CucumberCraft.pageObjects.EposAddFNAPage;
import com.CucumberCraft.pageObjects.EposAddProspectPage;
import com.CucumberCraft.pageObjects.EposCreateProposalPage;
import com.CucumberCraft.pageObjects.EposDrawerMenu;
import com.CucumberCraft.pageObjects.LoginEPOSAppPage;
import com.CucumberCraft.supportLibraries.DriverManager;
import com.CucumberCraft.supportLibraries.SeleniumTestParameters;
import com.CucumberCraft.supportLibraries.Util;
import cucumber.api.Scenario;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

import org.testng.asserts.Assertion;

public abstract class MasterStepDefs {
	
	public  String comprop;
	static Map<String, Object> perfectoCommand = new HashMap<>();
	Set<String> set = new HashSet<String>();
	protected static Scenario currentScenario;
	protected static SeleniumTestParameters currentTestParameters;
	static Logger log;
	public static boolean resultagree;
	public static boolean resultprospect;
	static final String AB = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    static final String BC = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    static SecureRandom rnd = new SecureRandom();

	protected static Properties dataproperties;

	static {
		log = Logger.getLogger(EPoslogin.class);
	}

	public static void swipeRightToLeft(AppiumDriver<?> driver) {

		Dimension size = driver.manage().window().getSize();
		int startx = (int) (size.width * 0.8);
		int endx = (int) (size.width * 0.16);
		int starty = (int) (size.height * 0.75);

		driver.swipe(startx, starty, endx, starty, 1000);

	}

	
	public static void Directdebitbankname(String bankname,AppiumDriver<?> driver){
		
		driver.findElementByXPath(Applyphase.txt_DirectDebit_Bankname).click();
		driver.findElementByXPath("//*[text()='"+bankname+"']").click();
		
	}
	
public static void DirectdebitAccIDType(String IDtype,AppiumDriver<?> driver){
		
		driver.findElementByXPath(Applyphase.txt_DirectDebit_AccIDType).click();
		driver.findElementByXPath("//*[text()='"+IDtype+"']").click();
		
	}

protected void openAppWithIdentifier(final String context, final String identifer,AppiumDriver driver) {
    if (context.equals("NATIVE_APP")) {
           perfectoCommand.put("identifier", identifer);
           driver.executeScript("mobile:application:open", perfectoCommand);
           perfectoCommand.clear();
    } 

}
public static void DirectdebitAccholderqn(String policyqn,AppiumDriver<?> driver){
	
	driver.findElementByXPath(Applyphase.txt_DirectDebit_AccHoldpolicy).click();
	driver.findElementByXPath("//*[text()='"+policyqn+"']").click();
	
}
	
public static void DirectdebitJntholderqn(String Jntpolicyqn,AppiumDriver<?> driver){
	
	if(Jntpolicyqn.equalsIgnoreCase("No")){
		imageNoClick(driver);
		
	}else if(Jntpolicyqn.equalsIgnoreCase("Yes")){
		imageYesClick(driver);
		
	}
	
}

public static void imageNoClick(AppiumDriver<?> driver){
	PauseScript(5, driver);
	perfectoCommand.put("content", "PUBLIC:ePOSImageObjects/btn_No.png");
	perfectoCommand.put("timeout", "5");
	perfectoCommand.put("screen.top", "0%");
	perfectoCommand.put("screen.height", "100%");
	perfectoCommand.put("screen.left", "0%");
	perfectoCommand.put("screen.width", "100%");
	PauseScript(5, driver);
	final Object result =driver.executeScript("mobile:image:select", perfectoCommand);
	/*
	final Boolean resultBool = Boolean.valueOf(result.toString());
	if(resultBool==true){
		perfectoCommand.clear();
				
	}else{
		imageNoClick(driver);
	}
	*/
	
	
}

public static void imageYesClick(AppiumDriver<?> driver){
	PauseScript(5, driver);
	perfectoCommand.put("content", "PUBLIC:ePOSImageObjects/btn_Yes.png");
	perfectoCommand.put("timeout", "5");
	perfectoCommand.put("screen.top", "0%");
	perfectoCommand.put("screen.height", "100%");
	perfectoCommand.put("screen.left", "0%");
	perfectoCommand.put("screen.width", "100%");
	PauseScript(5, driver);
	final Object result =driver.executeScript("mobile:image:select", perfectoCommand);
	/*
	final Boolean resultBool = Boolean.valueOf(result.toString());
	
	if(resultBool==true){
		perfectoCommand.clear();
				
	}else{
		imageNoClick(driver);
	}
	*/
}

public static void DirectdebitAccNo(String val1,String val2,AppiumDriver<?> driver){
	//driver.findElementByXPath(Applyphase.txt_DirectDebit_Accbrno).sendKeys(val1);
	//driver.findElementByXPath(Applyphase.txt_DirectDebit_Accno).sendKeys(val2);
	
	//To handle Acc number fields by co-ordinates
	Map<String, Object> params9 = new HashMap<>();
	params9.put("location", "857,627");
	Object result8 = driver.executeScript("mobile:touch:tap", params9);
	driver.getKeyboard().sendKeys(val1);
	
	//Acc No-2
	
	Map<String, Object> params2 = new HashMap<>();
	params2.put("location", "1008,627");
	Object result2 = driver.executeScript("mobile:touch:tap", params2);
	driver.getKeyboard().sendKeys(val2);
	
	HideKeyboard(driver);
		
}
	
	
	public static void MCVfield(String field_value,AppiumDriver<?> driver){
		
		driver.findElementByXPath("//*[@label='"+field_value+"']").click();
		
	}
	
	public static void MCVfield(String type,String value,AppiumDriver<?> driver){
		switch(type){
		case "Text":
		driver.findElementByXPath("//*[@label='MCV Reference Number']/following::UIATextField").sendKeys(value);
		break;
		}
	}
	
	public static void Diseasedetails(String text1, String text2, String text3, AppiumDriver<?> driver) {
		
		driver.context("WEBVIEW");
		SetPageContext("WEBVIEW_2",driver);
		
		driver.findElementByXPath("//*[@class=\"form-control ng-pristine ng-untouched ng-valid ng-scope\"]").click();
		driver.findElementByXPath("//*[@class=\"form-control ng-pristine ng-untouched ng-valid ng-scope\"]").sendKeys(text1);
		driver.findElementByXPath(Applyphase.Lbl_Applyheader).click();
		driver.findElementByXPath("//*[@class=\"form-control ng-pristine ng-untouched ng-valid ng-scope\"]").click();
		driver.findElementByXPath("//*[@class=\"form-control ng-pristine ng-untouched ng-valid ng-scope\"]").sendKeys(text2);
		driver.findElementByXPath(Applyphase.Lbl_Applyheader).click();
		driver.findElementByXPath("//*[@class=\"form-control ng-pristine ng-untouched ng-valid ng-scope\"]").click();
		driver.findElementByXPath("//*[@class=\"form-control ng-pristine ng-untouched ng-valid ng-scope\"]").sendKeys(text3);
		
	}
	
	protected static void Applypaymentmode(String paymentmode,AppiumDriver<?> driver){
		
		driver.findElementByXPath("//LABEL[contains(text(),'"+paymentmode+"')]").click();
	}
	protected  static void Applyselectdocs(String doc_name,AppiumDriver<WebElement> driver){
		
		List<WebElement> doccount=driver.findElementsByXPath("//UIATableCell[UIAStaticText[contains(@label,'"+doc_name+"')]]/UIAButton[@label='icon photo green']");
		//List<WebElement> doccount=driver.findElementsByXPath("//UIATableCell[UIAStaticText[@label='"+doc_name+"')]]/UIAButton[@label='icon photo green']");
		int w=doccount.size();
		if(w>1){
			for(int i=1;i<=w;i++){
				driver.findElementByXPath("//UIATableView["+i+"]//UIATableCell/UIAStaticText[contains(@label,'"+doc_name+"')]/parent::UIATableCell/UIAButton[@label='icon photo green']").click();
				ApplyTakePhoto(driver);
			}
		}else{
				driver.findElementByXPath("//UIATableCell[UIAStaticText[contains(@label,'"+doc_name+"')]]/UIAButton[@label='icon photo green']").click();
				ApplyTakePhoto(driver);
			}
	
	}
	
	
	protected static void Applythirdpartypaymentmode(String paymentmode,AppiumDriver<?> driver){
		
		driver.findElementByXPath("//*[text()='"+paymentmode+"']").click();
	}
	
	protected static void Applythirdpartypaymentcurrency(String currency,AppiumDriver<?> driver){
		
		driver.findElementByXPath("//*[@class='payment-checkbox-label ng-scope' and text()='"+currency+"']").click();
	}
	
	protected static void Applythirdpartypaymentmethod(String method,AppiumDriver<?> driver){
		/*///Working code -Previously used
		driver.context("VISUAL");		
		perfectoCommand.put("content", "PUBLIC:ePOSImageObjects/PaymentMode.png");
		perfectoCommand.put("timeout", "5");
		perfectoCommand.put("screen.top", "0%");
		perfectoCommand.put("screen.height", "100%");
		perfectoCommand.put("screen.left", "0%");
		perfectoCommand.put("screen.width", "100%");
		driver.executeScript("mobile:image:select", perfectoCommand);
		perfectoCommand.clear();
		driver.context("WEBVIEW");
		SetPageContext("WEBVIEW_2",driver);
		WebElement pymt_method=driver.findElementByXPath("//*[text()='"+method+"']");
		pymt_method.click();
		*/
		driver.findElementByXPath(Applyphase.btn_Pymt_Method).click();
		WebElement pymt_method=driver.findElementByXPath("//*[text()='"+method+"']");
		pymt_method.click();
		
	}
	

	protected static void Relationship(String relationship, AppiumDriver<?> driver) {
		WebDriverWait wait = new WebDriverWait(driver, 60);
		driver.findElementByXPath(Applyphase.lst_Relationship).click();
		driver.findElementByXPath("//LI[p[text()='" + relationship + "']]").click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By
				.xpath("//*[@id='personalInfoPolicyownerRelationshipToProposedInsured-control']//*[@id='undefined_button']/LABEL[text()='"
						+ relationship + "']")));

	}

	protected static void Relationship(String type, String relationship, AppiumDriver<?> driver) {
		switch (type) {
		case "Payor":
			//WebDriverWait wait = new WebDriverWait(driver, 60);
			driver.findElementByXPath(Applyphase.lst_Relationship_Payor).click();
			driver.findElementByXPath("//LI[p[text()='" + relationship + "']]").click();
			//driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			// wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='personalInfoPolicyownerRelationshipToProposedInsured-control']//*[@id='undefined_button']/LABEL[text()='"+relationship+"']")));
			break;
		}

	}

	protected static void Labelclick(String name, AppiumDriver<?> driver) {
		driver.findElementByXPath("//*[@label='" + name + "']");

	}

	protected static void ProposalPaymentMode(String mode, AppiumDriver<?> driver) {
		driver.findElementByXPath("//TR[contains(@id,'PaymentMode')]/TD/SELECT/*[text()='" + mode + "']").click();
	}

	protected static void ProposalInsured(String name, AppiumDriver<?> driver) {
		driver.findElementByXPath("//SELECT[contains(@name,'selected_insured')]//*[text()='" + name + "']").click();
		//driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);

	}

	protected static void Proposalgender(String gender, AppiumDriver<?> driver) {
		driver.findElementByXPath("//*[@name='primary_sex' and @value='" + gender + "']").click();

	}
	
	protected static void ThirdpartyNationality(String Nationality, AppiumDriver<?> driver) {
		WebDriverWait wait = new WebDriverWait(driver, 60);
		driver.findElementByXPath("//*[@id='agreementsThirdPartyNationality-control']//*[@id='undefined_button']").click();
				
		driver.findElementByXPath("//LI[p[text()='" + Nationality + "']]").click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By
				.xpath("//*[@id='agreementsThirdPartyNationality-control']//*[@id='undefined_button']/LABEL[text()='"
						+ Nationality + "']")));
			

	}
	
	protected static void ThirdpartyGender(String gender, AppiumDriver<?> driver) {
		WebDriverWait wait = new WebDriverWait(driver, 60);
		driver.findElementByXPath("//*[@id='agreementsThirdPartySex-control']//*[@id='undefined_button']").click();
				
		driver.findElementByXPath("//LI[p[text()='" + gender + "']]").click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By
				.xpath("//*[@id='agreementsThirdPartySex-control']//*[@id='undefined_button']/LABEL[text()='"
						+ gender + "']")));
			

	}
	
	protected static void ThirdpartyCountry(String country, AppiumDriver<?> driver) {
		WebDriverWait wait = new WebDriverWait(driver, 60);
		driver.findElementByXPath("//*[@id='agreementsThirdPartyPassportCountryOfIssue-control']//*[@id='undefined_button']").click();
				
		driver.findElementByXPath("//LI[p[text()='" + country + "']]").click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By
				.xpath("//*[@id='agreementsThirdPartyPassportCountryOfIssue-control']//*[@id='undefined_button']/LABEL[text()='"
						+ country + "']")));
			

	}
	protected static void docIssueCountry(String country, AppiumDriver<?> driver) {
		driver.findElementByXPath(Applyphase.btn_Doc_Iss_Ctry).click();
		
		driver.findElementByXPath("//LI[p[text()='" + country + "']]").click();
	}
	protected static void applyHanded(String value, AppiumDriver<?> driver) {
		if(value.equalsIgnoreCase("Left Handed")){
			driver.findElementByXPath(Applyphase.btn_Lefthand).click();
		}else if(value.equalsIgnoreCase("Right Handed")){
			driver.findElementByXPath(Applyphase.btn_Righthand).click();
		}
	}
	
	
	
	protected static void CheckBoxClick(String policyname, AppiumDriver<?> driver) {
		driver.context("WEBVIEW");
		driver.findElementByXPath("//TD[contains(text(),'" + policyname + "')]/preceding-sibling::TD/INPUT").click();

	}

	protected static void CheckBoxValue(String policyname, String value, AppiumDriver<?> driver) {
		driver.findElementByXPath("//TD[contains(text(),'" + policyname + "')]/preceding-sibling::TD/INPUT").click();
		driver.findElementByXPath("//TD[contains(text(),'" + policyname + "')]/following-sibling::TD/INPUT")
				.sendKeys(value);

	}

	protected static void CheckBoxListValue(String policyname, String value, AppiumDriver<?> driver) {
		driver.findElementByXPath("//TD[contains(text(),'" + policyname + "')]/preceding-sibling::TD/INPUT").click();
		driver.findElementByXPath(
				"//TD[contains(text(),'" + policyname + "')]/../TD[last()]/SELECT//*[text()='" + value + "']").click();

	}
	
	protected static void CheckBoxListValue(String policyname, String value,int listboxno, AppiumDriver<?> driver) {
		driver.findElementByXPath("//TD[contains(text(),'" + policyname + "')]/preceding-sibling::TD/INPUT").click();
		driver.findElementByXPath(
				"//TD[contains(text(),'" + policyname + "')]/../TD[last()]/SELECT["+listboxno+"]//*[text()='" + value + "']").click();

	}

	
	
	protected void WaitForObject(String textname, AppiumDriver<?> driver) {
		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", textname);
		// params1.put("content", "Chinese Name");
		params1.put("timeout", "10");
		params1.put("threshold", "80");
		Object result1 = driver.executeScript("mobile:checkpoint:text", params1);

	}

	protected void DeleteUndefined(AppiumDriver<?> driver) {

		driver.findElementByXPath("//*[@class='gact iconDelete']").click();
		driver.context("NATIVE");
		driver.findElementByXPath("//*[@label='YES']").click();
		driver.context("WEBVIEW");

	}

	protected void Comprop_PaymentMode(String paymentmode, AppiumDriver<?> driver) {

		driver.findElementByXPath("//*[@label='" + paymentmode + "']").click();

	}
	protected void FNAlabelclick(String lbl_name,AppiumDriver driver){
		driver.findElementByXPath("//*[@label='"+lbl_name+"']/preceding::UIAButton[1]").click();
	}
	

	protected void AddInvestmentChoice(String choice, AppiumDriver<?> driver) {
		driver.findElementByXPath(Applyphase.btn_Add_Inv_Choice).click();
		driver.context("WEBVIEW_2");
		SetPageContext("WEBVIEW_3", driver);
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.visibilityOf(driver.findElementByXPath("//*[@type='text']")));
		// driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElementByXPath("//*[@type='text']").sendKeys(choice);
		// driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//DIV[contains(text(),'" + choice + "')]")));
		driver.findElementByXPath("//DIV[contains(text(),'" + choice + "')]").click();
		driver.findElementByXPath("//SPAN/A[contains(text(),'Done')]").click();
		driver.context("WEBVIEW");
		SetPageContext("WEBVIEW_2", driver);
	}

	protected void Click_Goal(String goalname, AppiumDriver<?> driver) {
		WebDriverWait wait=new WebDriverWait(driver, 60); 
		driver.context("WEBVIEW_2");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[text()='" + goalname + "']/parent::DIV/input[1]")));
		driver.findElementByXPath("//*[text()='" + goalname + "']/parent::DIV/input[1]").click();
		driver.findElementByXPath("//SPAN[contains(text(),'PROCEED')]").click();
		driver.context("WEBVIEW");

	}

	protected void GoalSelection(String goalname, AppiumDriver<?> driver) {

		int k = 16;
		for (int i = 1; i < k; i++) {

			if ((i == 4) || (i == 8) || (i == 12)) { // To swipe up since it
														// wont be visible
				ScrollUp(driver);
			}
			if (driver.findElementByXPath("//*[@class='goal-list scroll']/li[" + i + "]/div[1]/div[2]/TEXTAREA")
					.getAttribute("value").equalsIgnoreCase(goalname)) {

				driver.findElementByXPath("//*[@class='goal-list scroll']/li[" + i + "]/div[1]/div[4]/div[1]").click();
				break;
			} else {
				// Do nothing
			}
		}

	}

	protected void GoalStarAppend(String goalname, AppiumDriver<?> driver) {
		int k = 16;
		for (int i = 1; i < k; i++) {

			if ((i == 4) || (i == 8) || (i == 12)) { // To swipe up since it
														// wont be visible
				ScrollUp(driver);
			}
			if (driver.findElementByXPath("//*[@class='goal-list scroll']/li[" + i + "]/div[1]/div[2]/TEXTAREA")
					.getAttribute("value").equalsIgnoreCase(goalname)) {

				driver.findElementByXPath("//*[@class='goal-list scroll']/li[" + i + "]/div[1]/div[3]/div[2]").click();
				break;
			} else {
				// Do nothing
			}
		}
	}
	
	
	
	protected void Deletegoal(String goalname, AppiumDriver<?> driver) {
		int k = 16;
		driver.context("WEBVIEW");
		for (int i = 1; i < k; i++) {

			if ((i == 4) || (i == 8) || (i == 12)) { // To swipe up since it
														// wont be visible
				ScrollUp(driver);
			}
			if (driver.findElementByXPath("//*[@class='goal-list scroll']/li[" + i + "]/div[1]/div[2]/TEXTAREA")
					.getAttribute("value").equalsIgnoreCase(goalname)) {
				
				driver.findElementByXPath("//*[@class='goal-list scroll']/li[" + i + "]/div[1]/div[4]/div[1]").click();
				driver.context("NATIVE");
				if(driver.findElementByXPath(EposAddProspectPage.btn_Yes).isDisplayed()){
					driver.findElementByXPath(EposAddProspectPage.btn_Yes).click();
				}
				break;
			} else {
				// Do nothing
			}
		}
		driver.context("WEBVIEW");
	}

	
	
	protected void Solutiondeclareoption(String option, AppiumDriver<?> driver) {
		driver.findElementByXPath("//*[@value='" + option + "']/parent::DIV/LABEL/I").click();

	}

	protected void RPQQuestions(int qn_no, String option, AppiumDriver<?> driver) {

		int k = 0;
		String ret_opt_l;
		String ret_opt_r;
		//Getting count of left answers
		int left_qns_l = driver.findElementsByXPath("//DIV[contains(@id,'rpq" + qn_no + "section.rpq" + qn_no
				+ "')]//DIV[contains(@class,'tds-left-answers')]/div").size();
		//Getting count of right answers
		int right_qns_r = driver.findElementsByXPath("//DIV[contains(@id,'rpq" + qn_no + "section.rpq" + qn_no
				+ "')]//DIV[contains(@class,'tds-right-answers')]/div").size();
		//Iterating for left answers
		for (int i = 1; i <= left_qns_l; i++) {
			ret_opt_l = driver
						.findElementByXPath("//DIV[contains(@id,'rpq" + qn_no + "section.rpq" + qn_no
								+ "')]//DIV[contains(@class,'tds-left-answers')]/div[" + i + "]/input[1]")
						.getAttribute("value");		
			
		if (ret_opt_l.equalsIgnoreCase(option) || ret_opt_l.equalsIgnoreCase(option + ")")) {
				driver.findElementByXPath("//DIV[contains(@id,'rpq" + qn_no + "section.rpq" + qn_no
						+ "')]//DIV[contains(@class,'tds-left-answers')]/div[" + i
						+ "]//*[@class='dot' | @class='check']").click();
				k = 2;
				break;

			}
		}
		if(k!=2){
			for (int j = 1; j <= right_qns_r; j++) {//Iterating for right answers
				
					ret_opt_r = driver
							.findElementByXPath("//DIV[contains(@id,'rpq" + qn_no + "section.rpq" + qn_no
									+ "')]//DIV[contains(@class,'tds-right-answers')]/div[" + j + "]/input[1]")
							.getAttribute("value");
				
				if (ret_opt_r.equalsIgnoreCase(option) || ret_opt_r.equalsIgnoreCase(option + ")")) {
					driver.findElementByXPath("//DIV[contains(@id,'rpq" + qn_no + "section.rpq" + qn_no
							+ "')]//DIV[contains(@class,'tds-right-answers')]/div[" + j
							+ "]//*[@class='dot' | @class='check']").click();
					break;
				}
			}
		}
	}

	protected void RPQQuestions(AppiumDriver<?> driver,int qn_no, String... option ) {

		int k = 0;
		String ret_opt_l;
		String ret_opt_r;
		//Getting count of left answers
		int left_qns_l = driver.findElementsByXPath("//DIV[contains(@id,'rpq" + qn_no + "section.rpq" + qn_no
				+ "')]//DIV[contains(@class,'tds-left-answers')]/div").size();
		//Getting count of right answers
		int right_qns_r = driver.findElementsByXPath("//DIV[contains(@id,'rpq" + qn_no + "section.rpq" + qn_no
				+ "')]//DIV[contains(@class,'tds-right-answers')]/div").size();
		//Iterating for left answers
		for (int i = 1; i <= left_qns_l; i++) {
			ret_opt_l = driver.findElementByXPath("//DIV[contains(@id,'rpq" + qn_no + "section.rpq" + qn_no+ "')]//DIV[contains(@class,'tds-left-answers')]/div[" + i + "]//*[@class='order']").getText();		
		int option_len=option.length;	
		for (int l=0;l<option_len;l++){
		if (ret_opt_l.equalsIgnoreCase(option[l]) || ret_opt_l.equalsIgnoreCase(option[l] + ")")) {
				driver.findElementByXPath("//DIV[contains(@id,'rpq" + qn_no + "section.rpq" + qn_no
						+ "')]//DIV[contains(@class,'tds-left-answers')]/div[" + i
						+ "]//*[@class='dot' | @class='check']").click();
				k = 2;
				break;
		}
		}
		}
		
		for (int j = 1; j <= right_qns_r; j++) {//Iterating for right answers
				
				ret_opt_r = driver.findElementByXPath("//DIV[contains(@id,'rpq" + qn_no + "section.rpq" + qn_no+ "')]//DIV[contains(@class,'tds-right-answers')]/div[" + j + "]//*[@class='order']").getText();
				int option_len=option.length;
				for (int l=0;l<option_len;l++){
				if (ret_opt_r.equalsIgnoreCase(option[l]) || ret_opt_r.equalsIgnoreCase(option[l] + ")")) {
					driver.findElementByXPath("//DIV[contains(@id,'rpq" + qn_no + "section.rpq" + qn_no
							+ "')]//DIV[contains(@class,'tds-right-answers')]/div[" + j
							+ "]//*[@class='dot' | @class='check']").click();
					break;
				}
			
				}
			}
		}
	

	
	
	
	protected void GoalNewText(String text, AppiumDriver<?> driver) {
		driver.context("WEBVIEW");
		int k = 16;
		for (int i = 1; i < k; i++) {

			if ((i == 4) || (i == 8) || (i == 12)) { // To swipe up since it
														// wont be visible
				ScrollUp(driver);
			}
			if (driver.findElementByXPath("//*[@class='goal-list scroll']/li[" + i + "]/div[1]/div[2]/TEXTAREA")
					.getAttribute("value").isEmpty()) {

				String txtelement1 = driver
						.findElementByXPath("//*[@class='goal-list scroll']/li[" + i + "]/div[1]/div[2]/TEXTAREA")
						.getAttribute("id");

				driver.findElementByXPath("//*[@class='goal-list scroll']/li[" + i + "]/div[1]/div[4]/div[1]").click();

				driver.findElement(By.id(txtelement1)).sendKeys(text);
				driver.findElementByXPath("//H1[contains(text(),'Choose Your Goals')]").click(); // To
																									// click
																									// on
																									// the
																									// title
				break;
			} else {
				// Do nothing
			}
		}
	}

	protected void Goal_CalculateGoalClick(String goalname, AppiumDriver<?> driver) {

		WebDriverWait wait=new WebDriverWait(driver,60);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//H2[contains(text(),'" + goalname + "')]/parent::HEADER/parent::SECTION/div[1]/div[1]")));
		driver.findElementByXPath(
				"//H2[contains(text(),'" + goalname + "')]/parent::HEADER/parent::SECTION/div[1]/div[1]").click();
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//*[@class='calc-header']")));  

	}

	protected void ApplyQuestions(String qn, String option, AppiumDriver<?> driver) {
		WebDriverWait wait = new WebDriverWait(driver, 60);

		switch (qn) {
		case "Q1":
			wait.until(ExpectedConditions.visibilityOf(driver.findElementByXPath(
					"//*[@id='AgreementsReplacementAndCPDReplacement.agreementsReplacementPolicyReplacement']//*[text()='"
							+ option + "']/i[1]")));
			driver.findElementByXPath(
					"//*[@id='AgreementsReplacementAndCPDReplacement.agreementsReplacementPolicyReplacement']//*[text()='"
							+ option + "']/i[1]")
					.click();

			break;
		case "Q2":

			driver.findElementByXPath(
					"//*[@id='AgreementsReplacementAndCPDReplacement.agreementsReplacementIntendToReplace']//*[text()='"
							+ option + "']/i[1]")
					.click();
			break;
		case "Thirdparty_Qn":
			driver.findElementByXPath(
					"//*[@id='section-1.agreementsThirdPartyInterestsFlag']//*[text()='" + option + "']/i[1]").click();
			break;
		case "CRS_Qn":
			driver.findElementByXPath(
					"//*[@id='section-1.agreementsFATCACitizenship']//*[text()='" + option + "']/i[1]").click();
			break;
		case "Phase4_Qn1":
			driver.findElementByXPath("//*[@id='GEN_residence']//*[text()='" + option + "']/span[1]").click();
			break;
		case "Phase4_Qn2":
			wait.until(ExpectedConditions.visibilityOf(
					driver.findElementByXPath("//*[@id='GEN_substandard']//*[text()='" + option + "']/span[1]")));
			driver.findElementByXPath("//*[@id='GEN_substandard']//*[text()='" + option + "']/span[1]").click();
			break;
		case "Phase4_Qn3":
			wait.until(ExpectedConditions.visibilityOf(
					driver.findElementByXPath("//*[@id='GEN_pending_app']//*[text()='" + option + "']/span[1]")));
			driver.findElementByXPath("//*[@id='GEN_pending_app']//*[text()='" + option + "']/span[1]").click();
			break;
		case "Phase4_P2":
			wait.until(ExpectedConditions.visibilityOf(
					driver.findElementByXPath("//*[@id='AVOCATION_general']//*[text()='" + option + "']/span[1]")));
			driver.findElementByXPath("//*[@id='AVOCATION_general']//*[text()='" + option + "']/span[1]").click();
			break;
		case "Phase4_P3":
			wait.until(ExpectedConditions.visibilityOf(
					driver.findElementByXPath("//*[@id='LIFESTYLE_drugs']//*[text()='" + option + "']/span[1]")));
			driver.findElementByXPath("//*[@id='LIFESTYLE_drugs']//*[text()='" + option + "']/span[1]").click();
			break;
		case "Phase4_P4":
			wait.until(ExpectedConditions.visibilityOf(
					driver.findElementByXPath("//*[@id='FAM_history']//*[text()='" + option + "']/span[1]")));
			driver.findElementByXPath("//*[@id='FAM_history']//*[text()='" + option + "']/span[1]").click();
			break;
		case "Phase4_P5":
			driver.findElementByXPath("//*[@id='MED_5years']//*[text()='" + option + "']/span[1]").click();
			break;
		case "Medical_Q1":
			driver.findElementByXPath("//*[@id='MED_medication']//*[text()='" + option + "']/span[1]").click();
			break;
		case "Medical_Q2":
			driver.findElementByXPath("//*[@id='MED_hospital']//*[text()='" + option + "']/span[1]").click();
			break;
		case "Medical_Q3":
			driver.findElementByXPath("//*[@id='MED_investigation']//*[text()='" + option + "']/span[1]").click();
			break;
		case "Medical_Q4":
			driver.findElementByXPath("//*[@id='MED_disclosed_3']//*[text()='" + option + "']/span[1]").click();
			break;

		case "Medical_Q5":
			// *[@id="MED_checkup"]//*[text()="No"]/span[1]
			driver.findElementByXPath("//*[@id='MED_checkup']//*[text()='" + option + "']/span[1]").click();
			break;
		case "Medical_Q6":
			driver.findElementByXPath("//*[@id='MED_disclosed_2']//*[text()='" + option + "']/span[1]").click();
			break;

		case "Medical_Q7":
			driver.findElementByXPath("//*[@id='MED_timeoffwork']//*[text()='" + option + "']/span[1]").click();
			break;
		case "Medical_Q8":
			driver.findElementByXPath("//*[@id='MED_symptom']//*[text()='" + option + "']/span[1]").click();
			break;
		case "Medical_Q9":
			driver.findElementByXPath("//*[@id='MED_disability']//*[text()='" + option + "']/span[1]").click();
			break;
		case "Medical_Q10":
			driver.findElementByXPath("//*[@id='MED_major']//*[text()='" + option + "']/span[1]").click();
			break;

		}

	}

	protected void Applyqns(String qnno, String option, AppiumDriver<WebElement> driver) {
		switch (option) {
		case "Yes":// To click only visible option
			List<WebElement> answers_yes = driver.findElementsByXPath("//LABEL[contains(text(),'" + qnno
					+ ".')]/parent::DIV/DIV/DIV[@class='tds-left-answers']//LABEL[contains(text(),'" + option
					+ "')]/I");
			if (answers_yes.size() > 1) {
				for (WebElement answer : answers_yes) {
					if (answer.isDisplayed()) {
						answer.click();
					//	driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
					}
				}

			} else {
				driver.findElementByXPath("//LABEL[contains(text(),'" + qnno
						+ ".')]/parent::DIV/DIV/DIV[@class='tds-left-answers']//LABEL[contains(text(),'" + option
						+ "')]/I").click();
				//driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			}

			break;
		case "No":
			List<WebElement> answers_no = driver.findElementsByXPath("//LABEL[contains(text(),'" + qnno
					+ ".')]/parent::DIV/DIV/DIV[@class='tds-right-answers']//LABEL[contains(text(),'" + option
					+ "')]/I");
			if (answers_no.size() > 1) {
				for (WebElement answer : answers_no) {
					if (answer.isDisplayed()) {
						answer.click();
						//driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
					}
				}

			} else {
				driver.findElementByXPath("//LABEL[contains(text(),'" + qnno
						+ ".')]/parent::DIV/DIV/DIV[@class='tds-right-answers']//LABEL[contains(text(),'" + option
						+ "')]/I").click();
				//driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);

			}

			break;

		}
	}

	protected void Applyqnnames(String qntype, String qnname, String option, AppiumDriver<WebElement> driver) {

		switch (qntype) {
		case "Multiple":
			// List<WebElement>
			// answers_yes=driver.findElementsByXPath("//DIV[DIV[contains(text(),'"+qnname+"')]]/following-sibling::DIV//BUTTON[text()='"+option+"']//LABEL[contains(text(),'"+option+"')]/I");
			List<WebElement> answers_yes = driver.findElementsByXPath("//DIV[DIV[contains(text(),'" + qnname
					+ "')]]/following-sibling::DIV//BUTTON[text()='" + option + "']");
			if (answers_yes.size() > 1) {
				for (WebElement answer : answers_yes) {
					if (answer.isDisplayed()) {
						answer.click();
						//driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
					}
				}

			} else {
				// driver.findElementByXPath("//DIV[DIV[contains(text(),'"+qnname+"')]]/following-sibling::DIV//BUTTON[text()='"+option+"']//LABEL[contains(text(),'"+option+"')]/I").click();
				driver.findElementByXPath("//DIV[DIV[contains(text(),'" + qnname
						+ "')]]/following-sibling::DIV//BUTTON[text()='" + option + "']").click();
				//driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			}

			break;

		case "Single":
			if (option.equalsIgnoreCase("Yes")) {
				List<WebElement> answers_mul = driver.findElementsByXPath("//DIV[LABEL[contains(text(),'" + qnname
						+ "')]]/DIV/DIV[@class='tds-left-answers']//LABEL[contains(text(),'" + option + "')]/I");
				if (answers_mul.size() > 1) {
					for (WebElement answer : answers_mul) {
						if (answer.isDisplayed()) {
							answer.click();
							//driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
						}
					}

				} else {
					driver.findElementByXPath("//DIV[LABEL[contains(text(),'" + qnname
							+ "')]]/DIV/DIV[@class='tds-left-answers']//LABEL[contains(text(),'" + option + "')]/I")
							.click();
					//driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
				}
				break;
			} else if (option.equalsIgnoreCase("No")) {
				List<WebElement> answers_mul = driver.findElementsByXPath("//DIV[LABEL[contains(text(),'" + qnname
						+ "')]]/DIV/DIV[@class='tds-right-answers']//LABEL[contains(text(),'" + option + "')]/I");
				if (answers_mul.size() > 1) {
					for (WebElement answer : answers_mul) {
						if (answer.isDisplayed()) {
							answer.click();
							//driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
						}
					}

				} else {
					driver.findElementByXPath("//DIV[LABEL[contains(text(),'" + qnname
							+ "')]]/DIV/DIV[@class='tds-right-answers']//LABEL[contains(text(),'" + option + "')]/I")
							.click();
					//driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
				}

				break;
			}
		}
	}

	protected void FATCAoptions(String fieldname, String option, AppiumDriver<?> driver) {
		switch (fieldname) {
		case "Tax":

			driver.findElementByXPath(
					"//*[@id='agreementsFATCAFederalTaxClassification-control']//*[@id='undefined_button']").click();
			//driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
			driver.findElementByXPath("//LI[p[text()='" + option + "']]").click();
			//driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
			break;
		case "Payeecode":
			driver.findElementByXPath("//*[@id='agreementsFATCAExemptPayeeCode-control']//*[@id='undefined_button']")
					.click();
			//driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
			driver.findElementByXPath("//LI[p[text()='" + option + "']]").click();
			//driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
			break;
		case "Exemption":
			driver.findElementByXPath("//*[@id='agreementsFATCAExemptionFromFATCA-control']//*[@id='undefined_button']")
					.click();
			//driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
			driver.findElementByXPath("//LI[p[text()='" + option + "']]").click();
			//driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
			break;
		case "Country":
			driver.findElementByXPath("//*[@id='agreementsFATCACountry-control']//*[@id='undefined_button']").click();
			//driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
			driver.findElementByXPath("//LI[p[text()='" + option + "']]").click();
			//driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
			break;
		

		}
	}
	
	protected void TaxResidency(int number, String countryname, String reason,AppiumDriver<?> driver) {
		switch (number) {
		
		case 1:
			driver.findElementByXPath(
					"//P[contains(@id,'TaxResidencyCountryJurisdiction-control.1')]/A")
					.click();		
			//driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
			driver.findElementByXPath("//LI[p[text()='" + countryname + "']]").click();
			driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
			driver.findElementByXPath(
					"//P[contains(@id,'ReasonForNoTIN-control.1')]/A").click();
			//driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
			driver.findElementByXPath("//LI[p[text()='" + reason + "']]").click();
			//driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
			break;
			
		case 2:
			driver.findElementByXPath(
					"//P[contains(@id,'TaxResidencyCountryJurisdiction-control.2')]/A")
					.click();		
			//driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
			driver.findElementByXPath("//LI[p[text()='" + countryname + "']]").click();
			//driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
			driver.findElementByXPath(
					"//P[contains(@id,'ReasonForNoTIN-control.2')]/A").click();
			//driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
			driver.findElementByXPath("//LI[p[text()='" + reason + "']]").click();
			//driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
			break;
				
		
		}
	
	}	

	protected void FATCAnumber(String fld_name, String fld1, String fld2, String fld3, AppiumDriver<?> driver) {
		switch (fld_name) {
		case "Securitynumber":
			driver.findElementByXPath("//*[@id='section-1.agreementsFATCASocialSecurityNumber']/input[1]")
					.sendKeys(fld1);
			driver.findElementByXPath("//*[@id='section-1.agreementsFATCASocialSecurityNumber']/input[2]")
					.sendKeys(fld2);
			driver.findElementByXPath("//*[@id='section-1.agreementsFATCASocialSecurityNumber']/input[3]")
					.sendKeys(fld3);
			break;

		}

	}

	protected void FATCAnumber(String fld_name, String fld1, String fld2, AppiumDriver<?> driver) {
		switch (fld_name) {

		case "Employernumber":
			driver.findElementByXPath("//*[@id='section-1.agreementsFATCAEmployerIdNumber']/input[1]").sendKeys(fld1);
			driver.findElementByXPath("//*[@id='section-1.agreementsFATCAEmployerIdNumber']/input[2]").sendKeys(fld2);

			break;
		}
	}

	protected static void Datepick(int day, String month, String year, AppiumDriver<?> driver) {
		driver.context("VISUAL");
		
		Set<String> set = new HashSet<String>();
		perfectoCommand.put("content", "PUBLIC:ePOSImageObjects/Calendar.png");
		perfectoCommand.put("timeout", "7");
		perfectoCommand.put("screen.top", "0%");
		perfectoCommand.put("screen.height", "100%");
		perfectoCommand.put("screen.left", "0%");
		perfectoCommand.put("screen.width", "100%");
		driver.executeScript("mobile:image:select", perfectoCommand);
		perfectoCommand.clear();
		
		driver.context("WEBVIEW");
		SetPageContext("WEBVIEW_2", driver);
		//driver.findElementByXPath("//*[@id='BasicSection.personalInfoInsuredDateOfBirth']").click();
		// driver.findElementByXPath(Applyphase.txt_DOB).click();
		// driver.findElementByXPath(Applyphase.btn_Date_Pick).click();
		// driver.findElementByXPath(Applyphase.btn_Dateyear).sendKeys(year);
		// driver.findElementByXPath(Applyphase.btn_Datemonth).sendKeys(month);
		driver.findElementByXPath("//*[@class='ui-datepicker-year']//*[text()='" + year + "']").click();
		driver.findElementByXPath("//*[@class='ui-datepicker-month']//*[text()='" + month + "']").click();
		driver.findElementByXPath("//*[text()=" + day + "]").click();
		try {
			driver.findElementByXPath(Applyphase.txt_Place_Birth).click();
		} catch (Exception ex) {
		}

	}

	protected static void Try_Wait(WebElement element, AppiumDriver<?> driver) {
		for (int i = 0; i < 50; i++) {
			driver.context("WEBVIEW");
			SetPageContext("WEBVIEW_2", driver);
			try {
				if (element.isDisplayed()) {
					break;
				}
			} catch (Exception ex) {
			}
		}
	}

	protected void Proposalbuttonclick(AppiumDriver<?> driver) {
		try {
			textClick("Proposals", 5, driver);
		} catch (Exception ex) {
		}

		try {

			do {
				//Thread.sleep(100);
			} while (driver.findElementByXPath(EposCreateProposalPage.ldg_Create_Prop).isDisplayed());
		} catch (Exception e) {

		}

	}

	protected static void ApplyTakePhoto(AppiumDriver<WebElement> driver) {
		try{
			driver.context("NATIVE_APP");
			
			if(driver.findElementByXPath(Applyphase.btn_OK).isDisplayed()){
				driver.findElementByXPath(Applyphase.btn_OK).click();
				log.info("Entered If");
				
			}
		}catch(Exception ex){}
		driver.context("NATIVE");
		driver.findElementByXPath(Applyphase.btn_Takepic).click();
		log.info("Not entered If");
			
		/*
		try{
			if(driver.findElementByXPath(EposAddFNAPage.btn_OK).isDisplayed()){
				driver.findElementByXPath(EposAddFNAPage.btn_OK).click();
			}
		}catch(Exception ex){}
		*/
		driver.findElementByXPath(Applyphase.btn_Usephoto).click();

	}

	protected void Apply_AddBenificiary(int benif_no, AppiumDriver<?> driver) {

		for (int i = 1; i < benif_no; i++) {
			driver.findElementByXPath("//*[text()='Add Beneficiary']").click();
			//driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		}
	}

	protected void Apply_BenificiaryDetails(String benif_status, String surname, String givenname, String rel,
			String pass_no, String share, String option, int benif_no, AppiumDriver<?> driver) {

		//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		driver.findElementByXPath("//*[@id='solutionInfoNonILASBeneficiaryStatus-control." + benif_no
				+ "']//*[@id='undefined_button'] | //*[@id='solutionInfoILASBeneficiaryStatus-control." + benif_no
				+ "']//*[@id='undefined_button']").click();
		//driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		WebElement e1 = driver.findElementByXPath("//LI[p[text()='" + benif_status + "']]");
		e1.click();
		//driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		driver.findElementByXPath(
				"//*[@id='BeneficiariesSection.solutionInfoNonILASBeneficiariesRepeater." + (benif_no - 1)
						+ ".solutionInfoNonILASBeneficiarySurname'] | //*[@id='BeneficiariesSection.solutionInfoILASBeneficiariesRepeater."
						+ (benif_no - 1) + ".solutionInfoILASBeneficiarySurname']")
				.sendKeys(surname);
		//driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		driver.findElementByXPath(
				"//*[@id='BeneficiariesSection.solutionInfoNonILASBeneficiariesRepeater." + (benif_no - 1)
						+ ".solutionInfoNonILASBeneficiaryGivenName'] | //*[@id='BeneficiariesSection.solutionInfoILASBeneficiariesRepeater."
						+ (benif_no - 1) + ".solutionInfoILASBeneficiaryGivenName']")
				.sendKeys(givenname);
		// textClick(benif_status,5,driver);
		//driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		driver.findElementByXPath(
				"//*[@id='BeneficiariesSection.solutionInfoNonILASBeneficiariesRepeater." + (benif_no - 1)
						+ ".solutionInfoNonILASBeneficiariesIdOrPassportNum'] | //*[@id='BeneficiariesSection.solutionInfoILASBeneficiariesRepeater."
						+ (benif_no - 1) + ".solutionInfoILASBeneficiaryIDNumber']")
				.sendKeys(pass_no);
		driver.findElementByXPath(
				"//*[@id='BeneficiariesSection.solutionInfoNonILASBeneficiariesRepeater." + (benif_no - 1)
						+ ".solutionInfoNonILASBeneficiaryAllocation'] | //*[@id='BeneficiariesSection.solutionInfoILASBeneficiariesRepeater."
						+ (benif_no - 1) + ".solutionInfoILASBeneficiaryAllocationPercentage']")
				.sendKeys(share);
		// driver.findElementByXPath("//*[text()='"+benif_status+"']").click();
		// Benificiary relationship
		driver.findElementByXPath("//*[@id='solutionInfoNonILASBeneficiaryRelationshipToInsured-control." + benif_no
				+ "']//*[@id='undefined_button'] | //*[@id='solutionInfoILASBeneficiaryRelationshipToInsured-control."
				+ benif_no + "']//*[@id='undefined_button']").click();
		//driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		// driver.findElementByXPath("//*[text()='" + rel + "']").click();
		driver.findElementByXPath("//LI[p[text()='" + rel + "']]").click();
		//driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		driver.findElementByXPath("//*[@id='BeneficiariesSection.solutionInfoNonILASBeneficiariesRepeater."
				+ (benif_no - 1) + ".solutionInfoNonILASBeneficiaryYoungerThan']//*[text()='" + option
				+ "']/i[1] | //*[@id='BeneficiariesSection.solutionInfoILASBeneficiariesRepeater." + (benif_no - 1)
				+ ".solutionInfoILASBeneficiaryMinorFlag']//*[text()='" + option + "']/i[1]").click();
		

	}

	protected void Countrycode(String cntry_cde, AppiumDriver<?> driver) {
		switch (cntry_cde) {
		
		default:
			driver.findElementByXPath(EposAddProspectPage.txt_countrycode).click();
			driver.findElementByXPath("//*[text()='" + cntry_cde + "']").click();
			break;
		}
	}

	//@SuppressWarnings("rawtypes")
	protected void ReportGeneration(String Parameter, String Status, String Screenshot, AppiumDriver<?> driver) {
		if (Status.equals("Pass")) {
			log.info(Parameter);
			currentScenario.write(Parameter);
			Assertion hardAssert = new Assertion();
			hardAssert.assertTrue(true);
			if (Screenshot.equals("Yes")) {
				currentScenario.embed(Util.takeScreenshot(driver), "image/png");
			}
		} else if (Status.equals("Fail")) {
			log.error(Parameter);
			currentScenario.write(Parameter);
			Assertion hardAssert = new Assertion();
			hardAssert.assertTrue(false);
		} else {
			log.error(Parameter);
			currentScenario.write(Parameter);
			Assertion hardAssert = new Assertion();
			hardAssert.assertTrue(true);
		}
	}

	protected static void Waitforloading(String object, AppiumDriver<WebElement> driver) {
		driver.context("NATIVE_APP");
		try {
			System.out.println("Trying page loading");
			while (driver.findElementByXPath(object).isDisplayed()) {
				System.out.println("Waiting for page to load");
				PauseScript(4,driver);
			}
		} catch (Exception e) {
			System.out.println("Entered page loading exception");

		}

	}

	//@SuppressWarnings("rawtypes")
	protected Boolean textCheckpoint(final String textToFind, final Integer timeout, AppiumDriver<?> driver) {
		perfectoCommand.put("content", textToFind);
		perfectoCommand.put("timeout", timeout);
		final Object result = driver.executeScript("mobile:checkpoint:text", perfectoCommand);
		final Boolean resultBool = Boolean.valueOf(result.toString());
		perfectoCommand.clear();
		return resultBool;
	}

	protected void Gender_Select(String gender, AppiumDriver<?> driver) {

		switch (gender) {

		case "Male":

			driver.findElementByXPath(EposAddProspectPage.txt_malegender).click();
			break;
		case "Female":

			driver.findElementByXPath(EposAddProspectPage.txt_femmalegender).click();
			break;
		default:
			break;

		}

	}

	protected static void Passwordentry(AppiumDriver<?> driver) {
		WebDriverWait wait=new WebDriverWait(driver, 5);
		try {
			driver.context("WEBVIEW");
			SetPageContext("WEBVIEW_2",driver);
			SetPageContext("WEBVIEW_3",driver);
			if (driver.findElementByXPath(LoginEPOSAppPage.btn_number_1).isDisplayed()) {
				System.out.println("Entered IF of password entry");
				WebElement ele_btn=driver.findElementByXPath(LoginEPOSAppPage.btn_number_1);
				WebElement ele_Chk1=driver.findElementByXPath("//*[@class='grid steps']/div[1]");
				WebElement ele_Chk2=driver.findElementByXPath("//*[@class='grid steps']/div[2]");
				WebElement ele_Chk3=driver.findElementByXPath("//*[@class='grid steps']/div[3]");
				WebElement ele_Chk4=driver.findElementByXPath("//*[@class='grid steps']/div[4]");
				ele_btn.click();   //First number
				
				wait.until(ExpectedConditions.elementToBeClickable(ele_btn));
						
				ele_btn.click();   //First number
				wait.until(ExpectedConditions.elementToBeClickable(ele_btn));
								
				ele_btn.click();    //First number
				
				wait.until(ExpectedConditions.elementToBeClickable(ele_btn));
								
				ele_btn.click();    //First number
								
				
			}
		} catch (Exception e) {
			// do nothing
			System.out.println("Entered exception-Password");

		}

	}

	protected void proposalOccupationClass(String value,AppiumDriver<?> driver){
		
		driver.findElementByXPath("//*[text()='Occupation class']/../TD/INPUT[@value='"+value+"']").click();
		
	}
	
	protected void ApplyAddress(String address, String line1, String line2, String line3, String line4,
			AppiumDriver<?> driver) {

		switch (address) {

		case "Office":
			driver.findElementByXPath(
					"//*[@id='ContactSection.personalInfoPolicyownerInsuredOfficeAddressLine1'] | //*[@id='ContactSection.personalInfoPolicyownerOfficeAddressLine1']")
					.sendKeys(line1);
			driver.findElementByXPath(
					"//*[@id='ContactSection.personalInfoPolicyownerInsuredOfficeAddressLine2'] | //*[@id='ContactSection.personalInfoPolicyownerOfficeAddressLine2']")
					.sendKeys(line2);
			driver.findElementByXPath(
					"//*[@id='ContactSection.personalInfoPolicyownerInsuredOfficeAddressLine3'] | //*[@id='ContactSection.personalInfoPolicyownerOfficeAddressLine3']")
					.sendKeys(line3);
			driver.findElementByXPath(
					"//*[@id='personalInfoPolicyownerInsuredOfficeAddressLine4-control']//*[@id='undefined_button'] | //*[@id='personalInfoPolicyownerOfficeAddressLine4-control']//*[@id='undefined_button']")
					.click();
			driver.findElementByXPath("//LI[p[text()='" + line4 + "']]").click();
			break;
		case "Residence":
			driver.findElementByXPath(
					"//*[@id='ContactSection.personalInfoPolicyownerInsuredResidentialAddressLine1'] | //*[@id='ContactSection.personalInfoPolicyownerResidentialAddressLine1']")
					.sendKeys(line1);
			driver.findElementByXPath(
					"//*[@id='ContactSection.personalInfoPolicyownerInsuredResidentialAddressLine2'] | //*[@id='ContactSection.personalInfoPolicyownerResidentialAddressLine2']")
					.sendKeys(line2);
			driver.findElementByXPath(
					"//*[@id='ContactSection.personalInfoPolicyownerInsuredResidentialAddressLine3'] | //*[@id='ContactSection.personalInfoPolicyownerResidentialAddressLine3']")
					.sendKeys(line3);
			driver.findElementByXPath(
					"//*[@id='ContactSection.personalInfoPolicyownerInsuredResidentialAddressLine-City'] | //*[@id='ContactSection.personalInfoPolicyownerResidentialAddressLine-City']")
					.sendKeys(line4);
			break;
		case "Corresponding":

			driver.findElementByXPath(
					"//*[@id='ContactSection.personalInfoPolicyownerInsuredCorrespondenceAddressLine1'] | //*[@id='ContactSection.personalInfoPolicyownerCorrespondenceAddressLine1']")
					.sendKeys(line1);
			driver.findElementByXPath(
					"//*[@id='ContactSection.personalInfoPolicyownerInsuredCorrespondenceAddressLine2'] | //*[@id='ContactSection.personalInfoPolicyownerCorrespondenceAddressLine2']")
					.sendKeys(line2);
			driver.findElementByXPath(
					"//*[@id='ContactSection.personalInfoPolicyownerInsuredCorrespondenceAddressLine3'] | //*[@id='ContactSection.personalInfoPolicyownerCorrespondenceAddressLine3']")
					.sendKeys(line3);
			driver.findElementByXPath(
					"//*[@id='ContactSection.personalInfoPolicyownerInsuredCorrespondenceAddressLine4'] | //*[@id='ContactSection.personalInfoPolicyownerCorrespondenceAddressLine4']")
					.sendKeys(line4);
			break;
		}

	}

	protected void ApplyAddress(String type, String address, String line1, String line2, String line3, String line4,
			AppiumDriver<?> driver) {
		switch (type) {

		case "Insured":
			if (address == "Office") {
				driver.findElementByXPath("//*[@id='ContactSection.personalInfoInsuredOfficeAddressLine1']")
						.sendKeys(line1);
				driver.findElementByXPath("//*[@id='ContactSection.personalInfoInsuredOfficeAddressLine2']")
						.sendKeys(line2);
				driver.findElementByXPath("//*[@id='ContactSection.personalInfoInsuredOfficeAddressLine3']")
						.sendKeys(line3);
				driver.findElementByXPath(
						"//*[@id='personalInfoInsuredOfficeAddressLine4-control']//*[@id='undefined_button']").click();
				driver.findElementByXPath("//LI[p[text()='" + line4 + "']]").click();
				//driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);

				break;
			} else if (address == "Residence") {
				driver.findElementByXPath("//*[@id='ContactSection.personalInfoInsuredResidentialAddressLine1']")
						.sendKeys(line1);
				driver.findElementByXPath("//*[@id='ContactSection.personalInfoInsuredResidentialAddressLine2']")
						.sendKeys(line2);
				driver.findElementByXPath("//*[@id='ContactSection.personalInfoInsuredResidentialAddressLine3']")
						.sendKeys(line3);
				driver.findElementByXPath(
						"//*[@id='personalInfoInsuredResidentialAddressLine4-control']//*[@id='undefined_button']")
						.click();
				driver.findElementByXPath("//LI[p[text()='" + line4 + "']]").click();
				//driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
				break;

			}
		case "Payor":
			if (address == "Residence") {
				driver.findElementByXPath("//*[@id='ContactSection.personalInfoPayorResidentialAddressLine1']")
						.sendKeys(line1);
				driver.findElementByXPath("//*[@id='ContactSection.personalInfoPayorResidentialAddressLine2']")
						.sendKeys(line2);
				driver.findElementByXPath("//*[@id='ContactSection.personalInfoPayorResidentialAddressLine3']")
						.sendKeys(line3);
				driver.findElementByXPath(
						"//*[@id='personalInfoPayorResidentialAddressLine4-control']//*[@id='undefined_button']")
						.click();
				driver.findElementByXPath("//LI[p[text()='" + line4 + "']]").click();
				//driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
				break;
			}

		}

	}
	
	protected void Changeoccupation(String value_name, AppiumDriver<?> driver) {
		
		driver.findElementByXPath(Applyphase.btn_Changeocc_Ins).click();
		driver.context("WEBVIEW_2");
		SetPageContext("WEBVIEW_3", driver);
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions
				.visibilityOf(driver.findElementByXPath("//*[@class=\"ng-pristine ng-untouched ng-valid\"]")));
		driver.findElementByXPath("//*[@class=\"ng-pristine ng-untouched ng-valid\"]").clear();
		driver.findElementByXPath("//*[@class='search-input']/INPUT").sendKeys(value_name);
		wait.until(
				ExpectedConditions.presenceOfElementLocated(By.xpath("//DIV[contains(text(),'" + value_name + "')]")));
		driver.findElementByXPath("//DIV[contains(text(),'" + value_name + "')]").click();
		driver.context("WEBVIEW");

	}

	
	
	
	protected void Selectvalue(String value_name, AppiumDriver<?> driver) {

		driver.findElementByXPath(Applyphase.btn_Occupation).click();
		driver.context("WEBVIEW_2");
		SetPageContext("WEBVIEW_3", driver);
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions
				.visibilityOf(driver.findElementByXPath("//*[@class=\"ng-pristine ng-untouched ng-valid\"]")));
		// driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElementByXPath("//*[@class=\"ng-pristine ng-untouched ng-valid\"]").sendKeys(value_name);
		// driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		wait.until(
				ExpectedConditions.presenceOfElementLocated(By.xpath("//DIV[contains(text(),'" + value_name + "')]")));
		driver.findElementByXPath("//DIV[contains(text(),'" + value_name + "')]").click();
		driver.context("WEBVIEW");

	}

	protected void Selectvalue(String type, String value_name, AppiumDriver<?> driver) {
		WebDriverWait wait = new WebDriverWait(driver, 60);
		switch (type) {
		case "Insured":

			driver.findElementByXPath(Applyphase.btn_Occupation_Ins).click();
			driver.context("WEBVIEW_2");
			SetPageContext("WEBVIEW_3", driver);

			wait.until(ExpectedConditions
					.visibilityOf(driver.findElementByXPath("//*[@class=\"ng-pristine ng-untouched ng-valid\"]")));

			driver.findElementByXPath("//*[@class=\"ng-pristine ng-untouched ng-valid\"]").sendKeys(value_name);

			wait.until(ExpectedConditions
					.presenceOfElementLocated(By.xpath("//DIV[contains(text(),'" + value_name + "')]")));
			driver.findElementByXPath("//DIV[contains(text(),'" + value_name + "')]").click();
			driver.context("WEBVIEW");
			break;
		case "Payor":
			driver.findElementByXPath(Applyphase.btn_Occupation_Payor).click();
			driver.context("WEBVIEW_2");
			SetPageContext("WEBVIEW_3", driver);

			wait.until(ExpectedConditions
					.visibilityOf(driver.findElementByXPath("//*[@class=\"ng-pristine ng-untouched ng-valid\"]")));

			driver.findElementByXPath("//*[@class=\"ng-pristine ng-untouched ng-valid\"]").sendKeys(value_name);

			wait.until(ExpectedConditions
					.presenceOfElementLocated(By.xpath("//DIV[contains(text(),'" + value_name + "')]")));
			driver.findElementByXPath("//DIV[contains(text(),'" + value_name + "')]").click();
			driver.context("WEBVIEW");
			break;

		}

	}

	protected static void PayorQn(String opt, AppiumDriver<?> driver) {
		driver.findElementByXPath(
				"//*[@id='BasicSection.personalInfoPayorPayorToOwnerFlag']//*[text()='" + opt + "']/i[1]").click();

	}

	protected static void Payorsex(String sex, AppiumDriver<?> driver) {
		driver.findElementByXPath("//*[@id='personalInfoPayorSex-control']//*[@id='undefined_button']").click();
		driver.findElementByXPath("//LI[p[text()='" + sex + "']]").click();

	}

	protected void Apply_CheckBoc(AppiumDriver<?> driver) {
		Map<String, Object> params3 = new HashMap<>();
		params3.put("location", "1386,470");
		Object result3 = driver.executeScript("mobile:touch:tap", params3);
	}

	protected void ApplyYesorNo(String fieldname, String option, AppiumDriver<?> driver) {

		switch (fieldname) {
		case "Senior_Management":
			driver.findElementByXPath(
					"//*[@id='JobAndIncomeSection.personalInfoPolicyownerInsuredManagementFlag']//*[text()='" + option
							+ "']/i[1] | //*[@id='JobAndIncomeSection.personalInfoPolicyownerManagementFlag']//*[text()='"
							+ option + "']/i[1]")
					.click();
			break;
		case "SMS":
			driver.findElementByXPath(
					"//*[@id='ContactSection.personalInfoPolicyownerInsuredSMSApplicationSubmission']//*[text()='"
							+ option
							+ "']/i[1] | //*[@id='ContactSection.personalInfoPolicyownerSMSApplicationSubmission']//*[text()='"
							+ option + "']/i[1]")
					.click();
			break;
		case "Statement":
			driver.findElementByXPath(
					"//*[@id='ContactSection.personalInfoPolicyownerInsuredEStatementFlag']//*[text()='" + option
							+ "']/i[1] | //*[@id='ContactSection.personalInfoPolicyownerEStatementFlag']//*[text()='"
							+ option + "']/i[1]")
					.click();
			break;
		case "Corr_Res":
			driver.findElementByXPath(
					"//*[@id='ContactSection.personalInfoPolicyownerInsuredCorrespondenceAddressFlag']//*[text()='"
							+ option
							+ "']/i[1] | //*[@id='ContactSection.personalInfoPolicyownerCorrespondenceAddressFlag']//*[text()='"
							+ option + "']/i[1]")
					.click();
			break;
		case "Corr_Policy":
			driver.findElementByXPath(
					"//*[@id='ContactSection.personalInfoPolicyownerInsuredAddressOnlyToThisPolicyFlag']//*[text()='"
							+ option
							+ "']/i[1] | //*[@id='ContactSection.personalInfoPolicyownerAddressOnlyToThisPolicyFlag']//*[text()='"
							+ option + "']/i[1]")
					.click();
			break;
		case "Force_Pending":
			driver.findElementByXPath(
					"//*[@id='OtherInformationSection.personalInfoPolicyownerInsuredOtherInsuranceIndicator']//*[text()='"
							+ option
							+ "']/i[1] | //*[@id='OtherInformationSection.personalInfoPolicyownerOtherInsuranceIndicator']//*[text()='"
							+ option + "']/i[1]")
					.click();
			break;

		}

	}

	protected void ApplyYesorNo(String type, String fieldname, String option, AppiumDriver<?> driver) {

		switch (type) {
		case "Insured":
			if (fieldname == "Force_Pending") {
				driver.findElementByXPath(
						"//*[@id='OtherInformationSection.personalInfoInsuredOtherInsuranceIndicator']//*[text()='"
								+ option + "']/i[1]")
						.click();
				break;
			}
			if (fieldname == "Senior_Management") {
				driver.findElementByXPath("//*[@id='JobAndIncomeSection.personalInfoInsuredManagementFlag']//*[text()='"
						+ option + "']/i[1]").click();

				break;
			}
		case "Payor":
			if (fieldname == "Senior_Management") {
				driver.findElementByXPath("//*[@id='JobAndIncomeSection.personalInfoPayorManagementFlag']//*[text()='"
						+ option + "']/i[1]").click();

				break;
			}

		}
	}

	protected void ApplyPolicyYrDate(String option, AppiumDriver<?> driver) {

		driver.findElementByXPath(
				"//*[@id='solutionInfoNonILASInsuredsBasePolicySection.solutionInfoNonILASBackdateIndicator']//*[text()='"
						+ option + "']/i[1]")
				.click();

	}

	protected void Apply_HeightWeight(String type, String measure, String value, AppiumDriver<?> driver) {

		switch (type) {
		case "Height":
			if (measure.equals("cm")) {
				driver.findElementByXPath("//*[text()='cm']//*[@class='dot']").click();
				driver.findElementByXPath("//*[@id='OtherInformationSection.personalInfoPolicyownerInsuredHeightCm']")
						.sendKeys(value);
				break;
			} else if (measure.equals("ft")) {
				driver.findElementByXPath("//*[text()='ft, inch']//*[@class='dot']").click();
				driver.findElementByXPath("//*[@id='OtherInformationSection.personalInfoPolicyownerInsuredHeightFt']")
						.sendKeys(value);
				break;
			}

		case "Weight":
			if (measure.equals("lb")) {
				driver.findElementByXPath("//*[text()='lb']//*[@class='dot']").click();
				driver.findElementByXPath("//*[@id='OtherInformationSection.personalInfoPolicyownerInsuredWeightLb']")
						.sendKeys(value);
				break;

			} else if (measure.equals("kg")) {
				driver.findElementByXPath("//*[text()='kg']//*[@class='dot']").click();
				driver.findElementByXPath("//*[@id='OtherInformationSection.personalInfoPolicyownerInsuredWeightKg']")
						.sendKeys(value);
				break;

			}

		}

	}

	protected void Apply_HeightWeight(String policytype, String type, String measure, String value,
			AppiumDriver<?> driver) {
		switch (policytype) {
		case "Insured":
			if (type.equalsIgnoreCase("Height")) {
				if (measure.equalsIgnoreCase("Cm")) {
					driver.findElementByXPath(
							"//*[@id='OtherInformationSection.personalInfoInsuredHeight']//*[text()='cm']/i[1]")
							.click();
					driver.findElementByXPath("//*[@id='OtherInformationSection.personalInfoInsuredHeightCm']")
							.sendKeys(value);
					break;

				} else if (measure.equalsIgnoreCase("ft")) {
					driver.findElementByXPath(
							"//*[@id='OtherInformationSection.personalInfoInsuredHeight']//*[text()='ft, inch']/i[1]")
							.click();
					driver.findElementByXPath("//*[@id='OtherInformationSection.personalInfoInsuredHeightFt']")
							.sendKeys(value);
					break;
				}

			} else if (type.equalsIgnoreCase("Weight")) {
				if (measure == "lb") {
					driver.findElementByXPath(
							"//*[@id='OtherInformationSection.personalInfoInsuredWeight']//*[text()='lb']/i[1]")
							.click();
					driver.findElementByXPath("//*[@id='OtherInformationSection.personalInfoInsuredWeightLb']")
							.sendKeys(value);
					break;

				} else if (measure.equalsIgnoreCase("kg")) {
					driver.findElementByXPath(
							"//*[@id='OtherInformationSection.personalInfoInsuredWeight']//*[text()='kg']/i[1]")
							.click();
					driver.findElementByXPath("//*[@id='OtherInformationSection.personalInfoInsuredWeightKg']")
							.sendKeys(value);
					break;
				}
			}
		case "Payor":
			if (type.equalsIgnoreCase("Height")) {
				if (measure.equalsIgnoreCase("cm")) {
					driver.findElementByXPath(
							"//*[@id='OtherInformationSection.personalInfoPayorHeight']//*[text()='cm']/i[1]").click();
					driver.findElementByXPath("//*[@id='OtherInformationSection.personalInfoPayorHeightCm']")
							.sendKeys(value);
					break;

				} else if (measure.equalsIgnoreCase("ft")) {
					driver.findElementByXPath(
							"//*[@id='OtherInformationSection.personalInfoPayorHeight']//*[text()='ft, inch']/i[1]")
							.click();
					driver.findElementByXPath("//*[@id='OtherInformationSection.personalInfoPayorHeightFt']")
							.sendKeys(value);
					break;
				}
			} else if (type.equalsIgnoreCase("Weight")) {
				if (measure == "lb") {
					driver.findElementByXPath(
							"//*[@id='OtherInformationSection.personalInfoPayorWeight']//*[text()='lb']/i[1]").click();
					driver.findElementByXPath("//*[@id='OtherInformationSection.personalInfoPayorWeightLb']")
							.sendKeys(value);
					break;

				} else if (measure.equalsIgnoreCase("kg")) {
					driver.findElementByXPath(
							"//*[@id='OtherInformationSection.personalInfoPayorWeight']//*[text()='kg']/i[1]").click();
					driver.findElementByXPath("//*[@id='OtherInformationSection.personalInfoPayorWeightKg']")
							.sendKeys(value);
					break;
				}
			}

		}
	}

	protected void Apply_Smokingfield(String level, AppiumDriver<?> driver) {

		driver.findElementByXPath(
				"//*[@id='personalInfoPolicyownerInsuredSmokingHabitList-control']//*[@id='undefined_button']").click();
		driver.findElementByXPath("//*[text()='" + level + "']").click();

	}

	protected void Apply_Smokingfield(String type, String level, AppiumDriver<?> driver) {
		switch (type) {
		case "Insured":
			driver.findElementByXPath(
					"//*[@id='personalInfoInsuredSmokingHabitList-control']//*[@id='undefined_button']").click();
			driver.findElementByXPath("//LI[p[text()='" + level + "']]").click();
			break;
		case "Payor":
			driver.findElementByXPath("//*[@id='personalInfoPayorSmokingHabitList-control']//*[@id='undefined_button']")
					.click();
			driver.findElementByXPath("//LI[p[text()='" + level + "']]").click();
			break;

		}
	}

	protected void Apply_Language(String field_name, String lang, AppiumDriver<?> driver) {
		switch (field_name) {
		case "Language":
			driver.findElementByXPath(Applyphase.btn_Language).click();
			//driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			WebElement language = driver.findElementByXPath("//LI[p[text()='" + lang + "']]");
			language.click();
			driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			break;
		case "Contract_Lang":
			driver.findElementByXPath(
					"//*[@id='BasicSection.policyContractLanguage" + lang + "CheckBox.item-0']//*[@class='check']")
					.click();
			if (lang.equals("English")) {
				driver.findElementByXPath(
						"//*[@id='BasicSection.policyContractLanguageChineseCheckBox.item-0']//*[@class='check']")
						.click();
			}
			break;
		case "Addr_Lang":
			driver.findElementByXPath(Applyphase.btn_Corr_Adr_Lang).click();
			//driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			WebElement Addlang = driver.findElementByXPath("//LI[p[text()='" + lang + "']]");
			Addlang.click();
			//driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			break;

		}

	}

	protected void Apply_DrinkingfieldNo(String option, AppiumDriver<?> driver) {

		driver.findElementByXPath(
				"//*[@id='OtherInformationSection.personalInfoPolicyownerInsuredDrinkAlcohol']//*[text()='" + option
						+ "']/i[1]")
				.click();

	}

	protected void Apply_DrinkingfieldNo(String type, String option, AppiumDriver<?> driver) {
		switch (type) {
		case "Insured":
			driver.findElementByXPath("//*[@id='OtherInformationSection.personalInfoInsuredDrinkAlcohol']//*[text()='"
					+ option + "']/i[1]").click();
			break;
		case "Payor":
			driver.findElementByXPath(
					"//*[@id='OtherInformationSection.personalInfoPayorDrinkAlcohol']//*[text()='" + option + "']/i[1]")
					.click();
			break;

		}
	}

	protected void Apply_DrinkingfieldYes(String option, String type, AppiumDriver<?> driver) {

		driver.findElementByXPath(
				"//*[@id='OtherInformationSection.personalInfoPolicyownerInsuredDrinkAlcohol']//*[text()='No']/i[1]")
				.click();

	}

	protected void Doc_Selection(String docname, AppiumDriver<?> driver) {

		driver.findElementByXPath(Applyphase.txt_Identity_Doc).click();
		//driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		WebElement doc = driver.findElementByXPath("//*[text()='" + docname + "']");
		doc.click();
		//driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);

	}

	protected void Doc_Selection(String type, String docname, AppiumDriver<?> driver) {
		switch (type) {

		case "Insured":
			driver.findElementByXPath(Applyphase.txt_Identity_Doc_Ins).click();
			//driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			WebElement doc1 = driver.findElementByXPath("//LI[p[text()='" + docname + "']]");
			doc1.click();
			//driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			break;
		case "Payor":
			driver.findElementByXPath(Applyphase.txt_Identity_Doc_Payor).click();
			//driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			WebElement doc2 = driver.findElementByXPath("//LI[p[text()='" + docname + "']]");
			doc2.click();
			//driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			break;
		}
	}

	protected void ApplyCountrySelection(String fieldname, String countryname, AppiumDriver<?> driver) {
		WebDriverWait wait = new WebDriverWait(driver, 15);
		switch (fieldname) {

		case "Place_Birth":

			driver.findElementByXPath(Applyphase.txt_Place_Birth_Cnty).click();
			//driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			// WebElement Placebirth=driver.findElementByXPath("//*[text()='" +
			// countryname + "']");
			WebElement Placebirth = driver.findElementByXPath("//LI[p[text()='" + countryname + "']]");

			// wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[text()='"
			// + countryname + "']")));
			Placebirth.click();

			// driver.findElementByXPath("//*[@class='tds-control tds-button
			// tds-dropdown-button active']").isDisplayed());

			wait.until(ExpectedConditions.presenceOfElementLocated(By
					.xpath("//*[@id='personalInfoPolicyownerInsuredPlaceOfBirthCountry-control']//*[@id='undefined_button'] | //*[@id='personalInfoPolicyownerPlaceOfBirthCountry-control']//*[@id='undefined_button']/LABEL[text()='"
							+ countryname + "']")));
			// driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			break;
		case "Nationality":

			driver.findElementByXPath(Applyphase.btn_nationality).click();
			//driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			// WebElement nationality=driver.findElementByXPath("//p[text()='" +
			// countryname + "']");
			WebElement nationality = driver.findElementByXPath("//LI[p[text()='" + countryname + "']]");
			nationality.click();
			// wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='personalInfoPolicyownerNationality-control']//*[text()='"
			// + countryname + "']")));
			wait.until(ExpectedConditions.presenceOfElementLocated(By
					.xpath("//*[@id='personalInfoPolicyownerInsuredNationality-control']//*[@id='undefined_button'] | //*[@id='personalInfoPolicyownerNationality-control']//*[@id='undefined_button']/LABEL[text()='"
							+ countryname + "']")));
			break;
		case "Country":
			driver.findElementByXPath(Applyphase.btn_Country).click();
			//driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			// WebElement cntry=driver.findElementByXPath("//p[text()='" +
			// countryname + "']");
			WebElement cntry = driver.findElementByXPath("//LI[p[text()='" + countryname + "']]");
			cntry.click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By
					.xpath("//*[@id='personalInfoPolicyownerInsuredResidentialAddressLine4-control']//*[@id='undefined_button'] | //*[@id='personalInfoPolicyownerResidentialAddressLine4-control']//*[@id='undefined_button']/LABEL[text()='"
							+ countryname + "']")));
			// driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			break;

		}
	}

	protected void ApplyCountrySelection(String type, String fieldname, String countryname, AppiumDriver<?> driver) {
		WebDriverWait wait = new WebDriverWait(driver, 15);
		switch (type) {
		case "Insured":

			driver.findElementByXPath(Applyphase.btn_nationality_Ins).click();
			//driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			// WebElement nationality=driver.findElementByXPath("//p[text()='" +
			// countryname + "']");
			WebElement nationality1 = driver.findElementByXPath("//LI[p[text()='" + countryname + "']]");
			nationality1.click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By
					.xpath("//*[@id='personalInfoInsuredNationality-control']//*[@id='undefined_button']/LABEL[text()='"
							+ countryname + "']")));
			break;
		case "Payor":
			driver.findElementByXPath(Applyphase.btn_nationality_Payor).click();
			//driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			// WebElement nationality=driver.findElementByXPath("//p[text()='" +
			// countryname + "']");
			WebElement nationality2 = driver.findElementByXPath("//LI[p[text()='" + countryname + "']]");
			nationality2.click();
			wait.until(ExpectedConditions.presenceOfElementLocated(
					By.xpath("//*[@id='personalInfoPayorNationality-control']//*[@id='undefined_button']/LABEL[text()='"
							+ countryname + "']")));
			break;

		}

	}

	protected void Apply_Select(String field_name, String value, AppiumDriver<?> driver) {

		switch (field_name) {
		case "Language":
			driver.findElementByXPath(Applyphase.btn_Language).click();
			WebElement lang = driver.findElementByXPath("//*[text()='" + value + "']");
			lang.click();
			break;
		case "Policy_Contract":
			break;
		case "Handed":
			driver.findElementByXPath("//*[text()='" + value + "']//*[@class='dot']").click();
			break;
		}
	}

	public static void PauseScript(int How_Long_To_Pause, AppiumDriver<?> driver) {

		// convert to seconds
		How_Long_To_Pause = How_Long_To_Pause * 1000;

		try {
			Thread.sleep(How_Long_To_Pause);
		} catch (final InterruptedException ex) {
			Thread.currentThread().interrupt();
		}

	}

	protected void Touch_Swipe(AppiumDriver<WebElement> driver) {

		Map<String, Object> params1 = new HashMap<>();
		params1.put("location", "1465,324");
		params1.put("operation", "down");
		Object result1 = driver.executeScript("mobile:touch:tap", params1);

		Map<String, Object> params2 = new HashMap<>();
		List<String> coordinates2 = new ArrayList<>();
		coordinates2.add("1327,320");
		coordinates2.add("1289,320");
		params2.put("location", coordinates2);
		params2.put("auxiliary", "notap");
		Object result2 = driver.executeScript("mobile:touch:drag", params2);

		Map<String, Object> params3 = new HashMap<>();
		params3.put("location", "1289,320");
		params3.put("operation", "up");
		Object result3 = driver.executeScript("mobile:touch:tap", params3);

	}

	protected void textClick(final String textToFind, final Integer timeout,
			@SuppressWarnings("rawtypes") AppiumDriver driver) {
		perfectoCommand.put("content", textToFind);
		perfectoCommand.put("timeout", timeout);
		driver.executeScript("mobile:text:select", perfectoCommand);

		perfectoCommand.clear();
	}

	protected void textGoalClick(final String textToFind, final Integer timeout,
			@SuppressWarnings("rawtypes") AppiumDriver driver) {
		perfectoCommand.put("content", textToFind);
		perfectoCommand.put("timeout", timeout);
		driver.executeScript("mobile:text:select", perfectoCommand);

		perfectoCommand.clear();
	}

	protected void visualScrollToClick(final String label, final Integer threshold,
			@SuppressWarnings("rawtypes") AppiumDriver driver) {
		perfectoCommand.put("label", label);
		perfectoCommand.put("threshold", threshold);
		perfectoCommand.put("scrolling", "scroll");
		driver.executeScript("mobile:text:click", perfectoCommand);
		perfectoCommand.clear();
	}

	static Dimension winSize;

	@SuppressWarnings("rawtypes")
	private static int getX(int x, AppiumDriver driver) {
		winSize = driver.manage().window().getSize();
		return (int) ((winSize.width * x) / 100);
	}

	@SuppressWarnings("rawtypes")
	private static int getY(int y, AppiumDriver driver) {
		winSize = driver.manage().window().getSize();
		return (int) ((winSize.height * y) / 100);
	}

	@SuppressWarnings({ "rawtypes" }) // scrolls to bottom of page
	protected static void visualScroll(AppiumDriver driver) {

		int startX = getX(90, driver);
		int endX = getX(92, driver);
		int startY = getY(62, driver);
		int endY = getY(35, driver);
		TouchAction touchAction4 = new TouchAction(driver);
		touchAction4.press(startX, startY).moveTo(endX, endY).release();
		driver.performTouchAction(touchAction4);

	}

	protected static void visualScrollGoalpage(AppiumDriver<WebElement> driver) {

		int startX = getX(650, driver);
		int endX = getX(680, driver);
		int startY = getY(1050, driver);
		int endY = getY(750, driver);
		TouchAction touchAction4 = new TouchAction(driver);
		touchAction4.press(startX, startY).moveTo(endX, endY).release();
		driver.performTouchAction(touchAction4);

	}

	// Scrolls only a smaller portion above
	protected static void visualScrollPage(AppiumDriver<WebElement> driver) {

		int startX = getX(90, driver);
		int endX = getX(92, driver);
		int startY = getY(62, driver);
		int endY = getY(55, driver);
		TouchAction touchAction4 = new TouchAction(driver);
		touchAction4.press(startX, startY).moveTo(endX, endY).release();
		driver.performTouchAction(touchAction4);

	}

	// Scrolls only a little portion above
	protected static void visualScrollPage2(AppiumDriver<WebElement> driver) {

		int startX = getX(90, driver);
		int endX = getX(92, driver);
		int startY = getY(62, driver);
		int endY = getY(58, driver);
		TouchAction touchAction4 = new TouchAction(driver);
		touchAction4.press(startX, startY).moveTo(endX, endY).release();
		driver.performTouchAction(touchAction4);

	}

	@SuppressWarnings({ "rawtypes" }) // scroll from right to left
	protected static void visualScrollright(AppiumDriver driver) {

		int startX = getX(00, driver);
		int endX = getX(92, driver);
		int startY = getY(900, driver);
		int endY = getY(902, driver);
		TouchAction touchAction4 = new TouchAction(driver);
		touchAction4.press(endX, endY).moveTo(startX, startY).release();
		driver.performTouchAction(touchAction4);

	}

	@SuppressWarnings({ "rawtypes" }) // scrolls the left of page to the bottom
	protected static void visualScroll2(AppiumDriver driver) {

		int startX = getX(8, driver);
		int endX = getX(10, driver);
		int startY = getY(62, driver);
		int endY = getY(35, driver);
		TouchAction touchAction4 = new TouchAction(driver);
		touchAction4.press(startX, startY).moveTo(endX, endY).release();
		driver.performTouchAction(touchAction4);
	}

	protected static void Policy_Select(final String policy_name, AppiumDriver<?> driver) {
		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", " Whole-in-One Protector");
		params1.put("scrolling", "scroll");
		params1.put("maxscroll", "10");
		params1.put("next", "SWIPE_LEFT");
		// Object result1 = driver.executeScript("mobile:text:select", params1);
		driver.findElementByName(" Whole-in-One Protector").findElement(By.name("Icon Checkbox Unchecked 28 whi"))
				.click();
	}

	protected static void Advisoroptions(String option, AppiumDriver<?> driver) {
		switch (option) {
		case "option1":
			driver.findElementByXPath(EposAddFNAPage.btn_opt_1).click();

			break;
		case "option2":
			driver.findElementByXPath(EposAddFNAPage.btn_opt_2).click();
			break;
		case "other":
			driver.findElementByXPath(EposAddFNAPage.btn_opt_othr).click();
		}

	}
	
	protected  void Policy_Selector2(AppiumDriver driver,String...Policy_Name){
		WebDriverWait wait=new WebDriverWait(driver, 60);
		int k=9;
		int i=0;
		String Policy_search;
		List<String> Del_Pol_names=new ArrayList<String>();
		//String[] PolicystoreArray=Policy_Name;
	//	Set<String> Pol_names=new HashSet<String>();
		List<String> Pol_names=new ArrayList<String>();
		
		//Pol_names=Arrays.asList(Policy_Name);
		for (int a=0;a<Policy_Name.length;a++){
			Pol_names.add(Policy_Name[a]);
			Collections.sort(Pol_names);
		}
		System.out.println("Total no of policies-"+Pol_names.size());
		System.out.println("Values in array-"+Pol_names);
		
		for(int j=1;j<k;j++){
			
			for (i = 0; i < Pol_names.size(); i++) {
			try {
				Collections.sort(Pol_names);	
				Policy_search=Pol_names.get(i);
				
				
				WebElement ele_Chk_Box = driver.findElementByXPath("//UIATableCell[@name='" + Policy_search + "']//*[@label='Icon Checkbox Unchecked 28 whi']");
				
						//"//UIATableCell[contains(@name,'" + Policy_Name
						//		+ "')]//*[@label='Icon Checkbox Unchecked 28 whi']");

				if (driver.findElementByXPath("//UIATableCell[@name='" + Policy_search + "']//*[@label='Icon Checkbox Unchecked 28 whi']").isDisplayed()) {
					driver.findElementByXPath("//UIATableCell[@name='" + Policy_search + "']//*[@label='Icon Checkbox Unchecked 28 whi']").click();
					
					//Pol_names.remove(Policy_search);
					Del_Pol_names.add(Policy_search);					
					
					wait.until(ExpectedConditions.attributeContains(ele_Chk_Box, "enabled", "true"));
					log.info(Policy_search + " Identified");

				}
			
				}catch(Exception ex){
					//Policy_search=Policy_Name[i];
					//System.out.println("Policy not identified- "+Policy_search);
				}
							
				
		}
			if(Del_Pol_names.size()>0){
			for (int b=0;b<Del_Pol_names.size();b++){
				Pol_names.remove(Del_Pol_names.get(b));
				Collections.sort(Pol_names);
				System.out.println("Values in Polnames="+Pol_names);
				System.out.println("After removing the field size is- "+Pol_names.size());
			}
			}
			if(Pol_names.size()==0){
				System.out.println("All policies clicked");
				break;
			}else{	
			Touch_Swipe(driver);
			//scrollRightToLeft(driver);
			}
		}
		System.out.println("Values in Polnames="+Pol_names);
		//System.out.println("Searching for Policy-"+Policy_search);
	}
	
	
	
	
	protected void Policy_Selector(final String Policy_Name, AppiumDriver<WebElement> driver) throws InterruptedException {
		//int j = 0;
		WebDriverWait wait=new WebDriverWait(driver, 60);
		int k = 0;
		int l = 0;
		int i;
		
		for (i = 0; i < 11; i++) {

			log.info("Value of i-" + Policy_Name + i);

			try {

				WebElement ele_Chk_Box = driver.findElementByXPath("//UIATableCell[@name='" + Policy_Name + "']//*[@label='Icon Checkbox Unchecked 28 whi']");
				
						//"//UIATableCell[contains(@name,'" + Policy_Name
						//		+ "')]//*[@label='Icon Checkbox Unchecked 28 whi']");

				if (ele_Chk_Box.isDisplayed()) {
					ele_Chk_Box.click();
					wait.until(ExpectedConditions.attributeContains(ele_Chk_Box, "enabled", "true"));
					log.info(Policy_Name + " Identified");
					log.info("The value of l is-" + l);
					// To reset swipe back to the starting of page
					if (l > 0) {
						log.info("Value of l- " + l);
						log.info("Swipe to the beginning-" + Policy_Name + l);

						for (int m = 0; m < l; m++) {
							log.info("Swiping for " + m + " th time ");
							TouchAction tAction = new TouchAction(driver);
							tAction.press(700, 341).moveTo(1900, 314).release().perform();

						}

					}
					//driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
					break;

				} else {

					Touch_Swipe(driver);
					//driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);

					l = l + 1;
				}
			} catch (Exception ex) {

				Touch_Swipe(driver);
				//driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);

				l = l + 1;
			}

		}
		// If the function fails to search a particular Policy to swipe back to
		// the starting of page
		if (i > 8)
			;
		{
			for (k = 0; k <= i; k++) {
				TouchAction tAction = new TouchAction(driver);
				tAction.press(700, 341).moveTo(1900, 314).release().perform();

			}
		}
	}

	protected void Addhealthproblem(String healthprob, AppiumDriver<?> driver) {

		driver.findElementByXPath("//SPAN[contains(text(),'Select')]").click();
		driver.context("WEBVIEW_2");
		SetPageContext("WEBVIEW_3", driver);
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.visibilityOf(
				driver.findElementByXPath("//SPAN[contains(text(),'Please search and select the result')]")));
		driver.findElementByXPath("//*[@class='search-input']/input[1]").sendKeys(healthprob);
		driver.findElementByXPath("//*[@class='left-icon unchecked-icon']").click();
		//driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		driver.findElementByXPath("//SPAN/A[contains(text(),'Done')]").click();
		driver.context("WEBVIEW");
		SetPageContext("WEBVIEW_2", driver);
	}

	protected void CustomerClick(final String cust_name, AppiumDriver<?> driver) {
		// Customer Name type-1
		try {
			// if (driver.findElementByXPath("//UIATableCell[@name='" +
			// cust_name + "']/UIAButton[1]").isDisplayed()) {
			// driver.findElementByXPath("//UIATableCell[@name='" + cust_name +
			// "']/UIAButton[1]").click();
			System.out.println(cust_name);
			if (driver.findElementByXPath("//UIATableCell[contains(@name,'" + cust_name + "')]/UIAButton[1]")
					.isDisplayed()) {
				driver.findElementByXPath("//UIATableCell[contains(@name,'" + cust_name + "')]/UIAButton[1]").click();

			}

			else if (driver.findElementByXPath("//UIATableCell/UIAButton[1]").isDisplayed()) {
				driver.findElementByXPath("//UIATableCell/UIAButton[1]").click();
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
			

		}
	}

	protected static void CompropLogin(final String pwd, AppiumDriver<?> driver) {

		driver.context("WEBVIEW");

		// If first time login page is present
		try {
			driver.context("WEBVIEW");
			if (driver.findElementByXPath(EposCreateProposalPage.btn_Crmp_Ok).isDisplayed()) {
				driver.findElementByXPath(EposCreateProposalPage.btn_Crmp_Ok).click();
			}

		} catch (Exception ex) {
		}
		// Entering password
		try {
			if (driver.findElementByXPath(EposCreateProposalPage.txt_Pwd).isDisplayed()) {
				driver.findElementByXPath(EposCreateProposalPage.txt_Pwd).sendKeys(pwd);
				driver.context("WEBVIEW");
				driver.findElement(By.linkText("LOGIN")).click();
			}
		} catch (Exception e) {

		}
		// If force login screen is present
		try {
			driver.context("WEBVIEW");
			if (driver.findElementByXPath(EposCreateProposalPage.btn_Crmp_Ok).isDisplayed()) {
				driver.findElementByXPath(EposCreateProposalPage.btn_Crmp_Ok).click();
			}

		} catch (Exception ex) {
		}

		// If pop-up displays
		try {
			driver.context("NATIVE");
			driver.findElementByXPath(EposCreateProposalPage.btn_Popup).click();
		} catch (Exception ex) {
		}

	}

	protected static void ManutouchKill(AppiumDriver<?> driver) {
		int i = 0;
		do {
			log.info("Loop Started-Do condition");
			try {
				if (driver.findElementByXPath("//*[text()='Manutouch Login']").isDisplayed()) {
					log.info("Loop Started-If condition");
					driver.findElementByXPath("//*[@label='icon close']").click();
					driver.findElementByXPath(EposCreateProposalPage.btn_Create_Proposal).click();
					i = i + 1;
					log.info("Value of i-" + i);
				} else {
					// Do nothing
				}

			} catch (Exception ex) {
			}
		} while (i < 4 || driver.findElementByXPath(EposCreateProposalPage.txt_Pwd).isDisplayed());
		log.info("Loop Exit");
	}

	protected static void Plan_Selector(final String Policy_name, final String Plan_name, AppiumDriver<?> driver) {
		WebDriverWait wait=new WebDriverWait(driver, 60);
		// Plan list box
		
		driver.findElementByXPath("//UIATableCell[contains(@name,'" + Policy_name + "')]//*[@label='Please Select']")
				.click();
		
		driver.findElementByXPath("//UIAStaticText[contains(@label,'" + Plan_name + "')]").click();

		// Plan check box

		WebElement ele_Plan_Chk=driver.findElementByXPath("//UIATableCell[contains(@name,'" + Policy_name + "')]//*[@label='unchecked']");
		ele_Plan_Chk.click();
		//		.click();
		wait.until(ExpectedConditions.attributeContains(ele_Plan_Chk, "value", "1"));

	}
	
	protected static void Plan_Selector2(final String Plan_name, final String Policy_name, AppiumDriver<?> driver) {
		
		WebDriverWait wait=new WebDriverWait(driver, 60);
		// Plan list box
		
		driver.findElementByXPath("//*[@value='"+Policy_name+"']/following-sibling::UIAButton[@label='Please Select']")
				.click();
		
		driver.findElementByXPath("//UIAStaticText[contains(@label,'" + Plan_name + "')]").click();
		// Plan check box
		driver.findElementByXPath("//*[@value='"+Policy_name+"']/following-sibling::UIAButton[@label='unchecked']").click();
		WebElement ele_Plan_Chk=driver.findElementByXPath("//*[@value='"+Policy_name+"']/following-sibling::UIAButton[@label='unchecked']");
		//ele_Plan_Chk.click();
		//		.click();
		wait.until(ExpectedConditions.attributeContains(ele_Plan_Chk, "value", "1"));

	}
	

	protected static void Plan_Selector_Comprop(final String Plan_name, AppiumDriver<?> driver) {
		// Plan list box
		driver.context("WEBVIEW");
		// driver.findElementByXPath("//*[@value='Please Select']").click();
		driver.findElementByXPath("//*[@name='basic_plan']").sendKeys(Plan_name);

		// driver.findElementByXPath("//*[@label='"+Plan_name+"']").click();

	}

	protected static void iOSSwipe(String Policy_Name, AppiumDriver<?> driver) {
		do {

			try {
				driver.findElementByXPath(
						"//UIATableCell[@name='" + Policy_Name + "']//*[@label='Icon Checkbox Unchecked 28 whi']")
						.click();
				break;

			} catch (Exception NoSuchElementException) {
				Dimension dimensions = driver.manage().window().getSize();
				Double screenHeightStart = dimensions.getHeight() * 0.5;
				int scrollStart = screenHeightStart.intValue();
				Double screenHeightEnd = dimensions.getHeight() * 0.2;
				int scrollEnd = screenHeightEnd.intValue();
				driver.swipe(0, scrollStart, 0, scrollEnd, 2000);
			}
		} while (true);
	}

	protected static void HideKeyboard(AppiumDriver driver) {
		Map<String, Object> param = new HashMap<>();
		param.put("keySequence", "HIDE_KEYBOARD ");
		driver.executeScript("mobile:presskey", param);
	}

	protected void Dataselect(String data, AppiumDriver<?> driver) {

		switch (data) {
		case "Mr":
		case "Mrs":
		case "Ms":
		case "Miss":
			driver.findElementByXPath("//*[@label='" + data + "']").click();
			break;
		case "Single":
		case "Married":
		case "Divorce":
		case "Widowed":
			driver.findElementByXPath("//*[@label='" + data + "']").click();
			break;
		case "0":
		case "1":
		case "2":
		case "3":
		case "4":
			driver.findElementByXPath("//*[@label='" + data + "']").click();
			break;

		case "Mobile":
		case "Home":
		case "Office":

			driver.findElementByXPath("//*[@label='" + data + "']").click();
			break;
		case "University or Above":
		case "Post-Secondary/College":
		case "Primary school or below":
		case "Secondary school":
			driver.findElementByXPath("//*[@label='" + data + "']").click();
			break;

		case "Professionals":
			driver.findElementByXPath(EposAddFNAPage.txt_Occupation).click();
			driver.findElementByXPath("//*[@label='" + data + "']").click();
			break;

		}

	}

	protected void Option(String option, AppiumDriver<?> driver) {
		switch (option) {

		case "A":
			driver.findElementByXPath("//UIAButton[contains(@label,'A)')]").click();
			break;
		case "B":
			driver.findElementByXPath("//UIAButton[contains(@label,'B)')]").click();
			break;
		case "C":
			driver.findElementByXPath("//UIAButton[contains(@label,'C)')]").click();
			break;
		case "D":
			driver.findElementByXPath("//UIAButton[contains(@label,'D)')]").click();
			break;
		case "E":
			driver.findElementByXPath("//UIAButton[contains(@label,'E)')]").click();
			break;
		case "F":
			driver.findElementByXPath("//UIAButton[contains(@label,'F)')]").click();
			break;
		}

	}

	protected static void drawLetter(final String letter, AppiumDriver<?> driver) {
		final List<String> coordinates = new ArrayList<>();

		switch (letter) {
		case "A":

			break;
		case "B":

			break;
		case "C":

			break;
		case "D":

			break;
		case "E":
			coordinates.add("42%,40%");
			coordinates.add("42%,60%");
			perfectoCommand.put("location", coordinates);
			driver.executeScript("mobile:touch:drag", perfectoCommand);
			perfectoCommand.clear();
			coordinates.clear();
			coordinates.add("42%,40%");
			coordinates.add("52%,40%");
			perfectoCommand.put("location", coordinates);
			driver.executeScript("mobile:touch:drag", perfectoCommand);
			perfectoCommand.clear();
			coordinates.clear();
			coordinates.add("42%,48%");
			coordinates.add("52%,48%");
			perfectoCommand.put("location", coordinates);
			driver.executeScript("mobile:touch:drag", perfectoCommand);
			perfectoCommand.clear();
			coordinates.clear();
			coordinates.add("42%,56%");
			coordinates.add("52%,56%");
			perfectoCommand.put("location", coordinates);
			driver.executeScript("mobile:touch:drag", perfectoCommand);
			perfectoCommand.clear();
			coordinates.clear();
			break;
		case "F":

			break;
		case "G":

			break;
		case "H":

			break;
		case "I":

			break;
		case "J":

			break;
		case "K":

			break;
		case "L":

			break;
		case "M":

			break;
		case "N":

			break;
		case "O":

			break;
		case "P":
			coordinates.add("30%,40%");
			coordinates.add("30%,60%");
			perfectoCommand.put("location", coordinates);
			driver.executeScript("mobile:touch:drag", perfectoCommand);
			perfectoCommand.clear();
			coordinates.clear();
			coordinates.add("30%,40%");
			coordinates.add("40%,40%");
			perfectoCommand.put("location", coordinates);
			driver.executeScript("mobile:touch:drag", perfectoCommand);
			perfectoCommand.clear();
			coordinates.clear();
			coordinates.add("38%,40%");
			coordinates.add("38%,52%");
			perfectoCommand.put("location", coordinates);
			driver.executeScript("mobile:touch:drag", perfectoCommand);
			perfectoCommand.clear();
			coordinates.clear();
			coordinates.add("38%,48%");
			coordinates.add("28%,48%");
			perfectoCommand.put("location", coordinates);
			driver.executeScript("mobile:touch:drag", perfectoCommand);
			perfectoCommand.clear();
			coordinates.clear();
			break;
		case "Q":

			break;
		case "R":
			coordinates.add("54%,40%");
			coordinates.add("54%,60%");
			perfectoCommand.put("location", coordinates);
			driver.executeScript("mobile:touch:drag", perfectoCommand);
			perfectoCommand.clear();
			coordinates.clear();
			coordinates.add("54%,40%");
			coordinates.add("64%,40%");
			perfectoCommand.put("location", coordinates);
			driver.executeScript("mobile:touch:drag", perfectoCommand);
			perfectoCommand.clear();
			coordinates.clear();
			coordinates.add("62%,40%");
			coordinates.add("62%,52%");
			perfectoCommand.put("location", coordinates);
			driver.executeScript("mobile:touch:drag", perfectoCommand);
			perfectoCommand.clear();
			coordinates.clear();
			coordinates.add("62%,48%");
			coordinates.add("52%,48%");
			perfectoCommand.put("location", coordinates);
			driver.executeScript("mobile:touch:drag", perfectoCommand);
			perfectoCommand.clear();
			coordinates.clear();
			coordinates.add("54%,48%");
			coordinates.add("64%,60%");
			perfectoCommand.put("location", coordinates);
			driver.executeScript("mobile:touch:drag", perfectoCommand);
			perfectoCommand.clear();
			coordinates.clear();
			break;
		case "S":

			break;
		case "T":

			break;
		case "U":

			break;
		case "V":

			break;
		case "W":

			break;
		case "X":

			break;
		case "Y":

			break;
		case "Z":

			break;
		}

	}

	protected void ProposalClick(String Prop_name, AppiumDriver<WebElement> driver) {
		Waitforloading(Applyphase.ele_Ldg_PDF, driver);
		for (int i = 0; i < 8; i++) {
			log.info("entered for");
			try {
				log.info("entered try-" + i);
				driver.context("WEBVIEW");
				if (driver.findElementByXPath("//*[text()='" + Prop_name + "']").isDisplayed()) {
					// if(driver.findElementByXPath("//[contains(text(),'"+Prop_name+"')]").isDisplayed())
					// {

					log.info("entered If");
					driver.findElementByXPath("//*[text()='" + Prop_name + "']").click();

					break;
				}
			} catch (Exception ex) {
				log.info("entered exception" + i);

				visualScroll2(driver);
			}
		}

	}

	protected static void visualScrollleft(AppiumDriver<?> driver) {

		Map<String, Object> params8 = new HashMap<>();
		params8.put("location", "300,1284");
		params8.put("operation", "down");
		Object result8 = driver.executeScript("mobile:touch:tap", params8);

		Map<String, Object> params9 = new HashMap<>();
		List<String> coordinates9 = new ArrayList<>();
		coordinates9.add("256,728");
		params9.put("location", coordinates9);
		params9.put("auxiliary", "notap");
		Object result9 = driver.executeScript("mobile:touch:drag", params9);

		Map<String, Object> params10 = new HashMap<>();
		params10.put("location", "287,656");
		params10.put("operation", "up");
		Object result10 = driver.executeScript("mobile:touch:tap", params10);

		Map<String, Object> params11 = new HashMap<>();
		params11.put("location", "304,1263");
		params11.put("operation", "down");
		Object result11 = driver.executeScript("mobile:touch:tap", params11);

		Map<String, Object> params12 = new HashMap<>();
		List<String> coordinates12 = new ArrayList<>();
		coordinates12.add("325,773");
		coordinates12.add("307,632");
		params12.put("location", coordinates12);
		params12.put("auxiliary", "notap");
		Object result12 = driver.executeScript("mobile:touch:drag", params12);

		Map<String, Object> params13 = new HashMap<>();
		params13.put("location", "307,632");
		params13.put("operation", "up");
		Object result13 = driver.executeScript("mobile:touch:tap", params13);

	}

	/*
	 * protected void signInPdf(String value, String imagepath, AppiumDriver
	 * driver) {
	 * 
	 * int i = 1; while (i < 100) {
	 * 
	 * visualScrollPDF(driver); if (checkImagePDF(driver)) {
	 * imageClick(imagepath, driver); if (checkImagePDF(driver)) {
	 * imageClick(imagepath, driver); } try { drawLetter("P", driver);
	 * PauseScript(2, driver); Map<String, Object> params33 = new HashMap<>();
	 * params33.put("content", "Proceed");
	 * driver.executeScript("mobile:text:select", params33); PauseScript(3,
	 * driver); } catch (Exception e) { System.out.println(
	 * "Supress Error and Proceed"); } if (textCheckpointPDF(value, 5, driver))
	 * { if (checkImagePDF(driver)) { imageClick(imagepath, driver);
	 * drawLetter("P", driver); PauseScript(1, driver); Map<String, Object>
	 * params34 = new HashMap<>(); params34.put("content", "Proceed");
	 * driver.executeScript("mobile:text:select", params34); PauseScript(2,
	 * driver);
	 * 
	 * } else { visualScrollPDF(driver); PauseScript(2, driver); if
	 * (checkImagePDF(driver)) { imageClick(imagepath, driver); drawLetter("P",
	 * driver); PauseScript(3, driver); Map<String, Object> params34 = new
	 * HashMap<>(); params34.put("content", "Proceed");
	 * driver.executeScript("mobile:text:select", params34); PauseScript(2,
	 * driver); } } textClick("Confirm", 5, driver); break; } } i++; } }
	 */
	protected void visualScrollPDF(AppiumDriver<WebElement> driver) {
		int startX = getX(20, driver);
		int endX = getX(22, driver);
		int startY = getY(62, driver);
		int endY = getY(35, driver);
		// TouchAction touchAction4 = new TouchAction(driver.getAppiumDriver());
		TouchAction touchAction4 = new TouchAction(driver);
		touchAction4.press(startX, startY).moveTo(endX, endY).release();
		// driver.getAppiumDriver().performTouchAction(touchAction4);
		driver.performTouchAction(touchAction4);
	}

	protected Boolean textCheckpointPDF(final String textToFind, AppiumDriver<?> driver) {

		perfectoCommand.put("content", textToFind);
		// perfectoCommand.put("threshold", "95");
		perfectoCommand.put("timeout", "10");
		// final Object result =
		// driver.getAppiumDriver().executeScript("mobile:checkpoint:text",
		// perfectoCommand);
		final Object result = driver.executeScript("mobile:checkpoint:text", perfectoCommand);
		final Boolean resultBool = Boolean.valueOf(result.toString());
		perfectoCommand.clear();
		return resultBool;
	}

	private boolean checkImagePDF(AppiumDriver<?> driver) {

		Map<String, Object> params5 = new HashMap<>();
		// params5.put("content", ImageObjects.checkPdfImageNeedle);
		params5.put("timeout", "5");
		params5.put("screen.top", "0%");
		params5.put("screen.height", "100%");
		params5.put("screen.left", "0%");
		params5.put("screen.width", "100%");
		// Object result5 =
		// driver.getAppiumDriver().executeScript("mobile:image:find", params5);
		Object result5 = driver.executeScript("mobile:image:find", params5);
		final Boolean resultBool = Boolean.valueOf(result5.toString());
		
		return resultBool;
	}

	private static boolean checkAgreebutton(AppiumDriver<?> driver) {

		Map<String, Object> params5 = new HashMap<>();
		params5.put("content","PUBLIC:ePOSImageObjects/English.png");
		params5.put("timeout", "5");
		params5.put("screen.top", "0%");
		params5.put("screen.height", "100%");
		params5.put("screen.left", "0%");
		params5.put("screen.width", "100%");
		Object result5 = driver.executeScript("mobile:image:find", params5);
		resultagree = Boolean.valueOf(result5.toString());
		System.out.println("Agree button - "+resultagree);
		return resultagree;
	}

	private static  boolean checkAddprospect(AppiumDriver<?> driver) {

		Map<String, Object> params5 = new HashMap<>();
		params5.put("content","PUBLIC:ePOSImageObjects/Addprospect.png");
		params5.put("timeout", "5");
		params5.put("screen.top", "0%");
		params5.put("screen.height", "100%");
		params5.put("screen.left", "0%");
		params5.put("screen.width", "100%");
		Object result5 = driver.executeScript("mobile:image:find", params5);
		resultprospect = Boolean.valueOf(result5.toString());
		System.out.println("Addprospect button - "+resultprospect);
		return resultprospect;
	}

	
	protected void imageClick(String imagePath, AppiumDriver<?> driver) {
		perfectoCommand.put("content", imagePath);
		perfectoCommand.put("timeout", "5");
		perfectoCommand.put("screen.top", "0%");
		perfectoCommand.put("screen.height", "100%");
		perfectoCommand.put("screen.left", "0%");
		perfectoCommand.put("screen.width", "100%");
		driver.executeScript("mobile:image:select", perfectoCommand);
		perfectoCommand.clear();
		// eAppWait();

	}

	protected void SignAcrossPDF(AppiumDriver<WebElement> driver) {
		WebDriverWait wait = new WebDriverWait(driver, 30);
	
		driver.context("NATIVE_APP");
		driver.findElementByXPath(Applyphase.btn_Next).click();
		//driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		try {
			//driver.context("NATIVE_APP");
			while (driver.findElementByXPath("//*[@label=\"Ok\"]").isDisplayed()) {
				//driver.context("NATIVE_APP");
				
				driver.findElementByXPath("//*[@label=\"Ok\"]").click();
				// driver.findElementByXPath(Applyphase.btn_OK).click();
				
				
				driver.context("NATIVE_APP");
				List<WebElement> sign=driver.findElementsByXPath("//UIAScrollView/UIAStaticText[@label,'Tap to sign here']/preceding-sibling::UIAImage");
				for(WebElement s:sign){
					if(s.isDisplayed()){
					s.click();
					drawLetter("E", driver);
					driver.context("NATIVE_APP");
					driver.findElementByXPath(EposAddProspectPage.btn_confirm).click();
					}
				}
					
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@class='tds-btn-next ng-binding'] | //*[@label='Next']")));
				// SignInPDF(driver);
				
				try{
					if(driver.findElementByXPath(Applyphase.lbl_PDF).isDisplayed()){
						driver.findElementByXPath(Applyphase.btn_Next).click();
					}
				}catch(Exception ex){
					break;
				}
								
			}

		} catch (Exception ex) {
		}

	}
	protected void SignAcrossPDFApply(AppiumDriver<WebElement> driver) {
		WebDriverWait wait = new WebDriverWait(driver, 30);
	
		driver.context("NATIVE_APP");
		driver.findElementByXPath(Applyphase.btn_Next).click();
		//driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		try {
			log.info("Trying OK button is present");
			//driver.context("NATIVE_APP");
			while (driver.findElementByXPath("//*[@label=\"Ok\"]").isDisplayed()) {
				//driver.context("NATIVE_APP");
				
				driver.findElementByXPath("//*[@label=\"Ok\"]").click();
				// driver.findElementByXPath(Applyphase.btn_OK).click();
				
				
				driver.context("NATIVE_APP");
				List<WebElement> sign=driver.findElementsByXPath("//UIAScrollView/UIAStaticText[@label,'Tap to sign here']/preceding-sibling::UIAImage");
				for(WebElement s:sign){
					if(s.isDisplayed()){
					s.click();
					drawLetter("E", driver);
					driver.context("NATIVE_APP");
					driver.findElementByXPath(EposAddProspectPage.btn_confirm).click();
					}
				}
					
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@class='tds-btn-next ng-binding'] | //*[@label='Next']")));
				// SignInPDF(driver);
				
				try{
					if(driver.findElementByXPath(Applyphase.lbl_PDF_Apply).isDisplayed()){
						driver.findElementByXPath(Applyphase.btn_Next).click();
					}
				}catch(Exception ex){
					break;
				}
								
			}

		} catch (Exception ex) {
			log.info("Trying OK button exception");
		}

	}
	protected void SignAcrossDeclrPDF(AppiumDriver<WebElement> driver) {
		WebDriverWait wait = new WebDriverWait(driver, 30);
	
		driver.context("NATIVE_APP");
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Applyphase.btn_SubmitApplication)));
		driver.findElementByXPath(Applyphase.btn_SubmitApplication).click();
		//driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		try {
			//driver.context("NATIVE_APP");
			while (driver.findElementByXPath("//*[@label=\"Ok\"]").isDisplayed()) {
				//driver.context("NATIVE_APP");
				
				driver.findElementByXPath("//*[@label=\"Ok\"]").click();
				// driver.findElementByXPath(Applyphase.btn_OK).click();
				
				
				driver.context("NATIVE_APP");
				List<WebElement> sign=driver.findElementsByXPath("//UIAScrollView/UIAStaticText[@label,'Tap to sign here']/preceding-sibling::UIAImage");
				for(WebElement s:sign){
					if(s.isDisplayed()){
					s.click();
					drawLetter("E", driver);
					driver.context("NATIVE_APP");
					driver.findElementByXPath(EposAddProspectPage.btn_confirm).click();
					}
				}
					
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Applyphase.btn_SubmitApplication)));
				// SignInPDF(driver);
				
				try{
					if (driver.findElementByXPath(Applyphase.lbl_PDF).isDisplayed()) {
						wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Applyphase.btn_SubmitApplication)));
						driver.findElementByXPath(Applyphase.btn_SubmitApplication).click();
					}
				}catch(Exception ex){
					break;}
								
				try{
				if (driver.findElementByXPath(Applyphase.btn_Confirm).isDisplayed()){
					driver.findElementByXPath(Applyphase.btn_Confirm).click();
					break;
				}
				}catch(Exception ex){}
			}

		} catch (Exception ex) {
		}
		Waitforloading(Applyphase.ldg_Gen_PDF,driver);
	}
	
	protected void SignAcrossDeclrPDFApply(AppiumDriver<WebElement> driver) {
		WebDriverWait wait = new WebDriverWait(driver, 30);
	
		driver.context("NATIVE_APP");
		driver.findElementByXPath(Applyphase.btn_SubmitApplication).click();
		//driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		try {
			//driver.context("NATIVE_APP");
			while (driver.findElementByXPath("//*[@label=\"Ok\"]").isDisplayed()) {
				//driver.context("NATIVE_APP");
				
				driver.findElementByXPath("//*[@label=\"Ok\"]").click();
				// driver.findElementByXPath(Applyphase.btn_OK).click();
				
				
				driver.context("NATIVE_APP");
				List<WebElement> sign=driver.findElementsByXPath("//UIAScrollView/UIAStaticText[@label,'Tap to sign here']/preceding-sibling::UIAImage");
				for(WebElement s:sign){
					if(s.isDisplayed()){
					s.click();
					drawLetter("E", driver);
					driver.context("NATIVE_APP");
					driver.findElementByXPath(EposAddProspectPage.btn_confirm).click();
					}
				}
					
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Applyphase.btn_SubmitApplication)));
				// SignInPDF(driver);
				
				try{
					if (driver.findElementByXPath(Applyphase.lbl_PDF).isDisplayed()) {
						driver.findElementByXPath(Applyphase.btn_SubmitApplication).click();
					}
				}catch(Exception ex){
					break;}
								
				try{
				if (driver.findElementByXPath(Applyphase.btn_Confirm).isDisplayed()){
					driver.findElementByXPath(Applyphase.btn_Confirm).click();
					break;
				}
				}catch(Exception ex){}
			}

		} catch (Exception ex) {
		}
		Waitforloading(Applyphase.ldg_Gen_PDF,driver);
	}

	
	
	
	
	protected void SignInPDF(AppiumDriver<?> driver) {

		Map<String, Object> params18 = new HashMap<>();
		params18.put("content", "PUBLIC:ePOSImageObjects/FNASignatureOfApplicant(s).png");
		// params18.put("scrolling", "scroll");
		// params18.put("maxscroll", "5");
		// params18.put("next", "SWIPE_UP");
		Object result18 = driver.executeScript("mobile:image:select", params18);

	}

	protected void ScrollPage(AppiumDriver<WebElement> driver) {
		TouchAction tAction = new TouchAction(driver);
		int startx = driver.findElementByXPath("//*[@id='custid-1']").getLocation().getX();

		int starty = driver.findElementByXPath("//*[@id='custid-1']").getLocation().getY();

		int endx = driver.findElementByXPath("//*[@id='custid-4']").getLocation().getY();

		int endy = driver.findElementByXPath("//*[@id='custid-4']").getLocation().getX();
		System.out.println(startx + " ::::::: " + starty + " ::::::: " + endx + " ::::::: " + endy);

		// First tap on the screen and swipe it right using moveTo function
		tAction.press(startx + 20, +endy + 20).moveTo(endx + 20, starty + 20).release().perform();

		// Second tap on the screen and swipe it left using moveTo function
		// tAction.press(endx+20,endy+20).moveTo(startx+20,starty+20).release().perform();

	}

	// Swipe a page Up little
	protected static void ScrollUp(AppiumDriver<?> driver) {
		Map<String, Object> params = new HashMap<>();
		params.put("start", "50%,80%");
		params.put("end", "50%,40%");
		params.put("duration", "3");
		Object res = driver.executeScript("mobile:touch:swipe", params);
	}

	// Swipe a page Up till the end
	protected static void ScrollAbove(AppiumDriver<?> driver) {
		Map<String, Object> params = new HashMap<>();
		params.put("start", "50%,80%");
		params.put("end", "50%,10%");
		params.put("duration", "3");
		Object res = driver.executeScript("mobile:touch:swipe", params);
	}

	protected void ApplyPhaseQns(String Qnfield, String opt, AppiumDriver<?> driver) {
		switch (Qnfield) {
		case "Wit_Qn":
			driver.findElementByXPath("//*[@id='section-1.advisorStatementAgentFlag']//*[text()='" + opt + "']/i[1]")
					.click();

			break;
		case "Fac_Qn":
			driver.findElementByXPath(
					"//*[@id='section-1.advisorStatementOtherFactorForUWFlag']//*[text()='" + opt + "']/i[1]").click();
			break;

		}

	}

	protected void Comproppassfield(String pwd, AppiumDriver<?> driver) {
		WebDriverWait wait = new WebDriverWait(driver, 60);
		try{
		driver.findElementByXPath(EposCreateProposalPage.txt_Pwd).sendKeys(pwd);
		driver.context("WEBVIEW");
		// driver.findElement(By.linkText("LOGIN")).click();
		driver.findElementByXPath("//DIV/A[contains(text(),'LOGIN')]").click();
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//DIV/A[contains(text(),'LOGIN')]")));
		}catch(Exception ex){}
		//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	}
	
	protected String  Compropisready(AppiumDriver<?> driver){
		
		try{
			driver.context("WEBVIEW");
			if (driver.findElementByXPath("//IMG[contains(@name,'tab1')]").isDisplayed()) {
				comprop="ready";
				return comprop;
			}else{
				 comprop="not ready";
				 return comprop;
			}
		}catch(Exception ex){
			comprop="not ready";
			return comprop;
		}
	}
	
	protected void Comproploggedin(AppiumDriver<?> driver) {
		driver.context("WEBVIEW");
		driver.findElementByXPath(EposCreateProposalPage.btn_Crmp_Ok).click();
		//driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
	}

	protected void Comproppopup(AppiumDriver<?> driver) {
		driver.context("NATIVE_APP");
		driver.findElementByXPath(EposCreateProposalPage.btn_Popup).click();
		//driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);

	}
/*
	protected void CompropLoginTest(final String pwd, AppiumDriver<?> driver) {
		int p = 0; // Variable to check if passord is entered
		
		//proposalBlankPage(driver);	
		for (int i = 1; i < 5; i++) { // Iterating to remove all popups and
										// screens to navigate to comprop screen
			try {
				Compropisready(driver);
				// Commenting as password will not be asked again in comprop
				// login
				
				  if (p != 3) {// If password is not entered once try {
				  
				// Trying if Password field is present
				try{	  
				log.info("Trying password field"); 
				driver.context("WEBVIEW");
				 if(driver.findElementByXPath(EposCreateProposalPage.txt_Pwd).isDisplayed()) {
				  log.info("Entered Password If");
				  Comproppassfield(pwd, driver);
				  p = 3;
				  log.info("Password entered");
				  }
				 
				}catch (Exception ex) { 
				
					
				  } 
				  }
				// Trying if Pop Up is present
				if(comprop=="not ready"){
				try {
					
					log.info("Tried PopUP button");
					driver.context("NATIVE_APP");
					if (driver.findElementByXPath(EposCreateProposalPage.btn_Popup).isDisplayed()) {
						log.info("Entered PopUp IF");
						Comproppopup(driver);
						log.info("Pop-Up clicked");
					}
				} catch (Exception ex) {
					
						log.info("Entered excep of pop-up");
					
				}
				}else{
					//break;
				}
				Compropisready(driver);
				if(comprop=="not ready"){
				// Trying if Already logged-in is present
				try {
					log.info("Tried Already entered button");
					driver.context("WEBVIEW");
					if (driver.findElementByXPath(EposCreateProposalPage.btn_Crmp_Ok).isDisplayed()) {
						log.info("Entered Already logged in If");
						Comproploggedin(driver);
						log.info("Already logged in clicked");
					}
				} catch (Exception ex) {
					
						log.info("Entered excep of already login");
					

				}
				}else{
					//break;
				}
				
				//Agree button is present
				if(i>2){
				
				try {
					log.info("Trying  agree button");
					driver.context("WEBVIEW");
					driver.switchTo().frame(driver.findElementByXPath("//iframe[@id=\"ns_Z7_29061982I86Q30IFHCP5DQ00I6_content-frame\"]"));
					if (driver.findElementByXPath("//*[@name=\"btnAgree\"]").isDisplayed()) {
						log.info("Entered Agree logged in If");
						driver.findElementByXPath("//*[@name=\"btnAgree\"]").click();
						
						driver.findElementByXPath("//*[text()=\"Home\"]").click();
						log.info("Agree logged in clicked");
						driver.switchTo().defaultContent();
					}
				} catch (Exception ex) {
						driver.switchTo().defaultContent();
						log.info("Entered excep  of agree button");
									
				}
								
				}else{
					//break;
				}
			} catch (Exception ex) {

				

			}
			
		} // Iterating 5 times

		}
*/
	
	protected void CompropLoginTest(final String pwd, AppiumDriver driver) {
		int p = 0; // Variable to check if passord is entered
		WebDriverWait wait = new WebDriverWait(driver, 60);
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		for (int i = 1; i < 5; i++) { // Iterating to remove all popups and
										// screens to navigate to comprop screen
			try {
				Compropisready(driver);
				// Commenting as password will not be asked again in comprop
				// login
				
				 if (p != 3) {// If password is not entered once
				try {
				  // Trying if Password field is present
					log.info("Tried password field");
					if (driver.findElementByXPath(EposCreateProposalPage.txt_Pwd).isDisplayed()) {
						log.info("Entered Password If");
				  Comproppassfield(pwd, driver);
				  p = 3; 
				  log.info("Password entered");
				  }
				 } catch (Exception ex) {
					 try {
				if(driver.findElementByXPath("//IMG[contains(@name,'tab1')]").isDisplayed()) {
					break;
					} 
				} catch (Exception ex1) { }
				  
				  } }
				
				// Trying if Pop Up is present
				if(comprop=="not ready"){
				try {
					
					log.info("Tried PopUP button");
					driver.context("NATIVE_APP");
					if (driver.findElementByXPath(EposCreateProposalPage.btn_Popup).isDisplayed()) {
						log.info("Entered PopUp IF");
						Comproppopup(driver);
						log.info("Pop-Up clicked");
					}
				} catch (Exception ex) {
					
						log.info("Entered excep of pop-up");
					
				}
				}else{
					break;
				}
				Compropisready(driver);
				if(comprop=="not ready"){
				// Trying if Already logged-in is present
				try {
					log.info("Tried Already entered button");
					driver.context("WEBVIEW");
					if (driver.findElementByXPath(EposCreateProposalPage.btn_Crmp_Ok).isDisplayed()) {
						log.info("Entered Already logged in If");
						Comproploggedin(driver);
						log.info("Already logged in clicked");
					}
				} catch (Exception ex) {
					
						log.info("Entered excep of already login");
					

				}
				}else{
					break;
				}
				
				//Agree button is present
				if(i>2){
				
				try {
					log.info("Trying  agree button");
					driver.context("WEBVIEW");
					driver.switchTo().frame(driver.findElementByXPath("//iframe[@id=\"ns_Z7_29061982I86Q30IFHCP5DQ00I6_content-frame\"]"));
					if (driver.findElementByXPath("//*[@name=\"btnAgree\"]").isDisplayed()) {
						log.info("Entered Agree logged in If");
						driver.findElementByXPath("//*[@name=\"btnAgree\"]").click();
						driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
						driver.findElementByXPath("//*[text()=\"Home\"]").click();
						log.info("Agree logged in clicked");
						driver.switchTo().defaultContent();
					}
				} catch (Exception ex) {
						driver.switchTo().defaultContent();
						log.info("Entered excep  of agree button");
									
				}
				
				}
				
			} catch (Exception ex) {

				

			}

		} // Iterating 5 times

	}


	
	
	protected void proposalBlankPage(AppiumDriver<?> driver){
	try{	
	
		WebDriverWait wait=new WebDriverWait(driver, 60);
		driver.context("NATIVE_APP");
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(EposCreateProposalPage.btn_Popup)));
					
		}catch(Exception ex){
			System.out.println("Entered exception of blank page proposal");
		}
	}
	

	protected static void SetPageContext(String context, AppiumDriver<?> driver) {
		Set<String> set = new HashSet();
		//driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		set = driver.getContextHandles();
		
		//driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		int abc = set.size();
		log.info(abc);
		for (String handleName : set) {
			log.info(handleName);
			if (handleName.equalsIgnoreCase(context)) {
				driver.context(handleName);
			}
			log.info(handleName);
		}
		log.info("ended code");
	}

	protected static void  Loginlanguage(AppiumDriver<?> driver){
		driver.context("NATIVE");
	WebDriverWait wait=new WebDriverWait(driver, 60);
	System.out.println("Entered English button");
		try {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(LoginEPOSAppPage.btn_Eng_language)));
			if (driver.findElementByXPath(LoginEPOSAppPage.btn_Eng_language).isDisplayed()) {
				driver.findElementByXPath(LoginEPOSAppPage.btn_Eng_language).click();

				Passwordentry(driver);
				Passwordentry(driver);
			}
		} catch (Exception e) {
			// do nothing
		}
		
	}
	
	protected static void  LoginAgree(AppiumDriver<?> driver){
		System.out.println("Entered Agree button");
		driver.context("NATIVE");
		WebDriverWait wait=new WebDriverWait(driver, 60);
		try {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(LoginEPOSAppPage.btn_Eng_Agree)));
			if (driver.findElementByXPath(LoginEPOSAppPage.btn_Eng_Agree).isDisplayed()) {
				driver.findElementByXPath(LoginEPOSAppPage.btn_Eng_Agree).click();
				Passwordentry(driver);
				Passwordentry(driver);
				
			}
		} catch (Exception e) {
			// do nothing
		}
		
	}
	
	protected static void  Customerlistclick(AppiumDriver<?> driver){
		driver.findElementByXPath("//UIAButton[count(//UIAStaticText[@label='Customer List']/preceding-sibling::*[name()='UIAStaticText'])+1]").click();
	}
	
	
	protected static void  Signaddprospect(AppiumDriver<?> driver){
		driver.context("WEBVIEW");
		WebDriverWait wait=new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='agentSignature']/P/IMG")));
		//Customer Signature
		driver.findElementByXPath("//*[@id='customerSignature']/P/IMG").click();
		drawLetter("P", driver);
		driver.context("NATIVE");
		driver.findElementByXPath(EposAddProspectPage.btn_confirm).click();
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(EposAddProspectPage.btn_confirm)));
		driver.context("WEBVIEW");
			
		//Agent Signature
		driver.findElementByXPath("//*[@id='agentSignature']/P/IMG").click();
		drawLetter("P", driver);
		driver.context("NATIVE");
		driver.findElementByXPath(EposAddProspectPage.btn_confirm).click();
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(EposAddProspectPage.btn_confirm)));
	}
	
	protected static void  FNAOptions(String opt_name,String value,AppiumDriver<?> driver){
		driver.context("NATIVE");
		driver.findElementByXPath("//UIAButton[contains(@label,'"+opt_name+")')]/following::UIATextField[1]").clear();
		try{
			if(driver.findElementByXPath(EposAddFNAPage.btn_OK).isDisplayed()){
				driver.findElementByXPath(EposAddFNAPage.btn_OK).click();
				driver.findElementByXPath(EposAddFNAPage.btn_proceed).click();
			}
			}catch(Exception ex){}
		driver.findElementByXPath("//UIAButton[contains(@label,'"+opt_name+")')]/following::UIATextField[1]").clear();    
		driver.findElementByXPath("//UIAButton[contains(@label,'"+opt_name+")')]/following::UIATextField[1]").sendKeys(value);
	}
	
	protected static void Waitforloginpage(AppiumDriver<?> driver){
		
		try{
		
		Visiblelogincheck(driver);			
			
		}catch(Exception ex1){
			System.out.println("Exception of page load");
		}
		PauseScript(2, driver);
		if(resultagree==true){
			Loginlanguage(driver);
			LoginAgree(driver);
		}else if(resultprospect==true){
			log.info("Add prospect displayed");
		}else{
			System.out.println("Add prospect and Agree button not found");
		}
		
}
	
	public static  void Visiblelogincheck(AppiumDriver<?> driver){
		if(checkAgreebutton(driver)||checkAddprospect(driver)){
			PauseScript(1, driver);
			
		}else{
		System.out.println("Waiting for page to load");
		Visiblelogincheck(driver);
		}
	}
	
	protected static void closeApp(AppiumDriver driver, String context, String identifer) {
		if (context.equals("NATIVE_APP")) {
			perfectoCommand.put("identifier", identifer);
			driver.executeScript("mobile:application:close", perfectoCommand);
			perfectoCommand.clear();
		} 
		
	}
	
	protected static void openApp(AppiumDriver driver, String context, String identifer) {
		if (context.equals("NATIVE_APP")) {
			perfectoCommand.put("identifier", identifer);
			driver.executeScript("mobile:application:open", perfectoCommand);
			perfectoCommand.clear();
		} 
		
	}
	 public static String randomString(int len) {
         StringBuilder sb = new StringBuilder(len);
         for (int i = 0; i < len; i++)
                sb.append(AB.charAt(rnd.nextInt(AB.length())));
         String b=sb.toString();
         System.out.println(b);
         return sb.toString();
        
  }
	 
	 protected  static void writePropertiesFile(String label,String name) {
			Properties dataproperties = new Properties();
			String relativePath = new File(System.getProperty("user.dir"))
					.getAbsolutePath();
			relativePath = relativePath + Util.getFileSeparator() + "src"
					+ Util.getFileSeparator() + "test" + Util.getFileSeparator()
					+ "resources";

			try {
				dataproperties.load(new FileInputStream(relativePath
						+ Util.getFileSeparator() + "Global Data.properties"));
				dataproperties.setProperty(label,name);
				FileOutputStream fileOut=new FileOutputStream(relativePath
						+ Util.getFileSeparator() + "Global Data.properties");
				dataproperties.store(fileOut, null);
				fileOut.close();

			    
			} catch (FileNotFoundException e) {
				log.error(e.getMessage());
				e.printStackTrace();
			} catch (IOException e) {
				log.error(e.getMessage());
				e.printStackTrace();
			}

			
		}

	 protected static String readPropertiesFile(String label) {
			Properties dataproperties = new Properties();
			String relativePath = new File(System.getProperty("user.dir"))
					.getAbsolutePath();
			relativePath = relativePath + Util.getFileSeparator() + "src"
					+ Util.getFileSeparator() + "test" + Util.getFileSeparator()
					+ "resources";

			try {
				dataproperties.load(new FileInputStream(relativePath
						+ Util.getFileSeparator() + "Global Data.properties"));
				
				FileOutputStream fileOut=new FileOutputStream(relativePath
						+ Util.getFileSeparator() + "Global Data.properties");
				dataproperties.store(fileOut, null);
				fileOut.close();

			    
			} catch (FileNotFoundException e) {
				log.error(e.getMessage());
				e.printStackTrace();
			} catch (IOException e) {
				log.error(e.getMessage());
				e.printStackTrace();
			}
			
			return dataproperties.getProperty(label);
			
		}
	 protected static void scrollRightToLeft(AppiumDriver driver){
		 	Map<String, Object> params = new HashMap<>();
			params.put("start", "34%,22%");
			params.put("end", "92%,22%");
			params.put("duration", "3");
			Object res = driver.executeScript("mobile:touch:swipe", params);
	 }
	protected static void proposalBasicNav(WebElement wb, AppiumDriver driver ) {
		int basicCount=0;
		int basicVisible=0;
		int basicExceptionCount=0;
		try{
			wb.click();
			basicCount=basicCount+1;
			try {
				driver.context("NATIVE");
				driver.findElementByXPath(EposCreateProposalPage.btn_Popup).click();
			} catch (Exception ex) {
			}
			driver.context("WEBVIEW");
			WebElement wb_check=driver.findElementByXPath("//*[@name='basic_plan']");
			if(wb_check.isDisplayed()){
				basicVisible=basicVisible+1;
				log.info("Navigated to basic tab in Proposal page");
			}
		}catch(Exception ex){
			basicExceptionCount=basicExceptionCount+1;
			log.info("Exception of proposal tabs");
			
		}
		finally{
			if(basicCount<4 && basicVisible!=1 && basicExceptionCount<4){
			proposalBasicNav(wb,driver);
			}
		}
		
	}
	 
protected static void proposalSuppNav(WebElement wb, AppiumDriver driver ) {
	int suppCount=0;
	int suppVisible=0;
	int suppExceptionCount=0;
		try{
			wb.click();
			suppCount=suppCount+1;
			WebElement wb_check=driver.findElementByXPath(EposCreateProposalPage.lbl_Prot_Amt);
			if(wb_check.isDisplayed()){
				suppVisible=suppVisible+1;
				log.info("Navigated to Supplementary tab in Proposal page");
			}
		}catch(Exception ex){
			suppExceptionCount=suppExceptionCount+1;
			log.info("Exception of proposal tabs");
			
		}
		finally{
			if(suppCount<4 && suppVisible!=1 &&suppExceptionCount<4 ){
				proposalSuppNav(wb,driver);
		}
		}
	}
	 
protected static void underwritingSummaryClick(WebElement wb, AppiumDriver driver ) {
	int uvClickCount=0;
	int proceedVisible=0;
	int uvExceptionCount=0;
		try{
			wb.click();
			uvClickCount=uvClickCount+1;
			Waitforloading(Applyphase.ldg_Gen_Results, driver);
			driver.context("NATIVE_APP");
			WebElement wb_check=driver.findElementByXPath("//UIAButton[contains(@label,'PROCEED')] | //UIAButton[contains(@label,'Proceed')]");
			if(wb_check.isDisplayed()){
				proceedVisible=proceedVisible+1;
				log.info("Successfully generated underwriting");
			}
		}catch(Exception ex){
			uvExceptionCount=uvExceptionCount+1;
			log.info("Exception of underwriting page");
			
		}
		finally{
			if(uvClickCount<4 && proceedVisible!=1 && uvExceptionCount<4){
				underwritingSummaryClick(wb,driver);
		}
		}
	
}
}