package com.CucumberCraft.stepDefinitions;

import java.util.concurrent.TimeUnit;

import com.CucumberCraft.pageObjects.Eposgoals;
import com.CucumberCraft.supportLibraries.DriverManager;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.AppiumDriver;

public class EPOSRevisitGoals extends MasterStepDefs{
	AppiumDriver driver=DriverManager.getDriver();
	
	@When("^I will click \\+ in the \"([^\"]*)\"$")
	public void i_will_click_in_the(String arg1) throws Throwable {
	
		
		// Write code here that turns the phrase above into concrete actions
	}

	@When("^I will enter \"([^\"]*)\"$")
	public void i_will_enter(String arg1) throws Throwable {
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		GoalNewText(arg1,driver);
	   
	}



	@Then("^I will click on navigation button in Your Savings section$")
	public void i_will_click_on_navigation_button_in_Your_Savings_section() throws Throwable {
	    driver.findElementByXPath(Eposgoals.btn_Navigate).click();
	   
	}

	@Then("^I will click on navigation button in Your Target section$")
	public void i_will_click_on_navigation_button_in_Your_Target_section() throws Throwable {
		driver.findElementByXPath(Eposgoals.btn_Navigate).click();
	   
	}

	@Then("^I will be navigated to Analysis page$")
	public void i_will_be_navigated_to_Analysis_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}





	@Then("^I will check \"([^\"]*)\"$")
	public void i_will_check(String arg1) throws Throwable {
		
		Click_Goal(arg1,driver);
	   
	}

	

	@Then("^I will be navigated to FNA page$")
	public void i_will_be_navigated_to_FNA_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}


}
