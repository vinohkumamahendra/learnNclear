package com.CucumberCraft.stepDefinitions;
/*
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;

import com.CucumberCraft.pageObjects.LoginPage;
import com.CucumberCraft.pageObjects.SettingsPage;
import com.CucumberCraft.supportLibraries.DriverManager;
import com.CucumberCraft.supportLibraries.MobileExecutionPlatform;
import com.CucumberCraft.supportLibraries.ReusableMethods;
import com.CucumberCraft.supportLibraries.Util;
import com.CucumberCraft.supportLibraries.WebDriverUtil;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import io.appium.java_client.AppiumDriver;

public class Settings extends MasterStepDefs {
	private LoginPage loginPage;
	private WebDriverUtil webDriverUtil;

	static Logger log = Logger.getLogger(Steps.class);
	@SuppressWarnings("rawtypes")
	AppiumDriver driver = DriverManager.getDriver();

	@SuppressWarnings("rawtypes")
	@And("^I Change email address \"([^\"]*)\" and password \"([^\"]*)\"$")
	public void changeemailaddrs(String newEmailaddrs, String passwrd) {
		log.info("Settings Page to change email address");
		currentScenario.write("Settings Page to change email address");
		currentScenario.embed(Util.takeScreenshot(driver), "image/png");

		if (currentTestParameters.getMobileExecutionPlatform().equals(MobileExecutionPlatform.ANDROID)) {
			// Android Scripting

		} else {
			String SucessEmailMsg = "";
			try {
				// Click on the Change email address
				driver.findElement(By.xpath(SettingsPage.iOSChangemailMpg)).click();
				if (driver.findElement(By.xpath(SettingsPage.iOSChangemailNewEmail)).isDisplayed())
					driver.findElement(By.xpath(SettingsPage.iOSChangemailNewEmail)).sendKeys(newEmailaddrs);
				driver.findElement(By.xpath(SettingsPage.iOSChangemailpswd)).click();
				driver.findElement(By.xpath(SettingsPage.iOSChangemailpswd)).sendKeys(passwrd);
				driver.findElement(By.xpath(SettingsPage.iOSChangsubmit)).click();
				try {
					driver.context("NATIVE");
					if (driver.findElement(By.xpath(SettingsPage.iOSChangeEmailConfMsg)).isDisplayed())
						currentScenario.write("Change Email Address Confirmation pop up displayed");
					driver.findElement(By.xpath(SettingsPage.iOSChangeEmailConfbt)).click();
					if (driver.findElement(By.xpath(SettingsPage.iOSChangeEmailSuccessful)).isDisplayed())
						SucessEmailMsg = driver.findElement(By.xpath(SettingsPage.iOSChangeEmailSuccessful))
								.getAttribute("label");
					System.out.println(SucessEmailMsg);
					log.info("Email address changed succesfully pop up displayed App message - " + SucessEmailMsg);
					currentScenario.write("Email address changed succesfully pop up displayed App message - " + SucessEmailMsg);
					currentScenario.embed(Util.takeScreenshot(driver), "image/png");
					driver.findElement(By.xpath(SettingsPage.iOSChangeEmailclose)).click();
				} catch (Exception ex) {
					if (driver.findElement(By.xpath(SettingsPage.iOSChangeEmailError)).isDisplayed())
						log.error("Error while changing Email address");
						currentScenario.write("Error while changing Email address");
						currentScenario.embed(Util.takeScreenshot(driver), "image/png");
						driver.findElement(By.xpath(SettingsPage.iOSChangeEmailOKbt)).click();
				}

			} catch (Exception ex) {
				log.error("Unable to change the email address" + ex);
				currentScenario.write("Unable to change the email address");
				currentScenario.embed(Util.takeScreenshot(driver), "image/png");
			}

		}
	}

	@SuppressWarnings("rawtypes")
	@And("^I Change existing password \"([^\"]*)\" and new password \"([^\"]*)\"$")
	public void changepassword(String existingpswd, String newpswd) {
		driver.context("WEB_VIEW");
		log.info("Settings Page to change password");
		currentScenario.write("Settings Page to change password");
		currentScenario.embed(Util.takeScreenshot(driver), "image/png");

		if (currentTestParameters.getMobileExecutionPlatform().equals(MobileExecutionPlatform.ANDROID)) {
			// Android Scripting

		} else {
			String SucessMsg = "";
			try {
				// Click on the Change email address
				driver.findElement(By.xpath(SettingsPage.iOSChangepswdMpg)).click();
				if (driver.findElement(By.xpath(SettingsPage.iOSChangepswdcurrpswd)).isDisplayed())
				driver.findElement(By.xpath(SettingsPage.iOSChangepswdcurrpswd)).sendKeys(existingpswd);
				driver.findElement(By.xpath(SettingsPage.iOSChangeNewpswd)).click();
				driver.findElement(By.xpath(SettingsPage.iOSChangeNewpswd)).sendKeys(newpswd);
				driver.findElement(By.xpath(SettingsPage.iOSChangepswdConfirmpswd)).click();
				driver.findElement(By.xpath(SettingsPage.iOSChangepswdConfirmpswd)).sendKeys(newpswd);
				driver.findElement(By.xpath(SettingsPage.iOSChangpwsdSubmit)).click();
				try {
					driver.context("NATIVE");
					if (driver.findElement(By.xpath(SettingsPage.iOSChangpwsdConfirmMsg)).isDisplayed())
						currentScenario.write("Change password Confirmation pop up displayed");
					driver.findElement(By.xpath(SettingsPage.iOSChangepwsdConfbt)).click();
					if (driver.findElement(By.xpath(SettingsPage.iOSChangepwsdSuccessful)).isDisplayed())
						SucessMsg = driver.findElement(By.xpath(SettingsPage.iOSChangepwsdSuccessful))
								.getAttribute("label");
					System.out.println(SucessMsg);
					log.info("Password Changed Succesfully - Msg from Page" + SucessMsg);
					currentScenario.write("Password Changed Succesfully - Msg from Page" + SucessMsg);
					currentScenario.embed(Util.takeScreenshot(driver), "image/png");
					driver.findElement(By.xpath(SettingsPage.iOSChangepwsdclose)).click();
				} catch (Exception ex) {
					driver.context("NATIVE");
					if (driver.findElement(By.xpath(SettingsPage.iOSChangepwsdError)).isDisplayed())
						;
					System.out.println("Error changing password");
					log.error("Error while changing password");
					currentScenario.write("Error while changing password");
					currentScenario.embed(Util.takeScreenshot(driver), "image/png");
					driver.findElement(By.xpath(SettingsPage.iOSChangepwsdOKbt)).click();
				}
			} catch (Exception ex) {
				log.error("Unable to change the password" + ex);
				currentScenario.write("Unable to change the password");
				currentScenario.embed(Util.takeScreenshot(driver), "image/png");
			}

		}
	}

	@SuppressWarnings("rawtypes")
	@And("^Validate Terms Of Use Content$")
	public void termsofuse() {
		driver.context("WEB_VIEW");
		log.info("Settings Page -  About Term of Use");
		currentScenario.write("Settings Page -  About Term of Use");
		currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		if (currentTestParameters.getMobileExecutionPlatform().equals(MobileExecutionPlatform.ANDROID)) {
			// Android Scripting

		} else {
			try {
				if (driver.findElement(By.xpath(SettingsPage.iOSPrivacyPolicyLnk)).isDisplayed()) {
					Map<String, Object> params1 = new HashMap<>();
					params1.put("content", "Term Of Use");
					params1.put("scrolling", "scroll");
					params1.put("maxscroll", "1");
					params1.put("next", "SWIPE_UP");
					Object result1 = driver.executeScript("mobile:text:select", params1);
				} else {
					driver.findElement(By.xpath(SettingsPage.iOStermsofuseLnk)).click();
					if (driver.findElement(By.xpath(SettingsPage.iOStermsofuseBrowser)).isDisplayed())
						;
					log.info("Manulife MOVE Mobile App in Term Of Use");
					currentScenario.write("Manulife MOVE Mobile App in Term Of Use");
					currentScenario.embed(Util.takeScreenshot(driver), "image/png");
					// driver.findElement(By.xpath(SettingsPage.iOStermsofuseBrowserDone)).click();
				}
			} catch (Exception ex) {
				log.error("Unable to view Terms of Use" + ex);
				currentScenario.write("Unable to view Terms of Use");
				currentScenario.embed(Util.takeScreenshot(driver), "image/png");
			}
		}
	}

	@SuppressWarnings("rawtypes")
	@And("^Validate Privacy Policy Content$")
	public void Privacypolicy() {
		driver.context("WEB_VIEW");
		log.info("Settings Page -  Privacy Policy");
		currentScenario.write("Settings Page -  Privacy Policy");
		currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		if (currentTestParameters.getMobileExecutionPlatform().equals(MobileExecutionPlatform.ANDROID)) {
			// Android Scripting

		} else {
			try {
				if (driver.findElement(By.xpath(SettingsPage.iOSPrivacyPolicyLnk)).isDisplayed()) {
					Map<String, Object> params2 = new HashMap<>();
					params2.put("content", "Privacy Policy");
					params2.put("scrolling", "scroll");
					params2.put("maxscroll", "1");
					params2.put("next", "SWIPE_UP");
					Object result2 = driver.executeScript("mobile:text:select", params2);
				} else {
					driver.findElement(By.xpath(SettingsPage.iOSPrivacyPolicyLnk)).click();
					if (driver.findElement(By.xpath(SettingsPage.iOSPrivacyPolicyBrowser)).isDisplayed())
						;
					log.info("Manulife MOVE Mobile App in Privacy Policy");
					currentScenario.write("Manulife MOVE Mobile App in Privacy Policy");
					currentScenario.embed(Util.takeScreenshot(driver), "image/png");
					// driver.findElement(By.xpath(SettingsPage.iOSPrivacyPolicyBrowserDone)).click();
				}
			} catch (Exception ex) {
				log.error("Unable to view Privacy Policy" + ex);
				currentScenario.write("Unable to view Privacy Policy");
				currentScenario.embed(Util.takeScreenshot(driver), "image/png");
			}
		}
	}

	@And("^I Want to use MOVE Key \"([^\"]*)\" and DOB Month\"([^\"]*)\" Date\"([^\"]*)\" Year\"([^\"]*)\"$")
	public void MoveKey(String Movekey, String DOBMonth, String DOBDate, String DOBYr) {

		driver.context("WEB_VIEW");
		log.info("Settings Page - Use your MOVE Key");
		currentScenario.write("Settings Page -  Privacy Policy");
		currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		if (currentTestParameters.getMobileExecutionPlatform().equals(MobileExecutionPlatform.ANDROID)) {
			// Android Scripting

		} else {
			try {
				if (driver.findElement(By.xpath(SettingsPage.iOSMovekeylnk)).isDisplayed())
					driver.findElement(By.xpath(SettingsPage.iOSMovekeylnk)).click();
				if (driver.findElement(By.xpath(SettingsPage.iOSMovekeyMsg)).isDisplayed())
					log.info("Manulife MOVE Mobile App in MOVE Key Screen");
				currentScenario.write("Manulife MOVE Mobile App in MOVE Key Screen");
				currentScenario.embed(Util.takeScreenshot(driver), "image/png");
				driver.findElement(By.xpath(SettingsPage.iOSMovekey)).sendKeys(Movekey);
				driver.findElement(By.xpath(SettingsPage.iOSmoveDOBDrpdwn)).click();
				ReusableMethods.selectDateiOS(driver, new String[] { DOBMonth, DOBDate, DOBYr });
				log.info("Data entered in MOVE key Page");
				currentScenario.write("Data entered in MOVE key Page");
				currentScenario.embed(Util.takeScreenshot(driver), "image/png");
				driver.findElement(By.xpath(SettingsPage.iOSMovekeyunlock)).click();

			} catch (Exception ex) {
				log.error("Unable to view Enter MOVE key Page" + ex);
				currentScenario.write("Unable to view Enter MOVE key Page");
				currentScenario.embed(Util.takeScreenshot(driver), "image/png");
			}
		}
	}

	@Then("^Change the Language to Chinese$")
	public void ChangelangChinese() {
		driver.context("WEB_VIEW");
		log.info("Settings Page - Change Language to Chinese from English");
		currentScenario.write("Settings Page - Change Language to Chinese  from English");
		currentScenario.embed(Util.takeScreenshot(driver), "image/png");

		if (currentTestParameters.getMobileExecutionPlatform().equals(MobileExecutionPlatform.ANDROID)) {
			// Android Scripting

		} else {
			try {
				if (driver.findElement(By.xpath(SettingsPage.iOSChnageLanginChinese)).isDisplayed())
					driver.findElement(By.xpath(SettingsPage.iOSChnageLanginChinese)).click();
				log.info("Change Language to Chinese POP up ");
				currentScenario.write("Change Language to Chinese POP up ");
				currentScenario.embed(Util.takeScreenshot(driver), "image/png");
				driver.context("NATIVE_APP");
				driver.findElementByXPath(SettingsPage.iOSChangeTraditionalChinese).click();
				driver.context("WEB_VIEW");
				log.info("Language Changed in Settings Page");
				currentScenario.write("Language Changed in Settings Page");
				currentScenario.embed(Util.takeScreenshot(driver), "image/png");
			} catch (Exception ex) {
				log.error("Unable to Change Language to Chinese" + ex);
				currentScenario.write("Unable to Change Language to Chinese");
				currentScenario.embed(Util.takeScreenshot(driver), "image/png");
			}
		}
	}

	@Then("^Change the Language to English$")
	public void ChangelangEnglish() {
		driver.context("WEB_VIEW");
		log.info("Settings Page - Change Language to English from Chinese");
		currentScenario.write("Settings Page - Change Language to English  from Chinese");
		currentScenario.embed(Util.takeScreenshot(driver), "image/png");

		if (currentTestParameters.getMobileExecutionPlatform().equals(MobileExecutionPlatform.ANDROID)) {
			// Android Scripting

		} else {
			try {
				if (driver.findElement(By.xpath(SettingsPage.iOSChangeLangMpg)).isDisplayed())
					driver.findElement(By.xpath(SettingsPage.iOSChangeLangMpg)).click();
				log.info("Change Language to English POP up ");
				currentScenario.write("Change Language to English POP up ");
				currentScenario.embed(Util.takeScreenshot(driver), "image/png");
				driver.context("NATIVE_APP");
				driver.findElementByXPath(SettingsPage.iOSChangeLangEnglish).click();
				driver.context("WEB_VIEW");
				log.info("Language Changed in Settings Page");
				currentScenario.write("Language Changed in Settings Page");
				currentScenario.embed(Util.takeScreenshot(driver), "image/png");
			} catch (Exception ex) {
				log.error("Unable to Change Language to English" + ex);
				currentScenario.write("Unable to Change Language to English");
				currentScenario.embed(Util.takeScreenshot(driver), "image/png");
			}
		}
	}

}
*/