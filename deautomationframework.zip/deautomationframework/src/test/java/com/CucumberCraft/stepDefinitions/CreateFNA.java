package com.CucumberCraft.stepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

import com.CucumberCraft.pageObjects.EposAddFNAPage;
import com.CucumberCraft.supportLibraries.DriverManager;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import io.appium.java_client.AppiumDriver;

public class CreateFNA extends MasterStepDefs {
	AppiumDriver driver=DriverManager.getDriver();
	public String temprider1,temprider2,temprider3,temprider4,temprider5,temprider6,temprider7,temprider8,temprider9;

	
	
	@Given("^I am in FNA page$")
	public void i_am_in_FNA_page() throws Throwable {
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Given("^I will click on OK in the pop up$")
	public void i_will_click_on_OK_in_the_pop_up() throws Throwable {
		driver.context("NATIVE");
		driver.findElementByXPath(EposAddFNAPage.btn_OK).click();
	    
	}
	
	@Given("^enter Insured issue age as \"([^\"]*)\"$")
	public void enter_Insured_issue_age_as(String issue_age) throws Throwable {
		driver.findElementByXPath(EposAddFNAPage.txt_Iss_Age).clear();
		driver.findElementByXPath(EposAddFNAPage.txt_Iss_Age).sendKeys(issue_age);
		HideKeyboard(driver);
	}

	
	
	@Given("^enter Age as \"([^\"]*)\" and Insured issue age as \"([^\"]*)\"$")
	public void enter_Age_as_and_Insured_issue_age_as(String age, String issue_age) throws Throwable {

		driver.findElementByXPath(EposAddFNAPage.txt_Age).clear();
		driver.findElementByXPath(EposAddFNAPage.txt_Age).sendKeys(age);
		HideKeyboard(driver);
		driver.findElementByXPath(EposAddFNAPage.txt_Iss_Age).clear();
		driver.findElementByXPath(EposAddFNAPage.txt_Iss_Age).sendKeys(issue_age);
		HideKeyboard(driver);
	    
	}
	@Given("^select Salutation as \"([^\"]*)\" Number of dependents as \"([^\"]*)\"  Marital Status as \"([^\"]*)\"$")
	public void select_Salutation_as_Number_of_dependents_as_Marital_Status_as(String salutation, String no_dep, String marital_status) throws Throwable {
	
		Dataselect(salutation, driver);

		Dataselect(no_dep, driver);
		Dataselect(marital_status, driver);

	}

	
	
	@Then("^click on buying tab and select option \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
	public void click_on_buying_tab_and_select_option_and(String opt1, String opt2, String opt3, String opt4, String opt5) throws Throwable {
		
		driver.findElement(By.name("Buying Objectives")).click();

		// To click options
		Option(opt1, driver);

		Option(opt2, driver);

		Option(opt3, driver);
		Option(opt4, driver);

	    
	}

	@Then("^enter value \"([^\"]*)\" in option A for ARI-FNA$")
	public void enter_value_in_option_A_for_ARI_FNA(String amt_A) throws Throwable {
		driver.findElementByXPath(EposAddFNAPage.txt_tgt_fld1).clear();
		
		driver.findElementByXPath(EposAddFNAPage.txt_tgt_fld1).sendKeys(amt_A);
		HideKeyboard(driver);
		
	}
	
	@Then("^enter value \"([^\"]*)\" in option E for ARI-FNA$")
	public void enter_value_in_option_E_for_ARI_FNA(String amt_E) throws Throwable {
		driver.findElementByXPath(EposAddFNAPage.txt_tgt_fld2).clear();
		
		driver.findElementByXPath(EposAddFNAPage.txt_tgt_fld2).sendKeys(amt_E);
		HideKeyboard(driver);
	}

	
	
	@Then("^click on Type of Insurance product tab and select option \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\"$")
	public void click_on_Type_of_Insurance_product_tab_and_select_option_and(String opt1, String opt2, String opt3) throws Throwable {
		driver.findElement(By.name("Type of Insurance Product")).click();

		Option(opt1, driver);

		Option(opt2, driver);

		Option(opt3, driver);
	}

	@Then("^click on Type of Insurance product tab and select option \"([^\"]*)\"$")
	public void click_on_Type_of_Insurance_product_tab_and_select_option(String option1) throws Throwable {
		driver.findElement(By.name("Type of Insurance Product")).click();

		Option(option1, driver);

	}

	
	@Then("^select option \"([^\"]*)\" and \"([^\"]*)\" in Accumulative Amount of Liquid Assets and  enter amount as \"([^\"]*)\"$")
	public void select_option_and_in_Accumulative_Amount_of_Liquid_Assets_and_enter_amount_as(String opt1, String opt2, String amt) throws Throwable {
		
	driver.findElement(By.name("Cumulative Liquid Assets")).click();
		
		
		if(driver.findElementByXPath("//UIAStaticText[contains(@label,'4.3 Accumulative Amount of Liquid Assets')]").isDisplayed()){
			ReportGeneration("Navigated to Accumulative liquid assets tab", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Navigation to Accumulative liquid assets tab failed", "Fail", "Yes", driver);
		}

		
		
		Option(opt1, driver);
		Option(opt2, driver);
		// scroll to bottom of page
		visualScroll(driver);

		driver.findElementByXPath(EposAddFNAPage.txt_Amt).sendKeys(amt);
		

	    
	}
	
	@Then("^scroll below the page$")
	public void scroll_below_the_page() throws Throwable {
		visualScroll2(driver);
		
	 
	}
	@Then("^click on RPQ tab in FNA page$")
	public void click_on_RPQ_tab_in_FNA_page() throws Throwable {
		FNAlabelclick("RPQ",driver);	
		 //driver.findElementByXPath(EposAddFNAPage.tab_RPQ).click();
	}
	
	@Then("^select option \"([^\"]*)\" for question '(\\d+)' in RPQ screen of questionone$")
	public void select_option_for_question_in_RPQ_screen_of_questionone(String opt, int qnno) throws Throwable {

		 driver.context("WEBVIEW");
		    RPQQuestions(qnno,opt,driver);
	    
	}

	@Then("^select option \"([^\"]*)\" for question '(\\d+)' in RPQ screen of questiontwo$")
	public void select_option_for_question_in_RPQ_screen_of_questiontwo(String opt, int qnno) throws Throwable {
		RPQQuestions(qnno,opt,driver);
		visualScrollPage(driver);
	    
	}

	@Then("^select option \"([^\"]*)\" for question '(\\d+)' in RPQ screen of questionthree$")
	public void select_option_for_question_in_RPQ_screen_of_questionthree(String opt, int qnno) throws Throwable {

		RPQQuestions(qnno,opt,driver);
	    
	}

	@Then("^select option \"([^\"]*)\" for question '(\\d+)' check box in RPQ screen of questionfour$")
	public void select_option_for_question_check_box_in_RPQ_screen_of_questionfour(String opt, int qnno) throws Throwable {
		RPQQuestions(driver,qnno,opt);
	   
	}

	@Then("^select option \"([^\"]*)\",\"([^\"]*)\" for question '(\\d+)' check box in RPQ screen of questionfive$")
	public void select_option_for_question_check_box_in_RPQ_screen_of_questionfive(String opt1, String opt2, int qnno) throws Throwable {
		RPQQuestions(driver,qnno,opt1,opt2);
	}

	@Then("^select option \"([^\"]*)\" for question '(\\d+)' in RPQ screen of questionsix$")
	public void select_option_for_question_in_RPQ_screen_of_questionsix(String opt, int qnno) throws Throwable {
		RPQQuestions(qnno,opt,driver);
		visualScrollPage(driver);
	    
	}

	@Then("^select option \"([^\"]*)\" for question '(\\d+)' in RPQ screen of questionseven$")
	public void select_option_for_question_in_RPQ_screen_of_questionseven(String opt, int qnno) throws Throwable {
		RPQQuestions(qnno,opt,driver);
	    
	}

	@Then("^select option \"([^\"]*)\" for question '(\\d+)' in RPQ screen of questioneight$")
	public void select_option_for_question_in_RPQ_screen_of_questioneight(String opt, int qnno) throws Throwable {
		RPQQuestions(qnno,opt,driver);
		visualScrollPage(driver);
	    
	}

	@Then("^select option \"([^\"]*)\" for question '(\\d+)' in RPQ screen of questionnine$")
	public void select_option_for_question_in_RPQ_screen_of_questionnine(String opt, int qnno) throws Throwable {
		RPQQuestions(qnno,opt,driver);
	    
	}

	@Then("^select option \"([^\"]*)\" for question '(\\d+)' in RPQ screen of questionten$")
	public void select_option_for_question_in_RPQ_screen_of_questionten(String opt, int qnno) throws Throwable {
		RPQQuestions(qnno,opt,driver);
	    driver.context("NATIVE");
	}


	

	@Then("^select Plan as \"([^\"]*)\" in solutions page$")
	public void select_Plan_as_in_solutions_page(String rider1) throws Throwable {
		temprider1 = rider1;
		Policy_Selector(rider1, driver);
	    
	}

	@Then("^select Plan as \"([^\"]*)\" for LaVie product$")
	public void select_Plan_as_for_LaVie_product(String rider2) throws Throwable {
		
		temprider2 = rider2;
		Policy_Selector(rider2, driver);
	    
	}

	@Then("^select riders  \"([^\"]*)\" and \"([^\"]*)\"$")
	public void select_riders_and(String rider3, String rider4) throws Throwable {
		temprider3 = rider3;
		temprider4 = rider4;
		
		
		Policy_Selector(rider3, driver);
		Policy_Selector(rider4, driver);
		
	    
	}

	@Then("^select \"([^\"]*)\", \"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
	public void select_and(String rider5, String rider6, String rider7, String rider8) throws Throwable {
		temprider5 = rider5;
		temprider6 = rider6;
		temprider7 = rider7;
		temprider8 = rider8;
		
		Policy_Selector(rider5, driver);
		Policy_Selector(rider6, driver);
		Policy_Selector(rider7, driver);
		Policy_Selector(rider8, driver);
	    
	}
	
	
	
	
	@Then("^Select Plan description as \"([^\"]*)\",\"([^\"]*)\", \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" respectively$")
	public void select_Plan_description_as_respectively(String plan1, String plan2, String plan3, String plan4, String plan5, String plan6, String plan7, String plan8) throws Throwable {
		
		Plan_Selector(temprider1, plan2, driver);
		Plan_Selector(temprider2, plan1, driver);
		Plan_Selector(temprider3, plan8, driver);
		visualScrollPage(driver);
		Plan_Selector(temprider4, plan6, driver);
		Plan_Selector(temprider5, plan3, driver);
		Plan_Selector(temprider6, plan4, driver);
		visualScrollPage(driver);
		Plan_Selector(temprider7, plan5, driver);
		Plan_Selector(temprider8, plan7, driver);
		visualScroll(driver);
	}
	
	
	

	@Then("^Select all the check boxes for the product and Riders$")
	public void select_all_the_check_boxes_for_the_product_and_Riders() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	

	@Then("^click on Proposals in the popup$")
	public void click_on_Proposals_in_the_popup() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}


	
	
}
