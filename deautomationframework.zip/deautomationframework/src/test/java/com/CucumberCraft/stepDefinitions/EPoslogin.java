package com.CucumberCraft.stepDefinitions;

import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.CucumberCraft.pageObjects.EposAddFNAPage;
import com.CucumberCraft.pageObjects.LoginEPOSAppPage;
import com.CucumberCraft.supportLibraries.DriverManager;
import com.CucumberCraft.supportLibraries.Settings;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.AppiumDriver;

public class EPoslogin extends MasterStepDefs {
	
	private static Properties mobileProperties = Settings.getInstance();
	static Logger log;

	static {
		log = Logger.getLogger(EPoslogin.class);
	}

	@SuppressWarnings("rawtypes")
	AppiumDriver driver = DriverManager.getDriver();
	
	@Given("^App is opened$")
	public void app_is_opened() throws Throwable {
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		//Closes the current session of APP
		closeApp(driver,"NATIVE_APP",mobileProperties.getProperty("Application_Package_Name"));
		//Re-opens the app again to login
		openApp(driver,"NATIVE_APP",mobileProperties.getProperty("Application_Package_Name"));
	}

	@When("^I give user name as  \"([^\"]*)\" and password as \"([^\"]*)\"$")
	public void i_give_user_name_as_and_password_as(String username, String password) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		// driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
		log.info("Started");

		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(LoginEPOSAppPage.txt_username)));

		driver.findElementByXPath(LoginEPOSAppPage.txt_username).clear();
		driver.findElementByXPath(LoginEPOSAppPage.txt_username).sendKeys(username);
		driver.findElementByXPath(LoginEPOSAppPage.txt_password).clear();
		driver.findElementByXPath(LoginEPOSAppPage.txt_password).sendKeys(password);
	}

	@When("^click on sign in button$")
	public void click_on_sign_in_button() throws Throwable {

		driver.findElementByXPath(LoginEPOSAppPage.btn_signin).click();

		// If sign in button is displayed again

		try {
			if (driver.findElementByXPath(LoginEPOSAppPage.btn_signin).isDisplayed()) {
				driver.findElementByXPath(LoginEPOSAppPage.btn_signin).click();
			}
		} catch (Exception ex) {

		}
		Waitforloginpage(driver);
		/*		//Previously used code
		Waitforloading(LoginEPOSAppPage.img_Login_Ldg, driver);
		try{
			System.out.println("Trying for Prospect screen");
			PauseScript(3,driver);	
			if (driver.findElementByXPath(LoginEPOSAppPage.btn_addprospect).isDisplayed()){
				log.info("Add prospect displayed check");
			}
		}catch(Exception ex){
			log.info("Entered exception searching for addprospect button ");
			// First time login-Language selection
			Loginlanguage(driver);
			
			// First time login-Loading screen
			LoginAgree(driver);
		}
			
	*/	

	}


@When("^click on \"([^\"]*)\" in pop-up if displayed$")
public void click_on_in_pop_up_if_displayed(String select_opt) throws Throwable {
	driver.context("NATIVE");
	try{
	if(driver.findElementByXPath("//*[@label='"+select_opt+"']").isDisplayed()){
		driver.findElementByXPath("//*[@label='"+select_opt+"']").click();
	}
	}catch(Exception ex){
		System.out.println("Allow popup exception");
	}
}

	
	
	@Then("^I navigate to login page of agent$")
	public void i_navigate_to_login_page_of_agent() throws Throwable {
		WebDriverWait wait=new WebDriverWait(driver, 5);
		
		Waitforloading(LoginEPOSAppPage.img_Login_Ldg, driver);
		//driver.context("WEBVIEW");
		// Pop-Up box
		/*
		 * if (driver.findElementByXPath(EposAddFNAPage.btn_OK).isDisplayed()) {
		 * driver.findElementByXPath(EposAddFNAPage.btn_OK).click(); }
		 */
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(LoginEPOSAppPage.btn_addprospect)));
		if (driver.findElementByXPath(LoginEPOSAppPage.btn_addprospect).isDisplayed()) {
			ReportGeneration("Login screen is displayed", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Failed to login", "Fail", "Yes", driver);
		}

	}

}
