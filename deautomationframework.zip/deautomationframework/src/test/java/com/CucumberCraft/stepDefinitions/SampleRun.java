package com.CucumberCraft.stepDefinitions;

import java.awt.Desktop.Action;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.internal.Coordinates;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.CucumberCraft.pageObjects.Applyphase;
import com.CucumberCraft.pageObjects.EposAddFNAPage;
import com.CucumberCraft.pageObjects.EposAddProspectPage;
import com.CucumberCraft.pageObjects.EposCreateProposalPage;
import com.CucumberCraft.pageObjects.EposDrawerMenu;
import com.CucumberCraft.pageObjects.Eposgoals;
import com.CucumberCraft.pageObjects.LoginEPOSAppPage;
import com.CucumberCraft.supportLibraries.DriverManager;
import com.CucumberCraft.supportLibraries.Settings;
import com.gargoylesoftware.htmlunit.javascript.host.Element;
import com.itextpdf.text.log.SysoCounter;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;

public class SampleRun extends MasterStepDefs {
	public  boolean resultBool;
	@SuppressWarnings("rawtypes")
	AppiumDriver driver=DriverManager.getDriver();
	private static Properties mobileProperties = Settings.getInstance();
	
	@Then("^i will make sample run$")
	public void i_will_make_sample_run() throws Throwable {
	
		
	SetPageContext("WEBVIEW_2",driver);
	SetPageContext("WEBVIEW_3",driver);
	//driver.context("WEBVIEW_2");	
	//WebElement o=driver.findElementByXPath(Applyphase.txt_DirectDebit_Accbrno);
	//int l=driver.findElementByXPath(Applyphase.txt_DirectDebit_Accbrno).getLocation().getY();
	
	Point point = driver.findElementByXPath(Applyphase.txt_DirectDebit_Accbrno).getLocation();
	String coordinates = point.getX()+","+ point.getY();

			Map<String, Object> params9 = new HashMap<>();
			params9.put("location", coordinates);
			Object result8 = driver.executeScript("mobile:touch:tap", params9);
			driver.getKeyboard().sendKeys("124");
			log.info("completed");
	
	//TouchAction a2 = new TouchAction(driver);
	//a2.tap (857,627).perform();
	//a2.tap(o).perform();
	
	//driver.tap
	//Object k=(Point)l;
	//int b=driver.findElementByXPath(Applyphase.txt_DirectDebit_Accbrno).getLocation().getY();
		
	//Map<String, Object> params9 = new HashMap<>();
	//params9.put("location", k);
	//Object result9 = driver.executeScript("mobile:touch:tap", params9);
	driver.getKeyboard().sendKeys("124");
	log.info("completed");
	//Mobile No	
	/*	
	Map<String, Object> params9 = new HashMap<>();
	params9.put("location", "714,412");
	Object result9 = driver.executeScript("mobile:touch:tap", params9);
	driver.getKeyboard().sendKeys("1242134");
	*/
	
	
	
	//Acc No
	/*
	Map<String, Object> params9 = new HashMap<>();
	params9.put("location", "857,627");
	Object result8 = driver.executeScript("mobile:touch:tap", params9);
	driver.getKeyboard().sendKeys("124");
	*/
	//Acc No-2
	/*
	Map<String, Object> params2 = new HashMap<>();
	params2.put("location", "1008,627");
	Object result2 = driver.executeScript("mobile:touch:tap", params2);
	driver.getKeyboard().sendKeys("222254545");
	
	*/
	
	
	
		
		
		
		
		
		
		
	}

	
			

		
	}
	
		
		



	
	
	