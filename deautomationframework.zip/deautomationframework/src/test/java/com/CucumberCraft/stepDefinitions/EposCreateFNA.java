package com.CucumberCraft.stepDefinitions;

import java.sql.Driver;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.CucumberCraft.pageObjects.EposAddFNAPage;
import com.CucumberCraft.pageObjects.EposCreateProposalPage;
import com.CucumberCraft.pageObjects.EposDrawerMenu;
import com.CucumberCraft.pageObjects.LoginEPOSAppPage;
import com.CucumberCraft.supportLibraries.DriverManager;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.TouchAction;
import io.appium.java_client.ios.IOSElement;

public class EposCreateFNA extends MasterStepDefs {
	AppiumDriver driver = DriverManager.getDriver();
	WebDriverWait wait=new WebDriverWait(driver, 30);
	public boolean resultBool;
	public static String temprider1, temprider2, temprider3, temprider4, temprider5, temprider6, temprider7, temprider8;

	@Given("^I am in home Screen after creating prospect$")
	public void i_am_in_home_Screen_after_creating_prospect() throws Throwable {
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		// Write code here that turns the phrase above into concrete actions

	}

	@Given("^search customer \"([^\"]*)\" and click the customer$")
	public void search_customer_and_click_the_customer(String cust_name) throws Throwable {
		driver.context("NATIVE");
		driver.findElementByXPath(EposCreateProposalPage.tab_Drawer_Menu).click();
		// If password window pop-up
		//Passwordentry(driver);
		// To click on Customer List
		//textClick("Customer List", 5, driver);
		Customerlistclick(driver);
		// If password window pop-up
		Passwordentry(driver);
		driver.context("NATIVE");
		driver.findElementByXPath(EposAddFNAPage.txt_cust).sendKeys(cust_name);
		driver.findElementByXPath(EposAddFNAPage.btn_Key_GO).click();

		CustomerClick(cust_name + " ", driver);

		// If password window pop-up
		Passwordentry(driver);

	}
	
	@Given("^search customer and click the customer$")
	public void search_customer_and_click_the_customer() throws Throwable {
		
		driver.context("NATIVE");
		driver.findElementByXPath(EposCreateProposalPage.tab_Drawer_Menu).click();
		
		Customerlistclick(driver);
		
		driver.context("NATIVE");
		
		try{
			driver.findElementByXPath(EposAddFNAPage.txt_cust).sendKeys(readPropertiesFile("name"));
			driver.findElementByXPath(EposAddFNAPage.btn_Key_GO).click();
			CustomerClick(readPropertiesFile("name")+" ", driver);
		}catch(Exception ex){
			// If password window pop-up
			Passwordentry(driver);
			driver.context("NATIVE");
			driver.findElementByXPath(EposAddFNAPage.txt_cust).sendKeys(readPropertiesFile("name"));
			driver.findElementByXPath(EposAddFNAPage.btn_Key_GO).click();
			CustomerClick(readPropertiesFile("name")+" ", driver);
		}
		

		

		// If password window pop-up
		//Passwordentry(driver);

	}
	
	

	@Then("^I will navigate to FNA panel to click create FNA button$")
	public void i_will_navigate_to_FNA_panel_to_click_create_FNA_button() throws Throwable {
		WebDriverWait wait=new WebDriverWait(driver, 60);

		// Scroll to the extreme right of page
		visualScrollright(driver);
		driver.context("WEBVIEW");
		driver.findElementByXPath(EposAddFNAPage.lbl_FNA).click();

		// If download pop-up appears
		try {
			driver.context("NATIVE");
			if (driver.findElementByXPath(EposDrawerMenu.btn_download).isDisplayed()) {
				driver.findElementByXPath(EposDrawerMenu.btn_download).click();
				PauseScript(1, driver);
				// Scroll to the extreme right of page
				visualScrollright(driver);
				driver.findElementByXPath(EposAddFNAPage.lbl_FNA).click();
			}
		} catch (Exception ex) {
		}
		driver.context("WEBVIEW");
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(EposAddFNAPage.lbl_FNApanel)));	

	}

	@Then("^I will be navigated to Financial Needs Analysis screen$")
	public void i_will_be_navigated_to_Financial_Needs_Analysis_screen() throws Throwable {

		driver.context("NATIVE");	
		driver.findElementByXPath(EposAddFNAPage.btn_FNA).click();
		Click_Goal("Ensure well-being of family & dependents in the event of death",driver);
		driver.context("NATIVE");
		driver.findElementByXPath(EposAddFNAPage.btn_OK).click();

	}

	@Then("^click Personal Information tab and will be navigated to Personal Information screen$")
	public void click_Personal_Information_tab_and_will_be_navigated_to_Personal_Information_screen() throws Throwable {
		
		FNAlabelclick("Personal Information",driver);
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//UIAStaticText[contains(@label,'Personal Information')]")));
		

		/*
		if(driver.findElementByXPath("//UIAStaticText[contains(@label,'Personal Information')]").isDisplayed()){
			ReportGeneration("Navigated to Personal Information screen", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Navigation to Personal Information screen failed", "Fail", "Yes", driver);
		}
		*/

	}

	@Then("^select Salutation as \"([^\"]*)\" Number of dependents as \"([^\"]*)\" issue age as \"([^\"]*)\" Age as \"([^\"]*)\" Marital Status as \"([^\"]*)\"$")
	public void select_Salutation_as_Number_of_dependents_as_issue_age_as_Age_as_Marital_Status_as(String salutation,
			String no_dep, String age, String issue_age, String marital_status) throws Throwable {

		Dataselect(salutation, driver);

		Dataselect(no_dep, driver);
		driver.findElementByXPath(EposAddFNAPage.txt_Age).clear();
		driver.findElementByXPath(EposAddFNAPage.txt_Age).sendKeys(age);
		driver.findElementByXPath(EposAddFNAPage.txt_Iss_Age).clear();
		driver.findElementByXPath(EposAddFNAPage.txt_Iss_Age).sendKeys(issue_age);
	Dataselect(marital_status, driver);

	}

	@Then("^select Number Type as \"([^\"]*)\"$")
	public void select_Number_Type_as(String mobile) throws Throwable {

		Dataselect(mobile, driver);

		// Hide the keyboard
		HideKeyboard(driver);

		// Scrolling to the end of page
		visualScroll(driver);

	}

	@Then("^Phone Number as \"([^\"]*)\"$")
	public void phone_Number_as(String phoneno) throws Throwable {
		driver.findElementByXPath(EposAddFNAPage.txt_Phone_No).sendKeys(phoneno);
		// Hide the keyboard
		HideKeyboard(driver);

	}

	@Then("^Occupation as \"([^\"]*)\" and Higher Education Level Attained as \"([^\"]*)\"$")
	public void occupation_as_and_Higher_Education_Level_Attained_as(String occupation, String edu_level)
			throws Throwable {

		Dataselect(occupation, driver);

		Dataselect(edu_level, driver);

	}

	@Then("^click on Proceed button at the top right corner$")
	public void click_on_Proceed_button_at_the_top_right_corner() throws Throwable {
		driver.findElementByXPath(EposAddFNAPage.btn_proceed).click();

	}
	
	
	
	
	
	
	@Then("^click on buying tab and select option \"([^\"]*)\",\"([^\"]*)\" and  deselect \"([^\"]*)\"$")
	public void click_on_buying_tab_and_select_option_and_deselect(String option1, String option2, String option3) throws Throwable {
		driver.findElement(By.name("Buying Objectives")).click();
		Option(option1, driver);
		Option(option2, driver);
		Option(option3, driver);
	}
	
	@Then("^click on buying tab$")
	public void click_on_buying_tab() throws Throwable {
		driver.findElement(By.name("Buying Objectives")).click();
	}
	
	@Then("^select option \"([^\"]*)\"$")
	public void select_option(String option) throws Throwable {
		Option(option, driver);
	}
	
	@Then("^deselect \"([^\"]*)\"$")
	public void deselect(String deselect_opt) throws Throwable {
		Option(deselect_opt, driver);
	}
	
	@Then("^click on buying tab and select option \"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
	public void click_on_buying_tab_and_select_option_and(String opt1, String opt2, String opt3) throws Throwable {
		driver.findElement(By.name("Buying Objectives")).click();

		// To click options
	//	Option(opt1, driver);

		Option(opt2, driver);

		Option(opt3, driver);

	}
	
	@Given("^enter value \"([^\"]*)\" in option \"([^\"]*)\"$")
	public void enter_value_in_option(String value, String option_name) throws Throwable {
		FNAOptions(option_name,value,driver);
		HideKeyboard(driver);
	}


@Given("^click on ok in pop-up if displayed$")
public void click_on_ok_in_pop_up_if_displayed() throws Throwable {
	driver.context("NATIVE");
	try{
	if(driver.findElementByXPath(EposAddFNAPage.btn_OK).isDisplayed()){
		driver.findElementByXPath(EposAddFNAPage.btn_OK).click();
		driver.findElementByXPath(EposAddFNAPage.btn_proceed).click();
	}
	}catch(Exception ex){}
    
}

	

	@Then("^enter value \"([^\"]*)\" in option E$")
	public void enter_value_in_option_E(String amt_E) throws Throwable {
		
		driver.findElementByXPath(EposAddFNAPage.txt_tgt_fld2).clear();
		
		driver.findElementByXPath(EposAddFNAPage.txt_tgt_fld2).sendKeys(amt_E);
		driver.findElementByXPath(EposAddFNAPage.btn_proceed).click();
		
	}

	@Then("^click on Type of Insurance product tab and select option \"([^\"]*)\" and \"([^\"]*)\"$")
	public void click_on_Type_of_Insurance_product_tab_and_select_option_and(String opt1, String opt2)
			throws Throwable {
		FNAlabelclick("Type of Insurance Product",driver);
		//driver.findElement(By.name("Type of Insurance Product")).click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//UIAStaticText[contains(@label,'Type of Insurance Product')]")));
	

		Option(opt1, driver);

		Option(opt2, driver);

	}
	

@Then("^click on Type of Insurance product tab$")
public void click_on_Type_of_Insurance_product_tab() throws Throwable {
	FNAlabelclick("Type of Insurance Product",driver);
	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//UIAStaticText[contains(@label,'Type of Insurance Product')]")));
 
}
	

	@Then("^click on Target Benefit/Protection Period tab and select option \"([^\"]*)\"$")
	public void click_on_Target_Benefit_Protection_Period_tab_and_select_option(String opt1) throws Throwable {
		visualScroll2(driver);
		FNAlabelclick("Target Benefit / Protection Period",driver);
		//driver.findElement(By.name("Target Benefit / Protection Period")).click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//UIAStaticText[contains(@label,'Target Benefit / Protection Period')]")));
		/*
		if(driver.findElementByXPath("//UIAStaticText[contains(@label,'3.  Target Benefit / Protection Period')]").isDisplayed()){
			ReportGeneration("Navigated to Target Benefit tab", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Navigation to Target Benefit tab failed", "Fail", "Yes", driver);
		}
		*/
		
		
		Option(opt1, driver);

		driver.findElementByXPath(EposAddFNAPage.btn_proceed).click();

	}
	
	@Then("^click on Target Benefit/Protection Period tab$")
	public void click_on_Target_Benefit_Protection_Period_tab() throws Throwable {
		FNAlabelclick("Target Benefit / Protection Period",driver);
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//UIAStaticText[contains(@label,'Target Benefit / Protection Period')]")));
		if(driver.findElementByXPath("//UIAStaticText[contains(@label,'3.  Target Benefit / Protection Period')]").isDisplayed()){
			ReportGeneration("Navigated to Target Benefit tab", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Navigation to Target Benefit tab failed", "Fail", "Yes", driver);
		}
	 
	}
	
	
	@Then("^click on Average Monthly Income tab and select In the following Range to select option \"([^\"]*)\"$")
	public void click_on_Average_Monthly_Income_tab_and_select_In_the_following_Range_to_select_option(String opt1)
			throws Throwable {
		FNAlabelclick("Average Monthly Income",driver);
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//UIAStaticText[contains(@label,'Average Monthly Income')]")));
		/*
		if(driver.findElementByXPath("//UIAStaticText[contains(@label,'4.1.  Average Monthly Income')]").isDisplayed()){
			ReportGeneration("Navigated to Average monthly income  tab", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Navigation to Average monthly income  tab failed", "Fail", "Yes", driver);
		}
		*/
		
		driver.findElementByXPath(EposAddFNAPage.btn_Foll_Rg).click();
		Option(opt1, driver);

		driver.findElementByXPath(EposAddFNAPage.btn_proceed).click();

	}
	
	@Then("^select In the following Range to select option \"([^\"]*)\"$")
	public void select_In_the_following_Range_to_select_option(String option) throws Throwable {
		driver.findElementByXPath(EposAddFNAPage.btn_Foll_Rg).click();
		Option(option, driver);
	}
	

@Given("^scroll the page in FNA screen$")
public void scroll_the_page_in_FNA_screen() throws Throwable {
	visualScroll2(driver);
}

	
	
	@Then("^click on Average Monthly Income tab$")
	public void click_on_Average_Monthly_Income_tab() throws Throwable {
		FNAlabelclick("Average Monthly Income",driver);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//UIAStaticText[contains(@label,'Average Monthly Income')]")));
		if(driver.findElementByXPath("//UIAStaticText[contains(@label,'4.1.  Average Monthly Income')]").isDisplayed()){
			ReportGeneration("Navigated to Average monthly income  tab", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Navigation to Average monthly income  tab failed", "Fail", "Yes", driver);
		}
	 
	}
	
	
	

	@Then("^click on Average Monthly Expense tab and enter amount \"([^\"]*)\"$")
	public void click_on_Average_Monthly_Expense_tab_and_enter_amount(String amt) throws Throwable {
		visualScroll2(driver);
		FNAlabelclick("Average Monthly Expenses",driver);
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//UIAStaticText[contains(@label,'Average Monthly Expenses')]")));
		/*
		if(driver.findElementByXPath("//UIAStaticText[contains(@label,'4.2 Average Monthly Expense')]").isDisplayed()){
			ReportGeneration("Navigated to Average monthly Expense  tab", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Navigation to Average monthly Expense  tab failed", "Fail", "Yes", driver);
		}
		*/
		driver.findElementByXPath(EposAddFNAPage.txt_Amt).sendKeys(amt);
		driver.findElementByXPath(EposAddFNAPage.btn_proceed).click();

	}

	@Then("^select option \"([^\"]*)\" in Accumulative Amount of Liquid Assets and enter amount as \"([^\"]*)\"$")
	public void select_option_in_Accumulative_Amount_of_Liquid_Assets_and_enter_amount_as(String opt1, String amt)
			throws Throwable {
		// driver.findElementByXPath(EposAddFNAPage.tab_Cum_Liq_Asset).click();
		FNAlabelclick("Cumulative Liquid Assets",driver);
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//UIAStaticText[contains(@label,'Cumulative Liquid Assets')]")));
		/*
		if(driver.findElementByXPath("//UIAStaticText[contains(@label,'4.3 Accumulative Amount of Liquid Assets')]").isDisplayed()){
			ReportGeneration("Navigated to Accumulative liquid assets tab", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Navigation to Accumulative liquid assets tab failed", "Fail", "Yes", driver);
		}
		*/
		
		
		Option(opt1, driver);

		// scroll to bottom of page
		visualScroll(driver);

		driver.findElementByXPath(EposAddFNAPage.txt_Amt).sendKeys(amt);
		driver.findElementByXPath(EposAddFNAPage.btn_proceed).click();

	}
	
	@Then("^click on of Accumulative Amount of Liquid Assets tab$")
	public void click_on_of_Accumulative_Amount_of_Liquid_Assets_tab() throws Throwable {
		FNAlabelclick("Cumulative Liquid Assets",driver);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//UIAStaticText[contains(@label,'Cumulative Liquid Assets')]")));
		
		if(driver.findElementByXPath("//UIAStaticText[contains(@label,'4.3 Accumulative Amount of Liquid Assets')]").isDisplayed()){
			ReportGeneration("Navigated to Accumulative liquid assets tab", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Navigation to Accumulative liquid assets tab failed", "Fail", "Yes", driver);
		}
	 
	}
	
	
	
	@Then("^select option \"([^\"]*)\" in Contibution Duration screen$")
	public void select_option_in_Contibution_Duration_screen(String opt1) throws Throwable {
		FNAlabelclick("Contribution Duration",driver);
		//driver.findElement(By.name("Contribution Duration")).click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//UIAStaticText[contains(@label,'Contribution Duration')]")));
		/*
		if(driver.findElementByXPath("//UIAStaticText[contains(@label,'4.4 Contribution Duration')]").isDisplayed()){
			ReportGeneration("Navigated to Contribution duration tab", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Navigation to Contribution duration tab failed", "Fail", "Yes", driver);
		}
		*/
		driver.findElementByXPath(EposAddFNAPage.btn_Foll_Rg).click();
		Option(opt1, driver);

		driver.findElementByXPath(EposAddFNAPage.btn_proceed).click();

	}
	
	@Then("^click on Type of Contibution Duration tab$")
	public void click_on_Type_of_Contibution_Duration_tab() throws Throwable {
		FNAlabelclick("Contribution Duration",driver);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//UIAStaticText[contains(@label,'Contribution Duration')]")));
		if(driver.findElementByXPath("//UIAStaticText[contains(@label,'4.4 Contribution Duration')]").isDisplayed()){
			ReportGeneration("Navigated to Contribution duration tab", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Navigation to Contribution duration tab failed", "Fail", "Yes", driver);
		}
		
	}

	
	
	@Then("^select option \"([^\"]*)\" in Disposable Income screen$")
	public void select_option_in_Disposable_Income_screen(String opt1) throws Throwable {

		visualScroll2(driver);
		FNAlabelclick("Disposable Income",driver);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//UIAStaticText[contains(@label,'Disposable Income')]")));
		
		/*
		if(driver.findElementByXPath("//UIAStaticText[contains(@label,'4.5 Disposable Income')]").isDisplayed()){
			ReportGeneration("Navigated to Disposable Income tab", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Navigation to Disposable Income tab failed", "Fail", "Yes", driver);
		}
		*/
		
		Option(opt1, driver);

		driver.findElementByXPath(EposAddFNAPage.btn_proceed).click();
		visualScroll2(driver);

	}
	
	@Then("^click on Type of Disposable Income screen$")
	public void click_on_Type_of_Disposable_Income_screen() throws Throwable {
		FNAlabelclick("Disposable Income",driver);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//UIAStaticText[contains(@label,'Disposable Income')]")));
		
		
		if(driver.findElementByXPath("//UIAStaticText[contains(@label,'4.5 Disposable Income')]").isDisplayed()){
			ReportGeneration("Navigated to Disposable Income tab", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Navigation to Disposable Income tab failed", "Fail", "Yes", driver);
		}
		
	}
	

	@Then("^select option \"([^\"]*)\" and \"([^\"]*)\" in Source of Funds screen$")
	public void select_option_and_in_Source_of_Funds_screen(String opt1, String opt2) throws Throwable {
		//driver.findElement(By.name("Source of Funds")).click();
		FNAlabelclick("Source of Funds",driver);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//UIAStaticText[contains(@label,'Source of Funds')]")));
		/*
		if(driver.findElementByXPath("//UIAStaticText[contains(@label,'4.6 Sources of Funds')]").isDisplayed()){
			ReportGeneration("Navigated to Source of funds tab", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Navigation to Source of funds tab failed", "Fail", "Yes", driver);
		}
		*/

		Option(opt1, driver);
		Option(opt2, driver);

		driver.findElementByXPath(EposAddFNAPage.btn_proceed).click();

	}
	
	@Then("^click on Source of Funds screen$")
	public void click_on_Source_of_Funds_screen() throws Throwable {
		FNAlabelclick("Source of Funds",driver);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//UIAStaticText[contains(@label,'Source of Funds')]")));
		if(driver.findElementByXPath("//UIAStaticText[contains(@label,'4.6 Sources of Funds')]").isDisplayed()){
			ReportGeneration("Navigated to Source of funds tab", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Navigation to Source of funds tab failed", "Fail", "Yes", driver);
		}

	}

	
	
	@Then("^select Plan  LaVie\\(RDB\\) in solutions page$")
	public void select_Plan_LaVie_RDB_in_solutions_page() throws Throwable {

	}

	@Then("^select rider \"([^\"]*)\"$")
	public void select_rider(String rider1) throws Throwable {
	 
	 Policy_Selector(rider1, driver);
	}
	
	@Then("^select Plan as \"([^\"]*)\"$")
	public void select_Plan_as(String rider1) throws Throwable {
		
		 Policy_Selector(rider1, driver);
	}
	
	@And("^select riders \"([^\"]*)\",\"([^\"]*)\", \"([^\"]*)\"$")
	public void select_riders(String rider1, String rider2, String rider3) throws Throwable {
		Policy_Selector2(driver, rider1,rider2,rider3);
	}
	
	@And("^select riders \"([^\"]*)\",\"([^\"]*)\", \"([^\"]*)\",\"([^\"]*)\" ,\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void select_riders(String policy1, String policy2, String policy3, String policy4, String policy5, String policy6, String policy7, String policy8) throws Throwable {
		Policy_Selector2(driver, policy1,policy2,policy3,policy4,policy5,policy6,policy7,policy8);
	}
	
	@And("^select riders \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" ,\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void select_riders(String policy1, String policy2, String policy3, String policy4, String policy5, String policy6, String policy7) throws Throwable {
		Policy_Selector2(driver, policy1,policy2,policy3,policy4,policy5,policy6,policy7);
	}

	
	
	
	@Then("^select riders \"([^\"]*)\",\"([^\"]*)\", \"([^\"]*)\" ,\"([^\"]*)\"$")
	public void select_riders(String rider1, String rider2, String rider3, String rider4) throws Throwable {
		temprider1 = rider1;
		temprider2 = rider2;
		temprider3 = rider3;
		temprider4 = rider4;

		Policy_Selector(rider1, driver);
		Policy_Selector(rider2, driver);
		Policy_Selector(rider3, driver);
		Policy_Selector(rider4, driver);

	}

	@Then("^select \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
	public void select_and(String rider5, String rider6, String rider7, String rider8) throws Throwable {
		temprider5 = rider5;
		temprider6 = rider6;
		temprider7 = rider7;
		temprider8 = rider8;

		// Policy_Selector("rider5",driver);
		Policy_Selector(rider6, driver);
		Policy_Selector(rider7, driver);
		Policy_Selector(rider8, driver);
		
		
		
		
		driver.findElementByXPath(EposAddFNAPage.btn_cmn_proceed).click();

	}
	
	@Given("^select riders \"([^\"]*)\",\"([^\"]*)\" ,\"([^\"]*)\"  for Manuguard$")
	public void select_riders_for_Manuguard(String rider1, String rider2, String rider3) throws Throwable {
		temprider1 = rider1;
		temprider2 = rider2;
		temprider3 = rider3;
		
		Policy_Selector(rider1, driver);
		Policy_Selector(rider2, driver);
		Policy_Selector(rider3, driver);
		
	}

	
	
	
	@Then("^I will be navigated to product recommendation screen$")
	public void i_will_be_navigated_to_product_recommendation_screen() throws Throwable {

		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//UIAStaticText[contains(@label,'Product Recommendation')]")));
		if(driver.findElementByXPath("//UIAStaticText[contains(@label,'Product Recommendation')]").isDisplayed()){
			ReportGeneration("Navigated to Product Recommendation page", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Navigation to Product Recommendation page failed", "Fail", "Yes", driver);
		}
		
		
	}

	@Then("^Select plan description as \"([^\"]*)\" for \"([^\"]*)\"$")
	public void select_plan_description_as_for(String Plan_name, String Policy_name) throws Throwable {
		Plan_Selector2(Plan_name,Policy_name,driver);
	}
	
	
	
	@Then("^Select plan description in Product recommendation screen for all Riders$")
	public void select_plan_description_in_Product_recommendation_screen_for_all_Riders() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@Then("^Select plan \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void select_plan(String plan1, String plan2, String plan3, String plan4, String plan5, String plan6,
			String plan7, String plan8) throws Throwable {

		Plan_Selector(temprider1, plan1, driver);
		Plan_Selector(temprider2, plan2, driver);
		Plan_Selector(temprider3, plan3, driver);

		visualScrollPage(driver);

		Plan_Selector(temprider4, plan4, driver);
		// Plan_Selector(temprider5,plan5,driver);

		Plan_Selector(temprider6, plan6, driver);
		visualScrollPage(driver);
		Plan_Selector(temprider7, plan7, driver);
		Plan_Selector(temprider8, plan8, driver);

	}
	
	@Given("^Select plan \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"  for Manuguard$")
	public void select_plan_for_Manuguard(String plan1, String plan2, String plan3) throws Throwable {
		Plan_Selector(temprider1, plan1, driver);
		Plan_Selector(temprider2, plan2, driver);
		Plan_Selector(temprider3, plan3, driver);
	}


	@Then("^Select all the check box for the product$")
	public void select_all_the_check_box_for_the_product() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@Then("^select Plan description as La Vie (\\d+) for Product La Vie\\(RDB\\)$")
	public void select_Plan_description_as_La_Vie_for_Product_La_Vie_RDB(int arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@Then("^Select all the check boxes for the products and Riders$")
	public void select_all_the_check_boxes_for_the_products_and_Riders() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}
	
	@Given("^select \"([^\"]*)\" in Advisor's reason$")
	public void select_in_Advisor_s_reason(String option) throws Throwable {
		Advisoroptions(option, driver);
	}

	

	@Then("^select \"([^\"]*)\" and \"([^\"]*)\" in Advisor's reason$")
	public void select_and_in_Advisor_s_reason(String arg1, String arg2) throws Throwable {
		Advisoroptions("option1", driver);

		Advisoroptions("option2", driver);

	}


	@Then("^I will be navigated to Financial Needs Analysis Summary page$")
	public void i_will_be_navigated_to_Financial_Needs_Analysis_Summary_page() throws Throwable {
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//UIAStaticText[contains(@label,'Financial Needs Analysis Summary')]")));
		if(driver.findElementByXPath("//UIAStaticText[contains(@label,'Financial Needs Analysis Summary')]").isDisplayed()){
			ReportGeneration("Navigated to FNA summary page", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Navigation to FNA summary page failed", "Fail", "Yes", driver);
		}
		
	}

	@Then("^click on Confirm & Proceed$")
	public void click_on_Confirm_Proceed() throws Throwable {
		
		driver.findElementByXPath(EposAddFNAPage.btn_cnfr_proceed).click();
		
	}

}
