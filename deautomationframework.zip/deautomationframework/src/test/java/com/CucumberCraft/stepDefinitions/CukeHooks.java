package com.CucumberCraft.stepDefinitions;

import io.appium.java_client.AppiumDriver;

import java.io.File;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriverException;

import com.CucumberCraft.supportLibraries.DriverFactory;
import com.CucumberCraft.supportLibraries.DriverManager;
import com.CucumberCraft.supportLibraries.PerfectoLabUtils;
import com.CucumberCraft.supportLibraries.RestApiForJira;
import com.CucumberCraft.supportLibraries.Settings;
import com.CucumberCraft.supportLibraries.Util;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;

public class CukeHooks extends MasterStepDefs {
	//private static Properties mobileProperties = MasterStepDefs.writePropertiesFile();
	//private static Properties properties = loadFromPropertiesFile();
	static Logger log;

	static {
		log = Logger.getLogger(CukeHooks.class);
				
		
	}

	@SuppressWarnings("rawtypes")
	@Before
	
	public void setUp(Scenario scenario) {
		
		try {
			currentScenario = scenario;
			currentTestParameters = DriverManager.getTestParameters();
			currentTestParameters.setScenarioName(scenario.getName());
			log.info("Running the Scenario" + scenario.getName());
			AppiumDriver driver = DriverFactory
					.createInstance(currentTestParameters);
			log.info("Driver Object Created");
			DriverManager.setWebDriver(driver);
		} catch (Exception e) {
			log.error("Error at Before Scenario " + e.getMessage());
		}
		
		
	}

	@SuppressWarnings("rawtypes")
	@After
	public void embedScreenshot(Scenario scenario) {
		try {
			update(scenario);
			Properties properties = Settings.getInstance();
			AppiumDriver driver = DriverManager.getDriver();
			if (Boolean.valueOf(properties
					.getProperty("PerfectoReportGeneration"))) {
				try {
					driver.close();
					String Udid;

					if (!(driver.getCapabilities().getCapability("model") == null)) {
						Udid = driver.getCapabilities().getCapability("model")
								.toString();
					} else {
						Udid = driver.getCapabilities()
								.getCapability("deviceName").toString();
					}
					PerfectoLabUtils.downloadReport(driver, "pdf",
							Util.getResultsPath() + Util.getFileSeparator()
									+ scenario.getName() + "_" + Udid);
				} catch (IOException e) {
					e.printStackTrace();
					log.error("Problem while downloading Perfecto Report for "
							+ scenario.getName());
				}
			}

		} catch (Exception ex) {
			log.error("Problem while closing the Driver Object"
					+ ex.getMessage());

		} finally {
			AppiumDriver driver = DriverManager.getDriver();
			if (driver != null) {
				driver.quit();
			}
		}

	}

	/**
	 * Embed a screenshot in test report if test is marked as failed And Update
	 * Task in JIRA
	 */
	private void update(Scenario scenario) {
		if (scenario.isFailed()) {
			try {
				Properties properties = Settings.getInstance();
				byte[] screenshot = ((TakesScreenshot) DriverManager
						.getDriver()).getScreenshotAs(OutputType.BYTES);
				scenario.embed(screenshot, "image/png");
				/*
				 * Below Logic to Simple create Bug/Taks in Jira without
				 * Screenshot
				 */
				if (Boolean.valueOf(properties
						.getProperty("TrackIssuesInJiraWithScreenShots"))) {

					RestApiForJira.creatLog(scenario.getName(),
							scenario.getName());

				}
				/* Below Logic to create Bug/Taks in Jira with Screenshot */
				else if (Boolean.valueOf(properties
						.getProperty("TrackIssuesInJiraWithOutScreenShots"))) {
					File filePath = ((TakesScreenshot) DriverManager
							.getDriver()).getScreenshotAs(OutputType.FILE);
					RestApiForJira.createLog(scenario.getName(),
							scenario.getName(), filePath.toString());
				}
			} catch (WebDriverException somePlatformsDontSupportScreenshots) {
				log.error(somePlatformsDontSupportScreenshots.getMessage());
			}
		}
	}

}