package com.CucumberCraft.stepDefinitions;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.CucumberCraft.pageObjects.EposAddProspectPage;
import com.CucumberCraft.pageObjects.EposCreateProposalPage;
import com.CucumberCraft.supportLibraries.DriverManager;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import io.appium.java_client.AppiumDriver;

public class Createproposal extends MasterStepDefs {
	AppiumDriver driver=DriverManager.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 10);
	@Then("^select \"([^\"]*)\" from dropdown$")
	public void select_from_dropdown(String opt) throws Throwable {
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		ProposalInsured(opt,driver);
		
		//driver.findElementByXPath(EposCreateProposalPage.btn_Others).click();
	    
	    
	    
	}

	@Then("^I will enter surname as \"([^\"]*)\"$")
	public void i_will_enter_surname_as(String surname) throws Throwable {
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(EposCreateProposalPage.txt_Surname)));  
	    driver.findElementByXPath(EposCreateProposalPage.txt_Surname).sendKeys(surname);
	    
	}

	@Then("^I will enter Given Name as \"([^\"]*)\"$")
	public void i_will_enter_Given_Name_as(String givenname) throws Throwable {
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(EposCreateProposalPage.txt_Givenname)));
		driver.findElementByXPath(EposCreateProposalPage.txt_Givenname).sendKeys(givenname);
	    
	}

	@Then("^I will select sex as \"([^\"]*)\"$")
	public void i_will_select_sex_as(String gender) throws Throwable {
		Proposalgender(gender,driver);
	    
	}

	@Then("^I will enter Proposal Age as \"([^\"]*)\"$")
	public void i_will_enter_Proposal_Age_as(String age) throws Throwable {
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(EposCreateProposalPage.txt_Proposalage)));
		driver.findElementByXPath(EposCreateProposalPage.txt_Proposalage).clear();
		driver.findElementByXPath(EposCreateProposalPage.txt_Proposalage).sendKeys(age);
		String ageProposal=driver.findElementByXPath(EposCreateProposalPage.txt_Proposalage).getAttribute("value");
		
	if(ageProposal.equalsIgnoreCase(age)){	
		ReportGeneration("Proposal age is modified in proposal", "Pass", "Yes", driver);
	} else {
		ReportGeneration("Proposal age modification failed", "Fail", "Yes", driver);
	}
	    
	}

	
	@Then("^I will select Basic Premium as \"([^\"]*)\"$")
	public void i_will_select_Basic_Premium_as(String currency) throws Throwable {
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//TD[contains(text(),'Basic Premium')] | //TD[contains(text(),'Notional Amount')] | //TD[contains(text(),'Currency')]")));
		driver.findElementByXPath(EposCreateProposalPage.btn_Currency_USD).click();
	    
	}

	@Then("^Select Payment mode as Annual$")
	public void select_Payment_mode_as_Annual() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^I will click on Supplementary Benefit section$")
	public void i_will_click_on_Supplementary_Benefit_section() throws Throwable {
		WebDriverWait wait=new WebDriverWait(driver, 30);
		driver.context("WEBVIEW");
		
		//WebElement supp_Tab=driver.findElementByXPath(EposCreateProposalPage.btn_Supp_tab);
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@name='rider'] | //*[@name='btnRider']")));
		
		proposalSuppNav(driver.findElementByXPath(EposCreateProposalPage.btn_Supp_tab),driver);
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(EposCreateProposalPage.lbl_Prot_Amt)));		
		WebElement lbl_Prot_Amt=driver.findElementByXPath(EposCreateProposalPage.lbl_Prot_Amt);
		if(lbl_Prot_Amt.isEnabled()){
			ReportGeneration("Successfully navigated to supplementary tab in comprop", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Navigation to supplementary tab in comprop failed", "Fail", "Yes", driver);
		}
		

	    
	}
	
	@Given("^I will select \"([^\"]*)\" and \"([^\"]*)\" in the last dropdown$")
	public void i_will_select_and_in_the_last_dropdown(String policyname, String value) throws Throwable {
		CheckBoxListValue(policyname,value,2,driver);
	 
	}
	
	
	@Then("^I will select \"([^\"]*)\" and enter value as \"([^\"]*)\" for CCB$")
	public void i_will_select_and_enter_value_as_for_CCB(String policyname, String amount) throws Throwable {
		CheckBoxValue(policyname,amount,driver);
	    
	}

	@Then("^I will select \"([^\"]*)\" and \"([^\"]*)\" in the second dropdown$")
	public void i_will_select_and_in_the_second_dropdown(String policyname, String value) throws Throwable {
		CheckBoxListValue(policyname,value,driver);
	    
	}
	
	@Then("^scroll to bottom of page$")
	public void scroll_to_bottom_of_page() throws Throwable {
		visualScroll(driver);
	}
	
	@Then("^I will select \"([^\"]*)\"$")
	public void i_will_select(String policyname) throws Throwable {
		CheckBoxClick(policyname,driver);
	 
	}
	

	@Then("^uncheck Accidental and Disability Protection RCC checkbox$")
	public void uncheck_Accidental_and_Disability_Protection_RCC_checkbox() throws Throwable {
	boolean Is_Checked=driver.findElementByXPath(EposCreateProposalPage.btn_RCC).isSelected();
	if(Is_Checked==true){
		driver.findElementByXPath(EposCreateProposalPage.btn_RCC).click();
	}
	}
	
	
	@Then("^I will select \"([^\"]*)\" and Enter Protection amount as \"([^\"]*)\" for HIB$")
	public void i_will_select_and_Enter_Protection_amount_as_for_HIB(String policyname, String amount) throws Throwable {
		CheckBoxValue(policyname,amount,driver);
	    
	}

	@Then("^I will select \"([^\"]*)\" and payor age as \"([^\"]*)\"$")
	public void i_will_select_and_payor_age_as(String policyname, String amount) throws Throwable {
		CheckBoxValue(policyname,amount,driver);
	    
	}


	
	
	
	
	}

	
	

	

	
	

