package com.CucumberCraft.stepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.CucumberCraft.pageObjects.Applyphase;
import com.CucumberCraft.supportLibraries.DriverManager;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.AppiumDriver;

public class Apply3 extends MasterStepDefs {
	AppiumDriver driver = DriverManager.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 60);

	@Given("^I am in Agreements task card$")
	public void i_am_in_Agreements_task_card() throws Throwable {
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.context("NATIVE_APP");
		wait.until(ExpectedConditions
				.presenceOfElementLocated(By.xpath("//UIAStaticText[contains(@label,'Agreements')]")));
		if (driver.findElementByXPath("//UIAStaticText[contains(@label,'Agreements')]").isDisplayed()) {
			ReportGeneration("Navigated to Agreements taskcard", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Navigation toAgreements taskcard failed", "Fail", "Yes", driver);
		}

		driver.context("WEBVIEW");
		SetPageContext("WEBVIEW_2", driver);
	}

	@Then("^I will enter some text in the text box$")
	public void i_will_enter_some_text_in_the_text_box() throws Throwable {
		//driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		driver.context("WEBVIEW");
		SetPageContext("WEBVIEW_2", driver);
		driver.findElementByXPath(Applyphase.lbl_Sig_Own_Handwriting).click();
		//textClick("Tap to do handwriting here", 10, driver);
		//driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		drawLetter("P", driver);
		driver.context("WEBVIEW");
		SetPageContext("WEBVIEW_2", driver);
		driver.findElementByXPath(Applyphase.btn_Save).click();
	}

	@Then("^I will select \"([^\"]*)\" for question \"([^\"]*)\"$")
	public void i_will_select_for_question(String option, String qnno) throws Throwable {
		Applyqns(qnno, option, driver);
	}

	@Then("^I will select \"([^\"]*)\" for question name \"([^\"]*)\"$")
	public void i_will_slect_for_question(String option, String qnname) throws Throwable {
		Applyqnnames("Single", qnname, option, driver);
	}

	@Then("^I will enter Third party Surname as \"([^\"]*)\"$")
	public void i_will_enter_Third_party_Surname_as(String surname) throws Throwable {
		driver.findElementByXPath(Applyphase.txt_Thirdyparty_Surname).sendKeys(surname);
	}

	@Then("^I will enter Third given name as \"([^\"]*)\"$")
	public void i_will_enter_Third_given_name_as(String givenname) throws Throwable {
		driver.findElementByXPath(Applyphase.txt_Thirdyparty_Gnname).sendKeys(givenname);
	}

	@Then("^I will select Sex as \"([^\"]*)\"$")
	public void i_will_select_Sex_as(String gender) throws Throwable {
		ThirdpartyGender(gender, driver);
	}

	@Then("^I will enter passport no as \"([^\"]*)\"$")
	public void i_will_enter_passport_no_as(String passno) throws Throwable {
		driver.findElementByXPath(Applyphase.txt_Thirdyparty_Passno).sendKeys(passno);
	}

	@Then("^I will select Third party Nationality as \"([^\"]*)\"$")
	public void i_will_select_Third_party_Nationality_as(String nationality) throws Throwable {
		ThirdpartyNationality(nationality, driver);
	}

	@Then("^I will select Third party Country of Issue as \"([^\"]*)\"$")
	public void i_will_select_Third_party_Country_of_Issue_as(String country) throws Throwable {
		ThirdpartyCountry(country, driver);
	}

	@Then("^I will enter Third party contact number as \"([^\"]*)\"$")
	public void i_will_enter_Third_party_contact_number_as(String ct_No) throws Throwable {
		driver.findElementByXPath(Applyphase.txt_Thirdyparty_Ctno).sendKeys(ct_No);

	}

	@Then("^I will enter Third party Occupation as \"([^\"]*)\"$")
	public void i_will_enter_Third_party_Occupation_as(String occupation) throws Throwable {
		driver.findElementByXPath(Applyphase.txt_Thirdyparty_Occ).sendKeys(occupation);
	}

	@Then("^I will enter Third party address as \"([^\"]*)\"$")
	public void i_will_enter_Third_party_address_as(String address) throws Throwable {
		driver.findElementByXPath(Applyphase.txt_Thirdyparty_ResAddr).sendKeys(address);
	}

	@Then("^I will enter Third party relationship as \"([^\"]*)\"$")
	public void i_will_enter_Third_party_relationship_as(String relationship) throws Throwable {
		driver.findElementByXPath(Applyphase.txt_Thirdyparty_Rel).sendKeys(relationship);
	}

	@Then("^I will click on close button$")
	public void i_will_click_on_close_button() throws Throwable {
		driver.findElementByXPath(Applyphase.btn_Close).click();
	}

	@Then("^click on cancel button in pop-up displayed$")
	public void click_on_cancel_button_in_pop_up_displayed() throws Throwable {
		
		driver.context("NATIVE");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Applyphase.btn_Cancel)));
		driver.findElementByXPath(Applyphase.btn_Cancel).click();
	}

	@Then("^I will click on Personal Information task card$")
	public void i_will_click_on_Personal_Information_task_card() throws Throwable {
		driver.findElementByXPath(Applyphase.lbl_PersInfo).click();

	}

	@Then("^I will click on change Occupation button and select \"([^\"]*)\"$")
	public void i_will_click_on_change_Occupation_button_and_select(String occupation) throws Throwable {
		driver.context("WEBVIEW");
		SetPageContext("WEBVIEW_2", driver);
		Changeoccupation(occupation, driver);
	}

	@Then("^I will select value \"([^\"]*)\" in all Federal classification drop-down$")
	public void i_will_select_value_in_all_Federal_classification_drop_down(String value) throws Throwable {
		FATCAoptions("Tax", value, driver);
	}

	@Then("^I will select value \"([^\"]*)\" in all Federal payeecode drop-down$")
	public void i_will_select_value_in_all_Federal_payeecode_drop_down(String value) throws Throwable {
		FATCAoptions("Payeecode", value, driver);
	}

	@Then("^I will select value \"([^\"]*)\" in all Federal exemption drop-down$")
	public void i_will_select_value_in_all_Federal_exemption_drop_down(String value) throws Throwable {
		FATCAoptions("Exemption", value, driver);
	}

	@Then("^I will enter \"([^\"]*)\" in FATCA address field$")
	public void i_will_enter_in_FATCA_address_field(String addr) throws Throwable {
		driver.findElementByXPath(Applyphase.txt_Fatca_Addr).sendKeys(addr);
	}

	@Then("^I will enter \"([^\"]*)\" in FATCA City field$")
	public void i_will_enter_in_FATCA_City_field(String city) throws Throwable {
		driver.findElementByXPath(Applyphase.txt_Fatca_City).sendKeys(city);
	}

	@Then("^I will enter \"([^\"]*)\" in FATCA State field$")
	public void i_will_enter_in_FATCA_State_field(String state) throws Throwable {
		driver.findElementByXPath(Applyphase.txt_Fatca_State).sendKeys(state);
	}

	@Then("^I will enter \"([^\"]*)\" in FATCA Country field$")
	public void i_will_enter_in_FATCA_Country_field(String value) throws Throwable {
		FATCAoptions("Country", value, driver);
	}

	@Then("^I will enter \"([^\"]*)\" in FATCA ZIP code field$")
	public void i_will_enter_in_FATCA_ZIP_code_field(String code) throws Throwable {
		driver.findElementByXPath(Applyphase.txt_Fatca_Zip).sendKeys(code);
		if (driver.findElementByXPath(Applyphase.txt_Fatca_Zip).isDisplayed()) {
			ReportGeneration("FATCA fields are entered", "Pass", "Yes", driver);
		} else {
			ReportGeneration("FATCA fields navigation  failed", "Pass", "Yes", driver);
		}
	}

	@Then("^I will enter \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" in FATCA security number field$")
	public void i_will_enter_in_FATCA_security_number_field(String no1, String no2, String no3) throws Throwable {

		FATCAnumber("Securitynumber", no1, no2, no3, driver);
	}

	@Then("^I will enter \"([^\"]*)\",\"([^\"]*)\" in identification number field$")
	public void i_will_enter_in_identification_number_field(String no1, String no2) throws Throwable {
		FATCAnumber("Employernumber", no1, no2, driver);

	}

	@Given("^I will select country as \"([^\"]*)\" in Country/Jurisdiction field and select \"([^\"]*)\" in TIN field for question(\\d+)$")
	public void i_will_select_country_as_in_Country_Jurisdiction_field_and_select_in_TIN_field_for_question(
			String country, String reason, int qnno) throws Throwable {
		TaxResidency(qnno, country, reason, driver);
	}

	@Then("^I will select \"([^\"]*)\" for firstquestion and \"([^\"]*)\" for secondquestion$")
	public void i_will_select_for_firstquestion_and_for_secondquestion(String opt1, String opt2) throws Throwable {

		ApplyQuestions("Q1", opt1, driver);

		if (driver.findElementByXPath(Applyphase.btn_Q1).isDisplayed()) {
			ReportGeneration("Replacement declaration screen displayed", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Replacement declaration screen is not displayed", "Fail", "Yes", driver);
		}

		ApplyQuestions("Q2", opt2, driver);
	}

	@Then("^I will click on Next$")
	public void i_will_click_on_Next() throws Throwable {
		driver.context("WEBVIEW");
		SetPageContext("WEBVIEW_2", driver);
		driver.findElementByXPath(Applyphase.btn_Next).click();
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);

	}

	@Then("^I will slect \"([^\"]*)\" for Third party question$")
	public void i_will_slect_for_Third_party_question(String opt1) throws Throwable {

		ApplyQuestions("Thirdparty_Qn", opt1, driver);

		if (driver.findElementByXPath(Applyphase.btn_Thirdparty).isDisplayed()) {
			ReportGeneration("Third party interest screen displayed", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Third party interest screen is not displayed", "Fail", "Yes", driver);
		}

	}

	@Then("^I will slect \"([^\"]*)\" for CRS question$")
	public void i_will_slect_for_CRS_question(String opt1) throws Throwable {
		visualScroll(driver);
		visualScroll(driver);
		visualScroll(driver);
		visualScroll(driver);
		ApplyQuestions("CRS_Qn", opt1, driver);
		if (driver.findElementByXPath(Applyphase.btn_CRS).isDisplayed()) {
			ReportGeneration("CRS screen displayed", "Pass", "Yes", driver);
		} else {
			ReportGeneration("CRs screen is not displayed", "Fail", "Yes", driver);
		}

	}

	@Given("^I will click on Proceed button in Agreement task card$")
	public void i_will_click_on_Proceed_button_in_Agreement_task_card() throws Throwable {
		driver.context("NATIVE_APP");
		driver.findElementByXPath(Applyphase.btn_Proceed).click();
	}

	@Then("^I will be navigate to E-Disclosure task card$")
	public void i_will_be_navigate_to_E_Disclosure_task_card() throws Throwable {
		driver.context("NATIVE");
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Applyphase.btn_Eng_Disclosure)));
		if (driver.findElementByXPath(Applyphase.btn_Eng_Disclosure).isDisplayed()) {
			ReportGeneration("Navigated to e-Disclosure task card from agreements task card", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Navigation e-Disclosure task card failed from agreements task card", "Fail", "Yes",
					driver);
		}

	}

}
