package com.CucumberCraft.stepDefinitions;
/*
import java.util.HashMap;
import java.util.Map;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.TouchAction;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;

import com.CucumberCraft.supportLibraries.DriverManager;
import com.CucumberCraft.supportLibraries.ReusableMethods;
import com.CucumberCraft.supportLibraries.Util;
import com.CucumberCraft.supportLibraries.WebDriverUtil;
import com.CucumberCraft.pageObjects.*;
import com.CucumberCraft.stepDefinitions.*;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Steps extends MasterStepDefs {
	private LoginPage loginPage;
	private WebDriverUtil webDriverUtil;
	
	static Logger log = Logger.getLogger(Steps.class);
	@SuppressWarnings("rawtypes")
	AppiumDriver driver = DriverManager.getDriver();
	
	public static MoveTransferObject MoveTransferObject1 = new MoveTransferObject();
	 String userName = MoveTransferObject1.getUserName();
	public String CurrDate = ReusableMethods.Getcurrentdate();
	
	@When("^I login to Move Application with valid credentials$")
	public void i_login_to_Move_Application_with_valid_credentials() {
		// DBConnect.ConnectDB();
		loginPage = new LoginPage(driver);
		loginPage.login("testing03", "abcd1234");
	}

	@SuppressWarnings("unused")
	@And("^I naviagte to Steps$")
	public void i_naviagte_to_Steps() {
		try {
			if(driver.findElement(By.xpath(DashboardPage.iOSdashboardstepsDetlnk)).isDisplayed())
				driver.findElement(By.xpath(DashboardPage.iOSdashboardstepsDetlnk)).click();
			if(driver.findElement(By.xpath(StepsPage.iOSweekDaysInfo)).isDisplayed())
				log.info("Steps Page Displayed");
				currentScenario.write("Steps Page Displayed");
				currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		} catch (Exception ex) {
			log.error("Couldn't Click on Steps" + ex.getMessage());
			currentScenario.embed(Util.takeScreenshot(driver), "image/png");	
		}
	}

	@Given("^I am in Main DashBoard Screen$")
	public void i_am_in_Main_DashBoard_Screen() {
		try {
			if (driver.findElementByXPath(DashboardPage.dashboardWelcomeScreen).isDisplayed()) {
				String welcomeMsg = driver.findElementByXPath(DashboardPage.dashboardWelcomeScreen).getText();
				String welcomeMsgVal = "Welcome to MOVE. Time to get started!";
				
				if (welcomeMsg.equals(welcomeMsgVal)) {
					currentScenario.write(welcomeMsgVal + "  is displayed");
				} else {
					currentScenario.write(welcomeMsg + "  is not matached with expected msg");
				}
				log.info("Dashboard Page Displayed");
				currentScenario.embed(Util.takeScreenshot(driver), "image/png");
			}
		} catch (Exception e) {
			log.error("Steps Page not displayed" + e.getMessage());
		}
	}

	@Then("^I will see this week information$")
	public void i_will_see_this_week_information() {
		
		TouchAction touchAction4 = new TouchAction(driver);
		touchAction4.press(634, 594).moveTo(643, 329).release();
		driver.performTouchAction(touchAction4);
			
		
		
		
		
		try {
			if (driver.findElementByXPath(StepsPage.iOSweekStepInfo).isDisplayed()) {
				String WeekSteps = driver.findElementByXPath(StepsPage.iOSweekStepInfo).getAttribute("value");
				log.info("Last 7 Days Steps - " + WeekSteps);
				currentScenario.write("Last 7 Days Steps - " + WeekSteps);
				String WeekDays = driver.findElementByXPath(StepsPage.iOSweekDaysInfo).getAttribute("value");
				log.info("Last 7 Days Month Range - " + WeekDays);
				currentScenario.write("Last 7 Days Month Range - " + WeekDays);
			}
		} catch (Exception e) {
			log.error("Last 7 Days information not displayed" + e.getMessage());
		}
	}

	@SuppressWarnings("unused")
	@Then("^I see last Ninty days Information$")
	public void i_see_last_Ninty_days_Information() {

		Map<String, Object> params18 = new HashMap<>();
		params18.put("content", "PUBLIC:Apps\\iOS\\MOVE\\Images\\Apple_iPhone-7_161107_170407.png");
		params18.put("scrolling", "scroll");
		params18.put("maxscroll", "1");
		params18.put("next", "SWIPE_UP");
		Object result18 = driver.executeScript("mobile:image:find", params18);

		try {
			if (driver.findElementByXPath(StepsPage.threeMonthsStepInfo).isDisplayed()) {
				String ThreeMonthsSteps = driver.findElementByXPath(StepsPage.threeMonthsStepInfo)
						.getAttribute("value");
				log.info("Last 90 Days Steps - " + ThreeMonthsSteps);
				currentScenario.write("Last 90 Days Steps - " + ThreeMonthsSteps);
				String ThreeMonthsdays = driver.findElementByXPath(StepsPage.threeMonthsDaysInfo).getAttribute("value");
				log.info("Last 90 Month Range - " + ThreeMonthsdays);
				currentScenario.write("Last 90 Month Range - " + ThreeMonthsdays);
				currentScenario.embed(Util.takeScreenshot(driver), "image/png");
			}
		} catch (Exception e) {
			log.error("Last 90 Days information not displayed" + e.getMessage());
		}
	}



switchToContext(driver, "WEBVIEW");
driver.findElementByXPath("//*[@id=\"personalInfoPolicyownerInsuredDateOfBirth-control\"]//*[@class=\"date-picker-icon\"]").click();


}
*/


