package com.CucumberCraft.stepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.CucumberCraft.pageObjects.Applyphase;
import com.CucumberCraft.pageObjects.EposAddFNAPage;
import com.CucumberCraft.pageObjects.EposCreateProposalPage;
import com.CucumberCraft.pageObjects.Eposgoals;
import com.CucumberCraft.supportLibraries.DriverManager;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.AppiumDriver;

public class FNAErrorValidation extends MasterStepDefs {
	AppiumDriver driver=DriverManager.getDriver();
	WebDriverWait wait=new WebDriverWait(driver,60);
	public  boolean resultBool;
	
	@Given("^I am in Proposal screen$")
	public void i_am_in_Proposal_screen() throws Throwable {
		driver.context("WEBVIEW");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		if(driver.findElementByXPath(EposCreateProposalPage.lbl_Proposal).isDisplayed()){
			ReportGeneration("Navigated to Proposal screen", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Navigated to Proposal screen failed", "Fail", "Yes", driver);
	    
	}
	}
	@When("^I click on Close button from top left corner in comprop$")
	public void i_click_on_Close_button_from_top_left_corner_in_comprop() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}
	@Then("^I will select \"([^\"]*)\" and  click on APPLY/REGENERATE button$")
	public void i_will_select_and_click_on_APPLY_REGENERATE_button(String arg1) throws Throwable {
		
		
		driver.context("WEBVIEW");
		ProposalClick(arg1, driver);
		Waitforloading(Applyphase.ele_Ldg_PDF, driver);
		driver.context("WEBVIEW");
		driver.findElementByXPath("//BUTTON[contains(text(),'Apply / Regenerate')]").click();

		
	}
	

	
	
	@Then("^I will be navigated to Apply phase$")
	public void i_will_be_navigated_to_Apply_phase() throws Throwable {
		
		WebDriverWait wait=new WebDriverWait(driver, 60);
		driver.context("WEBVIEW");
		SetPageContext("WEBVIEW_2",driver);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Applyphase.lbl_PICS)));
		WebElement pics_label=driver.findElementByXPath(Applyphase.lbl_PICS);
		//textCheckpoint("Personal Information", 5, driver);
		if (pics_label.isDisplayed()) {
		//if (resultBool = true) {
			ReportGeneration("Navigated to Personal Information taskcard", "Pass", "Yes", driver);
		} else if (resultBool = false) {
			ReportGeneration("Navigated to Personal Information taskcard failed", "Fail", "Yes", driver);
		}
	}
	
	
	@Then("^I will click on APPLY/REGENERATE button$")
	public void i_will_click_on_APPLY_REGENERATE_button() throws Throwable {
		driver.context("NATIVE");
		driver.findElementByXPath(EposCreateProposalPage.btn_Apply_Regn).click();
		
	    
	}

	@Then("^click on radio button$")
	public void click_on_radio_button() throws Throwable {
		WebDriverWait wait=new WebDriverWait(driver, 30);
		driver.context("WEBVIEW");
		SetPageContext("WEBVIEW_2",driver);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(EposCreateProposalPage.rdn_Proposal)));
		driver.findElementByXPath(EposCreateProposalPage.rdn_Proposal).click();
	    
	}

	@Then("^click on APPLY$")
	public void click_on_APPLY() throws Throwable {
		driver.findElementByXPath(EposCreateProposalPage.btn_Apply).click();
		
		driver.context("NATIVE_APP");
		//driver.findElementByXPath(EposCreateProposalPage.btn_Dwn).click();
		
		
		driver.findElementByXPath("//*[@label=\"Yes\"]").click();
			    
	}
	@Then("^navigated to Personal Information Collection Statement page$")
	public void navigated_to_Personal_Information_Collection_Statement_page() throws Throwable {
	    driver.context("NATIVE");
	    wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//UIAStaticText[contains(@label,'Personal Information Collection Statement')]")));
	    if (driver.findElementByXPath("//UIAStaticText[contains(@label,'Personal Information Collection Statement')]").isDisplayed()){
			ReportGeneration("Navigated to Personal Information Collection Statement", "Pass", "Yes", driver);
		} else  {
			ReportGeneration("Navigated to Personal  Information Collection Statement failed", "Fail", "Yes", driver);
		}
	 
	}
	
	
	@Then("^I will click on Close button in FNA selection page$")
	public void i_will_click_on_Close_button_in_FNA_selection_page() throws Throwable {
	   driver.context("WEBVIEW");
	   SetPageContext("WEBVIEW_2",driver);
	   driver.findElementByXPath(EposAddFNAPage.btn_FNA_Close).click();
	}

	@Then("^I will click on edit icon in the proposal$")
	public void i_will_click_on_edit_icon_in_the_proposal() throws Throwable {
	driver.context("NATIVE");
	  driver.findElementByXPath(EposCreateProposalPage.btn_Edit_Prop).click();
	  Waitforloading(EposCreateProposalPage.ldg_Create_Prop,driver);
	}
	
	@Then("^I will login to comprop$")
	public void i_will_login_to_comprop() throws Throwable {
	   WebDriverWait wait=new WebDriverWait(driver, 60);
	   try{
	   driver.context("NATIVE_APP");
	   wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(EposCreateProposalPage.btn_Popup)));
	   }catch(Exception ex){}
	   CompropLoginTest("Abcd1234", driver);
	}



	
	
	@Then("^I will verify the error message \"([^\"]*)\"$")
	public void i_will_verify_the_error_message(String arg1) throws Throwable {
		
		driver.context("WEBVIEW_2");
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@class='proposal-item-ul item-error ng-scope']")));
		String error_msg=driver.findElementByXPath("//*[@class='proposal-item-ul item-error ng-scope']").getText();
		if(error_msg.equalsIgnoreCase(arg1))
		{
			ReportGeneration("Error message is validated successfully", "Pass", "Yes", driver);
			
		}else{
			ReportGeneration("Error message validation failed", "Fail", "Yes", driver);
		}
		driver.findElementByXPath(Eposgoals.btn_Close).click();
		//driver.findElementByXPath(EposCreateProposalPage.btn_Popup).click();
		
	    
	}



}
