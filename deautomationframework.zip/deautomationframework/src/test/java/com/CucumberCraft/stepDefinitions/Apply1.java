package com.CucumberCraft.stepDefinitions;

import org.openqa.selenium.support.ui.FluentWait;

import java.util.HashSet;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.CucumberCraft.pageObjects.Applyphase;
import com.CucumberCraft.pageObjects.EposAddFNAPage;
import com.CucumberCraft.pageObjects.EposCreateProposalPage;
import com.CucumberCraft.pageObjects.LoginEPOSAppPage;
import com.CucumberCraft.supportLibraries.DriverManager;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.AppiumDriver;

public class Apply1 extends MasterStepDefs {
	AppiumDriver driver = DriverManager.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 60);
	Set<String> set = new HashSet();
	public boolean resultBool;
	public String handleName;
	

	@Given("^I am in comprop page$")
	public void i_am_in_comprop_page() throws Throwable {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.context("WEBVIEW");
		Waitforloading(Applyphase.ele_Ldg_PDF, driver);
		driver.context("WEBVIEW");
		if (driver.findElementByXPath(EposCreateProposalPage.lbl_Proposallst).isDisplayed()) {
			ReportGeneration("Navigated to Proposal page", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Navigation to Proposal page failed", "Fail", "Yes", driver);
		}
	}

	@Given("^I am in PICS task card$")
	public void i_am_in_PICS_task_card() throws Throwable {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		ScrollAbove(driver);
		driver.context("WEBVIEW");
		//driver.context("WEBVIEW_2");
		//driver.context("WEBVIEW");
		SetPageContext("WEBVIEW_2",driver);
		WebDriverWait wait=new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath(Applyphase.lbl_PICS)));
		if(driver.findElementByXPath(Applyphase.lbl_PICS).isDisplayed()){
			ReportGeneration("Navigated to PICS taskcard", "Pass", "Yes", driver);
		}else{
			ReportGeneration("Navigation to PICS taskcard failed", "Fail", "Yes", driver);
		}
		
		
		
		
	}

	
	@Then("^I will scroll down the page completely$")
	public void i_will_scroll_down_the_page_completely() throws Throwable {
		driver.context("WEBVIEW");
		SetPageContext("WEBVIEW_2",driver);
		ScrollAbove(driver);
		ScrollAbove(driver);
		ScrollAbove(driver);
		ScrollAbove(driver);
		ScrollAbove(driver);
		ScrollAbove(driver);
		ScrollAbove(driver);
		ScrollAbove(driver);
		ScrollAbove(driver);
		ScrollAbove(driver);
		ScrollAbove(driver);
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);

	}

	@Then("^click on declaration checkbox$")
	public void click_on_declaration_checkbox() throws Throwable {

		Apply_CheckBoc(driver);

	}

	@Then("^Click on Confirm & Proceed button$")
	public void click_on_Confirm_Proceed_button() throws Throwable {
		driver.context("NATIVE_APP");
		driver.findElementByXPath(EposAddFNAPage.btn_cnfr_proceed).click();

	}

	@Then("^I will be navigated to Personal Information task card$")
	public void i_will_be_navigated_to_Personal_Information_task_card() throws Throwable {
		driver.context("WEBVIEW");
		SetPageContext("WEBVIEW_2", driver);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Applyphase.lbl_Chinese)));

		driver.context("NATIVE_APP");
		if (driver.findElementByXPath("//UIAStaticText[contains(@label,'Personal Information')]").isDisplayed()) {
			ReportGeneration("Navigated to Personal Information taskcard", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Navigation to Personal Information taskcard failed", "Fail", "Yes", driver);
		}

	}

	@Then("^I will select Date  as '(\\d+)' and month as \"([^\"]*)\" and year as \"([^\"]*)\"$")
	public void i_will_select_Date_as_and_month_as_and_year_as(int day, String month, String year) throws Throwable {

		SetPageContext("WEBVIEW_2", driver);

		Datepick(day, month, year, driver);

	}

	@Then("^scroll the page above$")
	public void scroll_the_page_above() throws Throwable {

		visualScrollPage2(driver);
	}

	@Then("^Select Identity Document type as \"([^\"]*)\" and enter no as \"([^\"]*)\" for Insured$")
	public void select_Identity_Document_type_as_and_enter_no_as_for_Insured(String identitydoctype, String docno)
			throws Throwable {
		Doc_Selection("Insured", identitydoctype, driver);
		driver.findElementByXPath(Applyphase.txt_Identity_Doc_no_Ins).sendKeys(docno);
		visualScrollPage2(driver);
	}

	@Then("^I will select Nationality as \"([^\"]*)\" for Insured$")
	public void i_will_select_Nationality_as_for_Insured(String nationality) throws Throwable {
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		ApplyCountrySelection("Insured", "Nationality", nationality, driver);
	}

	@Then("^I will click on select occupation and select \"([^\"]*)\" for Insured$")
	public void i_will_click_on_select_occupation_and_select_for_Insured(String occupation) throws Throwable {
		Selectvalue("Insured", occupation, driver);
	}

	@Then("^select \"([^\"]*)\" button for senior management for Insured$")
	public void select_button_for_senior_management_for_Insured(String arg1) throws Throwable {
		SetPageContext("WEBVIEW_2", driver);
		ApplyYesorNo("Insured", "Senior_Management", arg1, driver);
	}

	@Then("^enter Place of Birth as \"([^\"]*)\"$")
	public void enter_Place_of_Birth_as(String placeofbirth) throws Throwable {
		driver.findElementByXPath(Applyphase.txt_Place_Birth).sendKeys(placeofbirth);
		// visualScrollPage2(driver);

	}

	@Then("^Select country as \"([^\"]*)\"$")
	public void select_country_as(String countryofbirth) throws Throwable {
		ApplyCountrySelection("Place_Birth", countryofbirth, driver);

	}

	@Then("^I will select Relationship to Proposed Insured as \"([^\"]*)\"$")
	public void i_will_select_Relationship_to_Proposed_Insured_as(String relationship) throws Throwable {
		Relationship(relationship, driver);

	}

	@Then("^I will select Relationship to Proposed Indured as \"([^\"]*)\" for payor$")
	public void i_will_select_Relationship_to_Proposed_Indured_as_for_payor(String relationship) throws Throwable {

		Relationship("Payor", relationship, driver);

	}

	@Then("^Select Identity Document type as \"([^\"]*)\" and enter no as \"([^\"]*)\" for Payor$")
	public void select_Identity_Document_type_as_and_enter_no_as_for_Payor(String identitydoctype, String docno)
			throws Throwable {

		Doc_Selection("Payor", identitydoctype, driver);
		driver.findElementByXPath(Applyphase.txt_Identity_Doc_no_Payor).sendKeys(docno);
		visualScrollPage2(driver);
	}

	@Then("^I will select Nationality as \"([^\"]*)\" for Payor$")
	public void i_will_select_Nationality_as_for_Payor(String nationality) throws Throwable {

		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		ApplyCountrySelection("Payor", "Nationality", nationality, driver);
	}

	@Then("^I will click on select occupation and select \"([^\"]*)\" for Payor$")
	public void i_will_click_on_select_occupation_and_select_for_Payor(String occupation) throws Throwable {
		Selectvalue("Payor", occupation, driver);
	}

	@Then("^select \"([^\"]*)\" button for senior management for Payor$")
	public void select_button_for_senior_management_for_Payor(String arg1) throws Throwable {

		SetPageContext("WEBVIEW_2", driver);
		ApplyYesorNo("Payor", "Senior_Management", arg1, driver);
	}

	@Then("^Select Identity Document type as \"([^\"]*)\" and enter no as \"([^\"]*)\"$")
	public void select_Identity_Document_type_as_and_enter_no_as(String identitydoctype, String docno)
			throws Throwable {
		Doc_Selection(identitydoctype, driver);
		driver.findElementByXPath(Applyphase.txt_Identity_Doc_no).sendKeys(docno);
		// visualScrollPage2(driver);

	}
	
	@Given("^Select document issue country  as \"([^\"]*)\"$")
	public void select_document_issue_country_as(String cntyname) throws Throwable {
		docIssueCountry(cntyname,driver);
	}

	@Then("^I will select Nationality as \"([^\"]*)\"$")
	public void i_will_select_Nationality_as(String nationality) throws Throwable {

		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		ApplyCountrySelection("Nationality", nationality, driver);

	}

	@Then("^I will select Language as \"([^\"]*)\" and Policy Contract as \"([^\"]*)\"$")
	public void i_will_select_Language_as_and_Policy_Contract_as(String language, String contractlang)
			throws Throwable {
		Apply_Language("Language", language, driver);
		Apply_Language("Contract_Lang", contractlang, driver);

	}

	@Then("^I will click on select occupation and select \"([^\"]*)\"$")
	public void i_will_click_on_select_occupation_and_select(String occupation) throws Throwable {
		Selectvalue(occupation, driver);

	}

	@Then("^select \"([^\"]*)\" button for senior management$")
	public void select_button_for_senior_management(String option) throws Throwable {
		SetPageContext("WEBVIEW_2", driver);
		ApplyYesorNo("Senior_Management", option, driver);

	}

	@Then("^I will enter average monthly income as \"([^\"]*)\" and Employer as \"([^\"]*)\" for Payor$")
	public void i_will_enter_average_monthly_income_as_and_Employer_as_for_Payor(String monthly_inc, String arg2)
			throws Throwable {
		driver.findElementByXPath(Applyphase.txt_Avg_Mnt_Inc_Payor).sendKeys(monthly_inc);

	}

	@Then("^I will enter current residence address as \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\" for Payor$")
	public void i_will_enter_current_residence_address_as_and_for_Payor(String resadd1, String resadd2, String resadd3,
			String resadd4) throws Throwable {
		ApplyAddress("Payor", "Residence", resadd1, resadd2, resadd3, resadd4, driver);
		visualScrollPage2(driver);

	}

	@Then("^I will select country as \"([^\"]*)\" for Payor$")
	public void i_will_select_country_as_for_Payor(String arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@Then("^I will select Height as \"([^\"]*)\" and enter \"([^\"]*)\" for Payor$")
	public void i_will_select_Height_as_and_enter_for_Payor(String arg1, String arg2) throws Throwable {
		Apply_HeightWeight("Payor", "Height", arg1, arg2, driver);
	}

	@Then("^I will select Weight as \"([^\"]*)\" and enter \"([^\"]*)\" for Payor$")
	public void i_will_select_Weight_as_and_enter_for_Payor(String arg1, String arg2) throws Throwable {
		Apply_HeightWeight("Payor", "Weight", arg1, arg2, driver);
	}

	@Then("^I will select \"([^\"]*)\" for smoking habit question for Payor$")
	public void i_will_select_for_smoking_habit_question_for_Payor(String option) throws Throwable {
		Apply_Smokingfield("Payor", option, driver);

	}

	@Then("^I will select \"([^\"]*)\" for alcohol question for Payor$")
	public void i_will_select_for_alcohol_question_for_Payor(String option) throws Throwable {
		Apply_DrinkingfieldNo("Payor", option, driver);
	}

	@Then("^I will enter average monthly income as \"([^\"]*)\" and Employer as \"([^\"]*)\"$")
	public void i_will_enter_average_monthly_income_as_and_Employer_as(String monthlyincome, String emp_name)
			throws Throwable {
		driver.findElementByXPath(Applyphase.txt_Avg_Mnt_Inc).sendKeys(monthlyincome);
		driver.findElementByXPath(Applyphase.txt_Name_Emp).sendKeys(emp_name);
		// visualScrollPage2(driver);

	}

	@Then("^I will enter average monthly income as \"([^\"]*)\" for insured$")
	public void i_will_enter_average_monthly_income_as_for_insured(String mnthly_income) throws Throwable {
		driver.findElementByXPath(Applyphase.txt_Avg_Mnt_Inc_Ins).sendKeys(mnthly_income);

	}

	@Then("^I will enter name of  Employer as \"([^\"]*)\" for insured$")
	public void i_will_enter_name_of_Employer_as_for_insured(String cpy_name_Ins) throws Throwable {
		driver.findElementByXPath(Applyphase.txt_Name_Emp_Ins).sendKeys(cpy_name_Ins);
	}
	
	
	@Then("^I will enter average monthly income as \"([^\"]*)\"$")
	public void i_will_enter_average_monthly_income_as(String income) throws Throwable {
		driver.findElementByXPath(Applyphase.txt_Avg_Mnt_Inc).sendKeys(income);

	}

	@Then("^I will enter office address as \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\" for Insured$")
	public void i_will_enter_office_address_as_and_for_Insured(String offadd1, String offadd2, String offadd3,
			String offadd4) throws Throwable {
		ApplyAddress("Insured", "Office", offadd1, offadd2, offadd3, offadd4, driver);
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		visualScrollPage2(driver);
	}

	@Then("^I will enter current residence address as \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\" for Insured$")
	public void i_will_enter_current_residence_address_as_and_for_Insured(String resadd1, String resadd2,
			String resadd3, String resadd4) throws Throwable {
		ApplyAddress("Insured", "Residence", resadd1, resadd2, resadd3, resadd4, driver);
		visualScrollPage2(driver);
	}

	@Then("^I will select Height as \"([^\"]*)\" and enter \"([^\"]*)\" for Insured$")
	public void i_will_select_Height_as_and_enter_for_Insured(String arg1, String arg2) throws Throwable {
		Apply_HeightWeight("Insured", "Height", arg1, arg2, driver);
	}

	@Then("^I will select Weight as \"([^\"]*)\" and enter \"([^\"]*)\"for Insured$")
	public void i_will_select_Weight_as_and_enter_for_Insured(String arg1, String arg2) throws Throwable {
		Apply_HeightWeight("Insured", "Weight", arg1, arg2, driver);
	}

	@Then("^I will select \"([^\"]*)\" for smoking habit question for Insured$")
	public void i_will_select_for_smoking_habit_question_for_Insured(String option) throws Throwable {
		Apply_Smokingfield("Insured", option, driver);
		visualScrollPage2(driver);
	}

	@Then("^I will select \"([^\"]*)\" for alcohol question for Insured$")
	public void i_will_select_for_alcohol_question_for_Insured(String alc_option) throws Throwable {
		
		Apply_DrinkingfieldNo("Insured", alc_option, driver);
	}

	@Then("^I will select \"([^\"]*)\" for force and pending insurance question for Insured$")
	public void i_will_select_for_force_and_pending_insurance_question_for_Insured(String opt_pendinginsurance)
			throws Throwable {
		ApplyYesorNo("Insured", "Force_Pending", opt_pendinginsurance, driver);
	}

	@Then("^I will enter office address as \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_will_enter_office_address_as_and(String offadd1, String offadd2, String offadd3, String offadd4)
			throws Throwable {
		ApplyAddress("Office", offadd1, offadd2, offadd3, offadd4, driver);
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		// visualScrollPage2(driver);

	}

	@Then("^I will enter current residence address as \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_will_enter_current_residence_address_as_and(String resadd1, String resadd2, String resadd3,
			String resadd4) throws Throwable {
		ApplyAddress("Residence", resadd1, resadd2, resadd3, resadd4, driver);
		// visualScrollPage2(driver);
	}

	@Then("^I will enter current residence address as \"([^\"]*)\"$")
	public void i_will_enter_current_residence_address_as(String arg1) throws Throwable {

	}

	@Then("^I will select country as \"([^\"]*)\"$")
	public void i_will_select_country_as(String country) throws Throwable {
		ApplyCountrySelection("Country", country, driver);
		// visualScrollPage2(driver);
	}

	@Then("^I will select address Language as \"([^\"]*)\"$")
	public void i_will_select_address_Language_as(String lang) throws Throwable {
		Apply_Language("Addr_Lang", lang, driver);

	}

	@Then("^I will select \"([^\"]*)\" for same as residence address$")
	public void i_will_select_for_same_as_residence_address(String option) throws Throwable {
		ApplyYesorNo("Corr_Res", option, driver);

	}

	@Then("^I will select \"([^\"]*)\" for Correspondence address to this policy only question$")
	public void i_will_select_for_Correspondence_address_to_this_policy_only_question(String corr_option)
			throws Throwable {
		ApplyYesorNo("Corr_Policy", corr_option, driver);
		// visualScrollPage2(driver);

	}

	@Then("^I will select \"([^\"]*)\" for SMS question$")
	public void i_will_select_for_SMS_question(String SMS_option) throws Throwable {
		ApplyYesorNo("SMS", SMS_option, driver);

	}

	@Then("^I will select \"([^\"]*)\" for e_statement Service$")
	public void i_will_select_for_e_statement_Service(String e_option) throws Throwable {
		ApplyYesorNo("Statement", e_option, driver);

	}

	@Then("^I will select Height as \"([^\"]*)\" and enter \"([^\"]*)\"$")
	public void i_will_select_Height_as_and_enter(String h_measure, String h_value) throws Throwable {
		Apply_HeightWeight("Height", h_measure, h_value, driver);

	}

	@Then("^I will select Weight as \"([^\"]*)\" and enter \"([^\"]*)\"$")
	public void i_will_select_Weight_as_and_enter(String w_measure, String w_value) throws Throwable {
		Apply_HeightWeight("Weight", w_measure, w_value, driver);

	}

	@Then("^I will select \"([^\"]*)\" for smoking habit question$")
	public void i_will_select_for_smoking_habit_question(String smoke_option) throws Throwable {
		Apply_Smokingfield(smoke_option, driver);
		// visualScrollPage2(driver);

	}

	@Then("^I will select \"([^\"]*)\" for alcohol question$")
	public void i_will_select_for_alcohol_question(String alc_option) throws Throwable {
		Apply_DrinkingfieldNo(alc_option, driver);

	}

	@Then("^I will select \"([^\"]*)\" for force and pending insurance question$")
	public void i_will_select_for_force_and_pending_insurance_question(String opt_pendinginsurance) throws Throwable {
		ApplyYesorNo("Force_Pending", opt_pendinginsurance, driver);

	}

	;

	@Then("^I will select \"([^\"]*)\" for last question$")
	public void i_will_select_for_last_question(String type_hand) throws Throwable {
		Apply_Select("Handed", type_hand, driver);

	}

	@Then("^I will click on Proceed$")
	public void i_will_click_on_Proceed() throws Throwable {
		driver.context("NATIVE_APP");
		driver.findElementByXPath(Applyphase.btn_Proceed).click();

	}
	
	@Then("^i will click on OK in the error popup displayed in apply phase$")
	public void i_will_click_on_OK_in_the_error_popup_displayed_in_apply_phase() throws Throwable {

		driver.context("NATIVE_APP");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Applyphase.btn_OK)));
		driver.findElementByXPath(Applyphase.btn_OK).click();
		System.out.println("Clicked");
		driver.context("WEBVIEW");
		SetPageContext("WEBVIEW_2",driver);
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(Applyphase.btn_OK)));
		
	}

	
	
	@Then("^i will click on OK in the popup displayed in apply phase$")
	public void i_will_click_on_OK_in_the_popup_displayed_in_apply_phase() throws Throwable {
		driver.context("NATIVE");
		driver.findElementByXPath(Applyphase.btn_OK).click();
		driver.context("WEBVIEW");
		SetPageContext("WEBVIEW_2",driver);
	}

	
	@Given("^I will verify the occupation error message \"([^\"]*)\" is displayed$")
	public void i_will_verify_the_occupation_error_message_is_displayed(String errmessage) throws Throwable {
	 driver.context("NATIVE");
	 String v_ret_msg=driver.findElementByXPath(Applyphase.lbl_Occ_Err).getText();
	 if(v_ret_msg.equalsIgnoreCase(errmessage)){
		 ReportGeneration("Occupation error message validated successfullty", "Pass", "Yes", driver);
		} else {
		ReportGeneration("Occupation error message validated failed", "Fail", "Yes", driver);
		}
		 
	}

	@Then("^click on Proposed Insured section$")
	public void click_on_Proposed_Insured_section() throws Throwable {
		driver.context("WEBVIEW");
		SetPageContext("WEBVIEW_2",driver);
		driver.findElementByXPath(Applyphase.lbl_Prop_Insured).click();

	}

	@Given("^I am in Proposed Insured section$")
	public void i_am_in_Proposed_Insured_section() throws Throwable {

	}

	@Then("^I will click on Payor section$")
	public void i_will_click_on_Payor_section() throws Throwable {
		driver.findElementByXPath(Applyphase.lbl_Payor).click();

	}

	@Then("^I will slect \"([^\"]*)\" for Payor same as Policyowner question$")
	public void i_will_slect_for_Payor_same_as_Policyowner_question(String ans) throws Throwable {
		PayorQn(ans, driver);

	}

	@Then("^enter surname as \"([^\"]*)\"$")
	public void enter_surname_as(String surname) throws Throwable {
		driver.findElementByXPath(Applyphase.txt_Payorsurname).sendKeys(surname);

	}

	@Then("^enter Given name as \"([^\"]*)\"$")
	public void enter_Given_name_as(String givenname) throws Throwable {
		driver.findElementByXPath(Applyphase.txt_Payorgivenname).sendKeys(givenname);

	}

	@Then("^select Sex as \"([^\"]*)\"$")
	public void select_Sex_as(String sex) throws Throwable {
		Payorsex(sex, driver);

	}

	@Then("^i will be navigated to Solution Information task card$")
	public void i_will_be_navigated_to_Solution_Information_task_card() throws Throwable {
		driver.context("NATIVE");
		try{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//UIAStaticText[contains(@label,'Solution Information')]")));
		}catch(Exception ex){}
		
		if (driver.findElementByXPath("//UIAStaticText[contains(@label,'Solution Information')]").isDisplayed()) {
			ReportGeneration("Navigated to Solution Information taskcard", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Navigation to Solution Information taskcard failed", "Fail", "Yes", driver);
		}

	}

}
