package com.CucumberCraft.stepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.CucumberCraft.pageObjects.Applyphase;
import com.CucumberCraft.supportLibraries.DriverManager;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.AppiumDriver;



public class Apply4 extends MasterStepDefs {
	
	
	public boolean resultBool;
	public String txt_healthprob1;
	public String txt_healthprob2;
	public String txt_healthprob3;
	AppiumDriver driver=DriverManager.getDriver();
	@Given("^I am in E-Disclosure task card$")
	public void i_am_in_E_Disclosure_task_card() throws Throwable {
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.context("NATIVE");
		WebDriverWait wait=new WebDriverWait(driver,60);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Applyphase.btn_Eng_Disclosure)));
		if(driver.findElementByXPath(Applyphase.btn_Eng_Disclosure).isDisplayed()){
			ReportGeneration("Navigated to e-Disclosure task card", "Pass", "Yes", driver);
		}else{
			ReportGeneration("Navigation e-Disclosure task card failed", "Fail", "Yes", driver);
		}
		
	    
	}

	@When("^I click on English in the popup$")
	public void i_click_on_English_in_the_popup() throws Throwable {
		
		driver.context("NATIVE");
		try{
	    if(driver.findElementByXPath(Applyphase.btn_Eng_Disclosure).isDisplayed()){
	    	driver.findElementByXPath(Applyphase.btn_Eng_Disclosure).click();
	    }
		}catch(Exception ex){}
		driver.context("WEBVIEW");
		SetPageContext("WEBVIEW_2",driver);
	}

	@Then("^I will select \"([^\"]*)\" for first questions$")
	public void i_will_select_for_first_questions(String opt1) throws Throwable {
		driver.context("WEBVIEW");
		SetPageContext("WEBVIEW_2",driver);
		//driver.findElementByXPath("//BUTTON[contains(text(),'No')]").click();
		ApplyQuestions("Phase4_Qn1",opt1,driver);
	    
	}
	
	@Then("^I will select \"([^\"]*)\" in question \"([^\"]*)\"$")
	public void i_will_select_in_question(String opt, String qnname) throws Throwable {
		driver.context("WEBVIEW");
		SetPageContext("WEBVIEW_2",driver);
		Applyqnnames("Multiple",qnname,opt,driver);
	}

	

	@Then("^I will select \"([^\"]*)\" for second question$")
	public void i_will_select_for_second_question(String opt1) throws Throwable {
		ApplyQuestions("Phase4_Qn2",opt1,driver);
		
	    
	}

	@Then("^I will select \"([^\"]*)\" for third question$")
	public void i_will_select_for_third_question(String opt1) throws Throwable {
		ApplyQuestions("Phase4_Qn3",opt1,driver);
		driver.findElementByXPath(Applyphase.btn_Next).click();

	    
	}

	@Then("^I will select \"([^\"]*)\" in second page  question$")
	public void i_will_select_in_second_page_question(String opt1) throws Throwable {
		ApplyQuestions("Phase4_P2",opt1,driver);
		 driver.findElementByXPath(Applyphase.btn_Next).click();
		 
		
	    
	}
	@Then("^I will select \"([^\"]*)\" in third  page  question$")
	public void i_will_select_in_third_page_question(String opt1) throws Throwable {
		ApplyQuestions("Phase4_P3",opt1,driver);
		 driver.findElementByXPath(Applyphase.btn_Next).click();
		 
		
		
	}
	
	@Then("^I will select \"([^\"]*)\" in fourth  page  question$")
	public void i_will_select_in_fourth_page_question(String opt1) throws Throwable {
		ApplyQuestions("Phase4_P4",opt1,driver);
		 driver.findElementByXPath(Applyphase.btn_Next).click();
		 driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);

	}
	@Then("^I will select \"([^\"]*)\" in Last five years question$")
	public void i_will_select_in_Last_five_years_question(String opt1) throws Throwable {
		ApplyQuestions("Phase4_P5",opt1,driver);
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		
	    
	}

	@Then("^I will click on Select button and select \"([^\"]*)\"$")
	public void i_will_click_on_Select_button_and_select(String arg1) throws Throwable {
		Addhealthproblem(arg1,driver);
	    
	}
	
	@Given("^I will enter \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" in all text box for disease details$")
	public void i_will_enter_in_all_text_box_for_disease_details(String detail1, String detail2, String detail3) throws Throwable {
		Diseasedetails(detail1,detail2,detail3,driver);
	}

	
	
	@Then("^I will enter \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" in all text box$")
	public void i_will_enter_in_all_text_box(String arg1, String arg2, String arg3) throws Throwable {
		txt_healthprob1=arg1;
		txt_healthprob2=arg2;
		txt_healthprob3=arg3;
		
		driver.findElementByXPath("//*[@class=\"form-control ng-pristine ng-untouched ng-valid ng-scope\"]").click();
		driver.findElementByXPath("//*[@class=\"form-control ng-pristine ng-untouched ng-valid ng-scope\"]").sendKeys(txt_healthprob1);
		visualScrollPage2(driver);
		
	    
	}

	@Then("^I will select \"([^\"]*)\" for more than ten consecutive days\\?$")
	public void i_will_select_for_more_than_ten_consecutive_days(String arg1) throws Throwable {
		ApplyQuestions("Medical_Q1",arg1,driver);
		//driver.findElementByXPath("//BUTTON[contains(text(),'No')]").click();
		
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		driver.findElementByXPath("//*[@class=\"form-control ng-pristine ng-untouched ng-valid ng-scope\"]").click();
		driver.findElementByXPath("//*[@class=\"form-control ng-pristine ng-untouched ng-valid ng-scope\"]").sendKeys(txt_healthprob2);
		visualScrollPage2(driver);
	   
	}

	@Then("^I will select \"([^\"]*)\" for Surgical procedure question$")
	public void i_will_select_for_Surgical_procedure_question(String arg1) throws Throwable {
		ApplyQuestions("Medical_Q2",arg1,driver);
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		driver.findElementByXPath("//*[@class=\"form-control ng-pristine ng-untouched ng-valid ng-scope\"]").click();
		driver.findElementByXPath("//*[@class=\"form-control ng-pristine ng-untouched ng-valid ng-scope\"]").sendKeys(txt_healthprob3);
		visualScrollPage2(driver);
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
	    
	}

	@Then("^I will select \"([^\"]*)\" for last ten years question$")
	public void i_will_select_for_last_ten_years_question(String arg1) throws Throwable {
		ApplyQuestions("Medical_Q3",arg1,driver);
	    
	}

	@Then("^I will select \"([^\"]*)\" for Is this intention question$")
	public void i_will_select_for_Is_this_intention_question(String arg1) throws Throwable {
		ApplyQuestions("Medical_Q4",arg1,driver);
		
	    
	}
	@Then("^I will select \"([^\"]*)\" for last five years question$")
	public void i_will_select_for_last_five_years_question(String arg1) throws Throwable {
		ApplyQuestions("Medical_Q5",arg1,driver);
		
		visualScrollPage2(driver);
		
	}

	@Then("^I will select \"([^\"]*)\" for any medical condition question$")
	public void i_will_select_for_any_medical_condition_question(String arg1) throws Throwable {
		ApplyQuestions("Medical_Q5",arg1,driver);
		
	    
	}

	@Then("^I will select \"([^\"]*)\" for all remaining question$")
	public void i_will_select_for_all_remaining_question(String arg1) throws Throwable {
		ApplyQuestions("Medical_Q6",arg1,driver);
		ApplyQuestions("Medical_Q7",arg1,driver);
		ApplyQuestions("Medical_Q8",arg1,driver);
		visualScrollPage2(driver);
		ApplyQuestions("Medical_Q9",arg1,driver);
		ApplyQuestions("Medical_Q10",arg1,driver);
	}

	@Then("^click on summary$")
	public void click_on_summary() throws Throwable {
	    driver.findElementByXPath("//SPAN[contains(text(),'Summary')]").click();
	    
	    
	}
	
	@Then("^I will verify the proceed button is not enabled$")
	public void i_will_verify_the_proceed_button_is_not_enabled() throws Throwable {
		 driver.context("NATIVE");
			if(driver.findElementByXPath("//UIAButton[contains(@label,'PROCEED')]").isEnabled()){
				ReportGeneration("Proceed button is enabled", "Fail", "Yes", driver);
			} else {
				ReportGeneration("Proceed button is disabled since details missing", "Pass", "Yes", driver);
			}
	}

	@Then("^I will click on edit in Insured Medical history$")
	public void i_will_click_on_edit_in_Insured_Medical_history() throws Throwable {
		driver.context("WEBVIEW");
		SetPageContext("WEBVIEW_2",driver);
	    driver.findElementByXPath(Applyphase.btn_Edit).click();
	    }

	@Then("^click on Next button till page ten$")
	public void click_on_Next_button_till_page_ten() throws Throwable {
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		
		do{
			driver.findElementByXPath(Applyphase.btn_Next).click();
			driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			String pageno=driver.findElementByXPath(Applyphase.Lbl_Applyheader).getText();
			if(pageno.equalsIgnoreCase("Step 10 of 11")){
				break;
			}
			
		}while(driver.findElementByXPath(Applyphase.btn_Next).isDisplayed());
		   
	}

	
	@Then("^Click on Proceed$")
	public void click_on_Proceed() throws Throwable {
	    driver.context("NATIVE");
		driver.findElementByXPath("//UIAButton[contains(@label,'PROCEED')]").click();
	    
	    
	    
	}

	@Then("^Click on GENERATE RESULTS in Underwriting request page$")
	public void click_on_GENERATE_RESULTS_in_Underwriting_request_page() throws Throwable {
		
						
			underwritingSummaryClick(driver.findElementByXPath(Applyphase.btn_Gen_Results),driver);
		
	    
	}

	@Then("^Underwriting result generated$")
	public void underwriting_result_generated() throws Throwable {
		SetPageContext("WEBVIEW_2", driver);
        if(driver.findElementByXPath("//UIAStaticText[contains(@label,'Required further underwriting')] | //*[@class='auwResult ng-binding']").isDisplayed()){

		//if(driver.findElementByXPath("//UIAStaticText[contains(@label,'Required further underwriting')]").isDisplayed()){
			ReportGeneration("Navigated to Underwriting result screen ", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Navigated to Underwriting result screen failed", "Fail", "Yes", driver);
		}
		
		
	}



	
	@Then("^i will click on Proceed button$")
	public void i_will_click_on_Proceed_button() throws Throwable {
		driver.context("NATIVE_APP");
		
		if(driver.findElementByXPath("//UIAButton[contains(@label,'PROCEED')] | //UIAButton[contains(@label,'Proceed')]").isDisplayed()){
			ReportGeneration("Entered valid details in eDisclosure taskcard", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Mandatory details missing in eDisclosure taskcard", "Fail", "Yes", driver);
		}
		
		driver.findElementByXPath("//UIAButton[contains(@label,'PROCEED')] | //UIAButton[contains(@label,'Proceed')]").click();
		
		 
		    
	    
	}


}
