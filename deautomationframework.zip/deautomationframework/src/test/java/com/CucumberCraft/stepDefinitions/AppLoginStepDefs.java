package com.CucumberCraft.stepDefinitions;
/*
import java.util.HashMap;
import java.util.Map;

import io.appium.java_client.AppiumDriver;
import junit.framework.Assert;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.CucumberCraft.supportLibraries.*;
import com.CucumberCraft.pageObjects.*;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AppLoginStepDefs extends MasterStepDefs {
	
	public int loginflg = 0;

	private LoginPage loginPage;
	private WebDriverUtil webDriverUtil;

	static Logger log = Logger.getLogger(AppLoginStepDefs.class);
	@SuppressWarnings("rawtypes")
	AppiumDriver driver = DriverManager.getDriver();

	@Given("^I setup all Prerequisites$")
	public void i_setup_all_Prerequisites() {

		driver.context("NATIVE_APP");
		webDriverUtil = new WebDriverUtil(driver);
		webDriverUtil.waitUntilElementLocated(By.xpath(LoginPage.notificationPage), 15);
		try {
			if (driver.findElementByXPath(LoginPage.notificationPage).isDisplayed()) {
				driver.findElementByXPath(LoginPage.allowButton).click();
				driver.findElementByXPath(LoginPage.continueEnglishBtn).click();
				log.info("Setup Language and Allowed Notification");

			}
		} catch (Exception ex) {
			log.info("Navigated directly Start up Page, no need of setting up prerequisites" + ex.getMessage());
			if (driver.findElementByXPath(LoginPage.continueEnglishBtn).isDisplayed()) {
				driver.findElementByXPath(LoginPage.continueEnglishBtn).click();
				log.info("Setup Language and Allowed Notification");
			}
		}

	}

	@SuppressWarnings("unused")
	@Then("^I should be able to see StartUp screen of MOVE$")
	public void i_should_be_able_to_see_StartUp_screen_of_MOVE() {
		try {
			Map<String, Object> params3 = new HashMap<>();
			params3.put("content", "PRIVATE:script\\Apple_iPhone-7 Plus_161107_105349.png");
			params3.put("image.top", "96");
			params3.put("image.height", "132");
			params3.put("image.left", "128");
			params3.put("image.width", "518");
			Object result3 = driver.executeScript("mobile:checkpoint:image", params3);
			log.info("Home Page displayed successfully");
		} catch (Exception ex) {
			log.error("Home Page didn't display sucessfully" + ex.getMessage());
		}

	}

	@When("^I login using the valid username \"([^\"]*)\" and the valid password \"([^\"]*)\"$")
	public void i_login_using_the_valid_username_testing_and_the_valid_password_abcd(String userName, String passWord) {

		String Platform = currentTestParameters.getMobileExecutionPlatform().name();
		System.out.println(Platform);
		
		// Verify Continue to english button is displayed
		if (currentTestParameters.getMobileExecutionPlatform().equals(MobileExecutionPlatform.ANDROID)) {
			// Android 
			try {
				if (driver.findElementByAccessibilityId("Continue with English").isDisplayed())
					currentScenario.write("Continue with English button is displayed ");
				driver.findElementByAccessibilityId("Continue with English").click();
			} catch (Exception e) {
				currentScenario.write("Language selection button not displayed ");
				currentScenario.embed(Util.takeScreenshot(driver), "image/png");
			}

		} else {
			// iOS 
			try {
				if (driver.findElement(By.xpath(LoginPage.continueEnglishBtn)).isDisplayed())
					currentScenario.write("Continue with English button is displayed ");
				driver.findElement(By.xpath(LoginPage.continueEnglishBtn)).click();
			} catch (Exception e) {
				currentScenario.write("Language selection button not displayed");
				currentScenario.embed(Util.takeScreenshot(driver), "image/png");
			}
		}

		// Verify whether in login page is displayed
		if (currentTestParameters.getMobileExecutionPlatform().equals(MobileExecutionPlatform.ANDROID)) 
		{
			// Android
			try {
				if (driver.findElementByAccessibilityId("Create your MOVE account").isDisplayed())
				log.info("Login Page is displayed");
				currentScenario.write("Login page is displayed");
				currentScenario.embed(Util.takeScreenshot(driver), "image/png");
				loginflg = 1;
			} catch (Exception ex) {
				log.error("Login Issues" + ex.getMessage());
			}
		} else {
			//iOS
			try {
				if (driver.findElement(By.xpath(LoginPage.loginpgDash)).isDisplayed())
				log.info("Login Page is displayed");
				currentScenario.write("Login page is displayed");
				currentScenario.embed(Util.takeScreenshot(driver), "image/png");
				loginflg = 1;
			}
			catch (Exception ex) {
				log.error("Login Issues" + ex.getMessage());
			}
			//Calling login function to execute
			if(loginflg == 1){
				loginPage = new LoginPage(driver);
				loginPage.login(userName, passWord);
				MoveTransferObject moveTransferObject = new MoveTransferObject();
				System.out.println(userName);
				moveTransferObject.setUserName(userName);
				moveTransferObject.setUserPassword(passWord);
				Dashboard.MoveTransferObject1.setUserName(userName);
			}


		}
	}

	@Then("^The application should log me in and navigate to DashBoard Page$")
	public void the_application_should_log_me_in_and_navigate_to_DashBoard_Page() {

		webDriverUtil = new WebDriverUtil(driver);
		webDriverUtil.waitUntilElementLocated(By.xpath(LoginPage.moveWelcomePage), 10);
		try {
			if (driver.findElementByXPath(LoginPage.moveWelcomePage).isDisplayed()
					&& driver.findElementByXPath(LoginPage.dashBoardTab).isDisplayed()) {
				log.info("Logged in Succesfully");
			}

		} catch (Exception ex) {
			log.error("Login Issues" + ex.getMessage());
		}
	}

	@When("^I naviagte to Settings$")
	public void i_naviagte_to_Settings() {
		driver.findElementByXPath(LoginPage.settingsButton).click();
	}
	

	@SuppressWarnings("unused")
	@When("^I Logout$")
	public void i_Logout() {
		try {
			Map<String, Object> params5 = new HashMap<>();
			params5.put("content", "Log Out");
			params5.put("scrolling", "scroll");
			params5.put("maxscroll", "1");
			params5.put("next", "SWIPE_UP");
			Object result5 = driver.executeScript("mobile:text:select", params5);
			driver.findElementByXPath(LoginPage.logoutButton).click();
		} catch (Exception ex) {
			log.error("Issue with Logging out" + ex.getMessage());
		}
	}

	@Then("^I should be able to see Login Screen$")
	public void i_should_be_able_to_see_Login_Screen() {
		try {
			if (driver.findElementByXPath(LoginPage.moveWelcomePage).isDisplayed()) {
				log.info("Back to Login Screen Succesfully");
				currentScenario.write("Back to Login Screen Succesfully");
			}
		} catch (Exception e) {
			log.error("Couldn't Logout SuccessFully" + e.getMessage());
		}
	}

	@SuppressWarnings("unused")
	@Then("^I Should able to navigate to challenges screen$")
	public void I_Should_able_to_navigate_to_challenges_screen() {

		// Click on the challenges screen
		driver.findElementByXPath(CommonPageObjects.challenges).click();

		// Check whether in challenges page with Marsh Madness Badge
		try {
			driver.context("NATIVE_APP");
			WebElement challengemarsh = driver.findElementByXPath("//*[@label=\"Marsh Madness\"]");
			WebDriverWait challengewait = new WebDriverWait(driver, 30);
			WebElement challenges = challengewait.until(ExpectedConditions.visibilityOf(challengemarsh));
			if (challengemarsh.isDisplayed())
				log.info("Challenges Page opened and Marsh Madness Badge displayed");
				currentScenario.write("Challenges Page opened and Marsh Madness Badge displayed");
				currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		} catch (Exception e) {
			log.error("Unable to navigate Challenges Page" + e.getMessage());
			currentScenario.write("Unable to navigate Challenges Page");

		}

	}

	@SuppressWarnings("unused")
	@Then("^I Should able to navigate to Moveplus screen$")
	public void Navigate_to_Moveplus() {

		// Click on the challenges screen
		driver.context("NATIVE_APP");
		driver.findElementByXPath(CommonPageObjects.movePlus).click();

		// Check whether in challenges page with Marsh Madness Badge
		try {
			WebElement moveplusoffer = driver.findElementByXPath("//*[@label='Offers']");
			WebDriverWait movepluswait = new WebDriverWait(driver, 30);
			WebElement moveplus = movepluswait.until(ExpectedConditions.visibilityOf(moveplusoffer));
			if (moveplusoffer.isDisplayed()) {
				log.info("MOVE+ Page opened is displayed");
				currentScenario.write("MOVE+ Page opened is displayed");
				currentScenario.embed(Util.takeScreenshot(driver), "image/png");
			}
		} catch (Exception e) {
			log.error("Unable to navigate MOVE+ Page" + e.getMessage());
			currentScenario.write("Unable to navigate MOVE+ Page");

		}

	}

	@SuppressWarnings("unused")
	@Then("^I Should able to navigate to leaderboard screen$")
	public void Navigate_to_leaderboard() {
		// Click on the challenges screen
		driver.context("NATIVE_APP");
		driver.findElementByXPath(CommonPageObjects.leaderbaord).click();

		// Check whether in challenges page with Marsh Madness Badge
		try {
			WebElement leaderBYou = driver.findElementByXPath("//*[@label='You']");
			WebDriverWait leaderBYouwait = new WebDriverWait(driver, 30);
			WebElement leaderBYouele = leaderBYouwait.until(ExpectedConditions.visibilityOf(leaderBYou));
			if (leaderBYou.isDisplayed()) {
				log.info("Leaderboard page opened is displayed");
				currentScenario.write("Leaderboard Page opened is displayed");
				currentScenario.embed(Util.takeScreenshot(driver), "image/png");
			}
		} catch (Exception e) {
			log.error("Unable to navigate Leaderboard Page" + e.getMessage());
			currentScenario.write("Unable to navigate Leaderboard Page");

		}

	}
}
*/