package com.CucumberCraft.stepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.CucumberCraft.pageObjects.Applyphase;
import com.CucumberCraft.pageObjects.EposAddFNAPage;
import com.CucumberCraft.pageObjects.EposDrawerMenu;
import com.CucumberCraft.pageObjects.Eposgoals;
import com.CucumberCraft.supportLibraries.DriverManager;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.AppiumDriver;

public class EPOSGoals extends MasterStepDefs {
	AppiumDriver driver = DriverManager.getDriver();
	public boolean resultBool;
	WebDriverWait wait=new WebDriverWait(driver,60);
	@Given("^I am in Introduction page$")
	public void i_am_in_Introduction_page() throws Throwable {
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.context("WEBVIEW");
		if (driver.findElementByXPath(Eposgoals.lbl_Introduction).isDisplayed()) {
			ReportGeneration("Navigated to Introduction screen", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Navigation to Introduction screen failed", "Fail", "Yes", driver);
		}

	}

	@When("^I will click on Introduction tab$")
	public void i_will_click_on_Introduction_tab() throws Throwable {
		driver.findElementByXPath(Eposgoals.btn_Introduction).click();

	}

	@When("^I will navigate all the pages in Introduction page$")
	public void i_will_navigate_all_the_pages_in_Introduction_page() throws Throwable {
		
		do{
			driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			driver.findElementByXPath(Eposgoals.btn_Navigate).click();
		}while(driver.findElementByXPath(Eposgoals.btn_Navigate).isDisplayed());

	}

	@When("^I will click on close icon from the top left corner$")
	public void i_will_click_on_close_icon_from_the_top_left_corner() throws Throwable {
		driver.context("NATIVE");
		driver.findElementByXPath(Eposgoals.btn_Close).click();
		driver.context("WEBVIEW");
		

	}
	
	@Then("^I will select \\* icon for \"([^\"]*)\"$")
	public void i_will_select_icon_for(String arg1) throws Throwable {
		GoalStarAppend(arg1,driver);

	}

	

	@Given("^I am in Manage Goals page$")
	public void i_am_in_Manage_Goals_page() throws Throwable {
		driver.context("WEBVIEW");

		if (driver.findElementByXPath(Eposgoals.btn_Manage_Goals).isDisplayed()) {
			ReportGeneration("Navigated to Manage goals screen", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Navigation to Manage goals screen failed", "Fail", "Yes", driver);
		}

	}

	@When("^I will click Manage Goals in Holistic Customer Portfolio$")
	public void i_will_click_Manage_Goals_in_Holistic_Customer_Portfolio() throws Throwable {

		driver.findElementByXPath(Eposgoals.btn_Manage_Goals).click();

		try {
			driver.context("NATIVE");
			if (driver.findElementByXPath(EposDrawerMenu.btn_download).isDisplayed()) {
				driver.findElementByXPath(EposDrawerMenu.btn_download).click();
				PauseScript(1, driver);

				driver.findElementByXPath(Eposgoals.btn_Manage_Goals).click();

			}
		} catch (Exception ex) {
		}

	}
	
	@Given("^I will delete  goals \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_will_delete_goals_and(String goal1, String goal2) throws Throwable {
		Deletegoal(goal1,driver);
		Deletegoal(goal2,driver);
	}
	
	
	@When("^I will select goal as \"([^\"]*)\"$")
	public void i_will_select_goal_as(String goalname) throws Throwable {
		driver.context("WEBVIEW");

		// DeleteUndefined(driver);
		GoalSelection(goalname, driver);

	}

	@When("^I Will select second goal as \"([^\"]*)\"$")
	public void i_Will_select_second_goal_as(String goalname) throws Throwable {
		GoalSelection(goalname, driver);
		

	}
	
	
	
	
	@Then("^I will be navigated to Holistic Customer Portfolio$")
	public void i_will_be_navigated_to_Holistic_Customer_Portfolio() throws Throwable {
		WebDriverWait wait=new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath(Eposgoals.btn_Manage_Goals)));
		if (driver.findElementByXPath(Eposgoals.btn_Manage_Goals).isDisplayed()) {
			ReportGeneration("Navigated to Customer Portfolio Screen", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Navigation Customer Portfolio Screen failed", "Fail", "Yes", driver);
		}

	}

	@Then("^I will click on Goals$")
	public void i_will_click_on_Goals() throws Throwable {
		driver.context("WEBVIEW");
		driver.findElementByXPath(Eposgoals.btn_Goal).click();

	}

	@Then("^I will be navigated to Goal Dashboard$")
	public void i_will_be_navigated_to_Goal_Dashboard() throws Throwable {
		driver.context("NATIVE");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//UIAStaticText[contains(@label,'Goal Dashboard')]")));
		if (driver.findElementByXPath("//UIAStaticText[contains(@label,'Goal Dashboard')]").isDisplayed()){
			ReportGeneration("Navigated to Goal Dashboard page", "Pass", "Yes", driver);
		} else  {
			ReportGeneration("Navigation to Goal Dashboard page failed", "Fail", "Yes", driver);
		}
		driver.context("WEBVIEW");
	}

	@Then("^I will click on Calculate this goal for \"([^\"]*)\" for first goal$")
	public void i_will_click_on_Calculate_this_goal_for_for_first_goal(String goalname) throws Throwable {

		Goal_CalculateGoalClick(goalname, driver);

	}

	@Then("^I will click on navigation button in About Your section$")
	public void i_will_click_on_navigation_button_in_About_Your_section() throws Throwable {
		driver.findElementByXPath(Eposgoals.btn_Navigate).click();

	}

	@Then("^I will click on navigation button in Your Retirement section$")
	public void i_will_click_on_navigation_button_in_Your_Retirement_section() throws Throwable {
		driver.findElementByXPath(Eposgoals.btn_Navigate).click();

	}

	@Then("^I will click on SAVE AND PROCEED$")
	public void i_will_click_on_SAVE_AND_PROCEED() throws Throwable {
		driver.context("WEBVIEW");
		
		//WaitForObject("SAVE AND PROCEED",driver);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Eposgoals.Save_And_Proceed)));
		driver.findElementByXPath(Eposgoals.Save_And_Proceed).click();


	}

	
	
	
	@Then("^I will click on Calculate this goal for \"([^\"]*)\"$")
	public void i_will_click_on_Calculate_this_goal_for(String goalname) throws Throwable {

		Goal_CalculateGoalClick(goalname, driver);

	}
	
	
	@Given("^I will click on navigation button$")
	public void i_will_click_on_navigation_button() throws Throwable {
		driver.findElementByXPath(Eposgoals.btn_Navigate).click();
	}

	@Then("^I will click on navigation button in Current Coverage/Reserve$")
	public void i_will_click_on_navigation_button_in_Current_Coverage_Reserve() throws Throwable {
		driver.findElementByXPath(Eposgoals.btn_Navigate).click();

	}

	@Then("^I will click on navigation button in Basic Life Coverage Need$")
	public void i_will_click_on_navigation_button_in_Basic_Life_Coverage_Need() throws Throwable {
		driver.findElementByXPath(Eposgoals.btn_Navigate).click();

	}

	@Then("^I will click on navigation button in Education Fund$")
	public void i_will_click_on_navigation_button_in_Education_Fund() throws Throwable {
		driver.findElementByXPath(Eposgoals.btn_Navigate).click();

	}

	@Then("^I will be navigated to Goals Summary$")
	public void i_will_be_navigated_to_Goals_Summary() throws Throwable {
		//textCheckpoint("Goal Summary", 5, driver);
		driver.context("NATIVE");
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//UIAStaticText[contains(@label,'Goals Summary')]")));
		if (driver.findElementByXPath("//UIAStaticText[contains(@label,'Goals Summary')]").isDisplayed()) {
			ReportGeneration("Navigated to Goal Summary page", "Pass", "Yes", driver);
		} else  {
			ReportGeneration("Navigation to Goal Summary page failed", "Fail", "Yes", driver);
		}
	
		
	}
	@Given("^click on close button$")
	public void click_on_close_button() throws Throwable {
		driver.context("NATIVE");
		driver.findElementByXPath(Eposgoals.btn_Close).click();
		
	 
	}
	

}
