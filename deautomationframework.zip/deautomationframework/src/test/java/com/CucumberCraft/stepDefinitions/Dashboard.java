/*
package com.CucumberCraft.stepDefinitions;

import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.TouchAction;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;

import com.CucumberCraft.supportLibraries.DBConnect;
import com.CucumberCraft.supportLibraries.DriverManager;
import com.CucumberCraft.supportLibraries.MobileExecutionPlatform;
import com.CucumberCraft.supportLibraries.ReusableMethods;
import com.CucumberCraft.supportLibraries.Util;
import com.CucumberCraft.stepDefinitions.*;
import com.CucumberCraft.supportLibraries.WebDriverUtil;
import com.CucumberCraft.pageObjects.*;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Dashboard extends MasterStepDefs {
	private LoginPage loginPage;
	private WebDriverUtil webDriverUtil;

	static Logger log = Logger.getLogger(Steps.class);
	@SuppressWarnings("rawtypes")
	AppiumDriver driver = DriverManager.getDriver();
	public static MoveTransferObject MoveTransferObject1 = new MoveTransferObject();
	 String userName = MoveTransferObject1.getUserName();
	//String userName = "testing04";
	public String CurrDate = ReusableMethods.Getcurrentdate();

	/*
	 * @Then("^I valdiate APP last update with DB$") public void
	 * I_valdiate_APP_last_update_with_DB(){ // SWIPE UP for Calories Burned
	 * 
	 * try{ Calendar c = Calendar.getInstance(); SimpleDateFormat sd1 = new
	 * SimpleDateFormat("dd-MMM-yy"); System.out.println("Date : " +
	 * sd1.format(new Date(c.getTimeInMillis()))); String CurrDate =
	 * sd1.format(new Date(c.getTimeInMillis()));
	 * 
	 * if(driver.findElement(By.xpath(DashboardPage.dashboardlastup)).
	 * isDisplayed()){ String Lastupd =
	 * driver.findElement(By.xpath(DashboardPage.dashboardlastup)).getText();
	 * 
	 * }
	 * 
	 * }catch(Exception ex){ log.error(
	 * "Unable retrive Last updated data from Dashboard Page" +
	 * ex.getMessage()); }
	 * 
	 * }
	 */
/*
	@Then("^I validate APP steps with DB$")
	public void I_validate_APP_steps_with_DB() {
		// Field userName = MoveTransferObject.class.getField("userName");
		log.info("Swipe up to steps");
		currentScenario.write("Swipe up to steps");
		currentScenario.embed(Util.takeScreenshot(driver), "image/png");

		String Platform = currentTestParameters.getMobileExecutionPlatform().name();
		System.out.println(Platform);
		if (currentTestParameters.getMobileExecutionPlatform().equals(MobileExecutionPlatform.ANDROID)) {
			// Android Scripting

		} else {
			// iOS Scripting
			// Small swipe up to view number of steps in dashboard
			TouchAction touchAction4 = new TouchAction(driver);
			touchAction4.press(634, 594).moveTo(619, 512).release();
			driver.performTouchAction(touchAction4);
			// Validate APP Step data with DB Step Data
			try {
				if (driver.findElement(By.xpath(DashboardPage.dashboardstepsMg)).isDisplayed()) {
					log.info("Steps Section Displayed");
					currentScenario.write("Steps Section Displayed");
					currentScenario.embed(Util.takeScreenshot(driver), "image/png");
					String appSteps = driver.findElement(By.xpath(DashboardPage.dashboardstepsMg)).getText();
					String DBLastup = DBConnect.Getclienthealthinfo(userName, CurrDate);
					String[] DBoutput = DBLastup.split("--");
					String dbSteps = DBoutput[4];
					String appStepsStr = appSteps.replace(",", "");
					log.info("MOVE App Steps - " + appStepsStr + " From Database " + dbSteps);
					currentScenario.write("MOVE App Steps - " + appStepsStr + " From Database " + dbSteps);
					if (appStepsStr.equals(dbSteps)) {
						log.info("MOVE App Steps - " + appStepsStr + " From Database " + dbSteps + " is Matched ");
						currentScenario
								.write("MOVE App Steps - " + appStepsStr + " From Database " + dbSteps + " is Matched ");
					} else {
						log.info("MOVE App Steps - " + appStepsStr + " From Database " + dbSteps + " not  Matched ");
						currentScenario
								.write("MOVE App Steps - " + appStepsStr + " From Database " + dbSteps + " not Matched ");
					}

				}

			} catch (Exception ex) {
				log.error("Unable retrive steps data" + ex.getMessage());
				currentScenario.embed(Util.takeScreenshot(driver), "image/png");
			}
		}
	}

	@Then("^I validate APP caloriesburned with DB$")
	public void valdiatecaloriesburnedwithdb() {
		String Platform = currentTestParameters.getMobileExecutionPlatform().name();
		System.out.println(Platform);

		TouchAction touchAction4 = new TouchAction(driver);
		touchAction4.press(634, 594).moveTo(619, 512).release();
		driver.performTouchAction(touchAction4);

		if (currentTestParameters.getMobileExecutionPlatform().equals(MobileExecutionPlatform.ANDROID)) {
			// Android Scripting

		} else {
			try {
				System.out.println(userName);
				if (driver.findElement(By.xpath(DashboardPage.dashboardcaloriesMg)).isDisplayed()) {
					log.info("Calories Section Displayed");
					currentScenario.write("Calories Section Displayed");
					currentScenario.embed(Util.takeScreenshot(driver), "image/png");
					String appcalories = driver.findElement(By.xpath(DashboardPage.dashboardcaloriesMg)).getText();
					String DBLastup = DBConnect.Getclienthealthinfo(userName, CurrDate);
					String[] DBoutput = DBLastup.split("--");
					String dbcalories = DBoutput[5];
					String appcaloriesStr = appcalories.replace(",", "");
					log.info("MOVE App calories burned - " + appcaloriesStr + " From Database " + dbcalories);
					currentScenario
							.write("MOVE App calories burned - " + appcaloriesStr + " From Database " + dbcalories);
					if (appcaloriesStr.equals(dbcalories)) {
						log.info("MOVE App calories burned - " + appcaloriesStr + " From Database " + dbcalories
								+ " is Matched ");
						currentScenario.write("MOVE App calories burned - " + appcaloriesStr + " From Database "
								+ dbcalories + " is Matched ");
					} else {
						log.info("MOVE App calories burned - " + appcaloriesStr + " From Database " + dbcalories
								+ " not  Matched ");
						currentScenario.write("MOVE App calories burned - " + appcaloriesStr + " From Database "
								+ dbcalories + " not Matched ");
					}
				}
			} catch (Exception ex) {
				log.error("Unable retrive Calories Burned data" + ex.getMessage());
			}

		}
	}

	@Then("^I validate APP weight with DB$")
	public void valdiateweightwithdb() {
		String Platform = currentTestParameters.getMobileExecutionPlatform().name();
		System.out.println(Platform);

		if (currentTestParameters.getMobileExecutionPlatform().equals(MobileExecutionPlatform.ANDROID)) {
			// Android Scripting

		} else {
			try {
				try {
					if (driver.findElement(By.xpath(DashboardPage.dashboardweightMg)).isDisplayed()) {
						currentScenario.write("Weight displayed");
					} else {
						Map<String, Object> params5 = new HashMap<>();
						params5.put("content", "Sleep");
						params5.put("scrolling", "scroll");
						params5.put("maxscroll", "1");
						params5.put("next", "SWIPE_UP");
						log.info("Swipe up to view weight data");
					}
				} catch (Exception ex) {
					log.error("Unable view Weight data" + ex.getMessage());
				}
				try {
					if(driver.findElement(By.xpath(DashboardPage.dashboardweightMg)).isDisplayed()){
						log.info("Weight Section Displayed");
						currentScenario.write("Weight Section Displayed");
						currentScenario.embed(Util.takeScreenshot(driver), "image/png");
					String appweight = driver.findElement(By.xpath(DashboardPage.dashboardweightMg)).getText();
					String DBLastup = DBConnect.Getclienthealthinfo(userName, CurrDate);
					String[] DBoutput = DBLastup.split("--");
					String dbweight = DBoutput[6];
					log.info("MOVE App Weight - " + appweight + " From Database " + dbweight);
					currentScenario.write("MOVE App Weight - " + appweight + " From Database " + dbweight);
					if (appweight.equals(dbweight)) {
						log.info("MOVE App Weight - " + appweight + " From Database " + dbweight + " is Matched ");
						currentScenario.write(
								"MOVE App Weight - " + appweight + " From Database " + dbweight + " is Matched ");
					} else {
						log.info("MOVE App Weight - " + appweight + " From Database " + dbweight + " not  Matched ");
						currentScenario.write(
								"MOVE App Weight - " + appweight + " From Database " + dbweight + " not Matched ");
					}
					}
				} catch (Exception ex) {
					log.error("Unable retrive Weight data" + ex.getMessage());
					currentScenario.embed(Util.takeScreenshot(driver), "image/png");
				}

			} catch (Exception ex) {
				log.error("Unable retrive Weight data" + ex.getMessage());
				currentScenario.embed(Util.takeScreenshot(driver), "image/png");
			}

		}
	}

	@Then("^I validate APP Sleep with DB$")
	public void valdiatesleepwithdb() {
		String Platform = currentTestParameters.getMobileExecutionPlatform().name();
		System.out.println(Platform);

		if (currentTestParameters.getMobileExecutionPlatform().equals(MobileExecutionPlatform.ANDROID)) {
			// Android Scripting

		} else {
			try {
				System.out.println(userName);

				try {
					if (driver.findElement(By.xpath(DashboardPage.dashboardsleepMg)).isDisplayed()) {
						currentScenario.write("Sleep displayed");
						log.info("Sleep section displayed");
					} else {
						Map<String, Object> params5 = new HashMap<>();
						params5.put("content", "Sleep");
						params5.put("scrolling", "scroll");
						params5.put("maxscroll", "1");
						params5.put("next", "SWIPE_UP");
						log.info("Swipe up to view sleep data");
					}
				} catch (Exception ex) {
					log.error("Unable view sleep data" + ex.getMessage());
				}

				{
					String appsleep = driver.findElement(By.xpath(DashboardPage.dashboardsleepMg)).getText();
					String DBLastup = DBConnect.Getclienthealthinfo(userName, CurrDate);
					String[] DBoutput = DBLastup.split("--");
					String dbsleep = DBoutput[4];
					log.info("MOVE App Sleep - " + appsleep + " From Database " + dbsleep);
					currentScenario.write("MOVE App Sleep - " + appsleep + " From Database " + dbsleep);
					if (appsleep.equals(dbsleep)) {
						log.info("MOVE App Sleep - " + appsleep + " From Database " + dbsleep + " is Matched ");
						currentScenario
								.write("MOVE App Sleep - " + appsleep + " From Database " + dbsleep + " is Matched ");
					} else {
						log.info("MOVE App Sleep - " + appsleep + " From Database " + dbsleep + " not  Matched ");
						currentScenario
								.write("MOVE App Sleep - " + appsleep + " From Database " + dbsleep + " not Matched ");
					}
				}

			} catch (Exception ex) {
				log.error("Unable retrive Weight data" + ex.getMessage());
			}

		}
	}

}
*/