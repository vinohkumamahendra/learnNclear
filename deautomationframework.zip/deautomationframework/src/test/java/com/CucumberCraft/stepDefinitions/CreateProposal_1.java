package com.CucumberCraft.stepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.CucumberCraft.pageObjects.Applyphase;
import com.CucumberCraft.pageObjects.EposCreateProposalPage;
import com.CucumberCraft.supportLibraries.DriverManager;

import cucumber.api.java.en.Then;
import io.appium.java_client.AppiumDriver;

public class CreateProposal_1 extends MasterStepDefs {
	public static String proposalName=""; 
	AppiumDriver driver = DriverManager.getDriver();
	WebDriverWait wait=new WebDriverWait(driver, 60);
	@Then("^I will select Smoker Status as \"([^\"]*)\" in Insured section for Proposal$")
	public void i_will_select_Smoker_Status_as_in_Insured_section_for_Proposal(String arg1) throws Throwable {
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		if (driver.findElementByXPath(EposCreateProposalPage.btn_Smoker_Stat).isDisplayed()) {
			ReportGeneration("Successfully navigated to owner details in comprop", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Navigation to owner details in comprop failed", "Fail", "Yes", driver);
		}

		driver.findElementByXPath(EposCreateProposalPage.btn_Smoker_Stat).sendKeys("Standard");

	}

	@Then("^I will select Smoker Status as \"([^\"]*)\" in Owner section for Proposal$")
	public void i_will_select_Smoker_Status_as_in_Owner_section_for_Proposal(String arg1) throws Throwable {

		driver.findElementByXPath(EposCreateProposalPage.btn_Dep_Smoker_Stat).sendKeys("Standard");

	}

	@Then("^I will click Basic Plan tab for Proposal(\\d+)$")
	public void i_will_click_Basic_Plan_tab_for_Proposal(int arg1) throws Throwable {
		WebDriverWait wait =new WebDriverWait(driver, 30);
		driver.findElementByXPath(EposCreateProposalPage.tab_Basic_Plan).click();
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath(EposCreateProposalPage.tab_Selected)));

	}

	@Then("^I will select Basic Plan as \"([^\"]*)\" for Proposal(\\d+)$")
	public void i_will_select_Basic_Plan_as_for_Proposal(String plan, int arg2) throws Throwable {
		proposalName=plan;
		Plan_Selector_Comprop(plan, driver);

	}

	@Then("^I will enter Notional Amount as \"([^\"]*)\" for Proposal(\\d+)$")
	public void i_will_enter_Notional_Amount_as_for_Proposal(String notional_amt, int arg_2) throws Throwable {
		driver.context("WEBVIEW");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@name='face_amount']")));
		driver.findElementByXPath("//*[@name='face_amount']").clear();
		driver.findElement(By.name("face_amount")).sendKeys(notional_amt);
		HideKeyboard(driver);

	}

	@Then("^I will click on Preview button for Proposal(\\d+)$")
	public void i_will_click_on_Preview_button_for_Proposal(int arg1) throws Throwable {
		driver.context("WEBVIEW");
		WebDriverWait wait=new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@name=\"btnPreview\"]")));
		driver.findElementByXPath("//*[@name=\"btnPreview\"]").click();

	}

	@Then("^I will be navigated to Premium Summary tab for Proposal(\\d+)$")
	public void i_will_be_navigated_to_Premium_Summary_tab_for_Proposal(int arg1) throws Throwable {
		driver.context("WEBVIEW");
		WebDriverWait wait=new WebDriverWait(driver, 30);
		//WebElement tab_Prem_Sum=driver.findElementByXPath(EposCreateProposalPage.tab_Premium_Sum);
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(EposCreateProposalPage.tab_Premium_Sum)));
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@name='Premium Summary']")));
		//wait.until(ExpectedConditions.elementToBeSelected(tab_Prem_Sum));

	}

	@Then("^I will click on Print button for Proposal(\\d+)$")
	public void i_will_click_on_Print_button_for_Proposal(int arg1) throws Throwable {
		WebDriverWait wait=new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(EposCreateProposalPage.btn_print)));
		driver.findElementByXPath(EposCreateProposalPage.btn_print).click();

	}
	
	@Then("^I will be navigated to Print options tab for Proposal(\\d+)$")
	public void i_will_be_navigated_to_Print_options_tab_for_Proposal(int arg1) throws Throwable {
		driver.context("WEBVIEW");
		WebDriverWait wait=new WebDriverWait(driver, 30);
		//WebElement tab_Print_Opt=driver.findElementByXPath(EposCreateProposalPage.tab_Premium_Sum);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(EposCreateProposalPage.tab_Print_Opt)));
		//wait.until(ExpectedConditions.elementToBeSelected(tab_Print_Opt));
	 
	}
	
	
	@Then("^I will click on English in Proposal Language for Proposal(\\d+)$")
	public void i_will_click_on_English_in_Proposal_Language_for_Proposal(int arg1) throws Throwable {
		driver.findElementByXPath(EposCreateProposalPage.btn_English).click();

		try {
			driver.context("NATIVE");
			driver.findElementByXPath(EposCreateProposalPage.btn_Popup).click();
		} catch (Exception ex) {
		}

	}

	@Then("^Click on PRINT button for Proposal(\\d+)$")
	public void click_on_PRINT_button_for_Proposal(int arg1) throws Throwable {
		driver.context("WEBVIEW");
		WebDriverWait wait=new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@name=\"btnPrint\"]")));
		driver.findElementByXPath("//*[@name=\"btnPrint\"]").click();

	}

	@Then("^I will click on SAVE button for Proposal(\\d+)$")
	public void i_will_click_on_SAVE_button_for_Proposal(int arg1) throws Throwable {
		driver.context("WEBVIEW");
		WebDriverWait wait=new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@name=\"btnSave_2\"]")));
		driver.findElementByXPath("//*[@name=\"btnSave_2\"]").click();

	}

	@Then("^I will click on OK in the popup for Proposal(\\d+)$")
	public void i_will_click_on_OK_in_the_popup_for_Proposal(int arg1) throws Throwable {
		try {
			driver.context("NATIVE");
			driver.findElementByXPath(EposCreateProposalPage.btn_Popup).click();
		} catch (Exception ex) {
		}

	}

	@Then("^I will click on Close button from top left corner for Proposal(\\d+)$")
	public void i_will_click_on_Close_button_from_top_left_corner_for_Proposal(int arg1) throws Throwable {
		Waitforloading(Applyphase.ele_Ldg_PDF, driver);
		driver.findElementByXPath(EposCreateProposalPage.btn_Close).click();
		try{
			driver.context("WEBVIEW");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//P[text()='"+proposalName+"']")));
		}catch(Exception ex){
			System.out.println("Entered Proposal wait exception");
		}
		
		

	}

}
