package com.CucumberCraft.stepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.CucumberCraft.pageObjects.Applyphase;
import com.CucumberCraft.pageObjects.EposAddProspectPage;
import com.CucumberCraft.supportLibraries.DriverManager;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.AppiumDriver;

public class Apply2 extends MasterStepDefs {
	AppiumDriver driver = DriverManager.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 60);

	@Given("^I am in Solution Information task card$")
	public void i_am_in_Solution_Information_task_card() throws Throwable {
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.context("NATIVE_APP");
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//UIAStaticText[contains(@label,'Solution Information')]")));
		if (driver.findElementByXPath("//UIAStaticText[contains(@label,'Solution Information')]").isDisplayed()) {
			ReportGeneration("Navigated to Solution Information taskcard", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Navigation to Solution Information taskcard failed", "Fail", "Yes", driver);
		}

	}

	@When("^I click on Proceed in Personal Information task card$")
	public void i_click_on_Proceed_in_Personal_Information_task_card() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@Then("^I will be verifying the label \"([^\"]*)\" is displayed$")
	public void i_will_be_verifying_the_label_is_displayed(String arg1) throws Throwable {
		driver.context("WEBVIEW");
		SetPageContext("WEBVIEW_2", driver);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Basic Premium']")));
		if (driver.findElementByXPath("//*[text()='Basic Premium']").isDisplayed()) {
			ReportGeneration("Navigated to Solution Information taskcard", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Navigation to Solution Information taskcard failed", "Fail", "Yes", driver);
		}

	}

	@Then("^I will be checking \"([^\"]*)\" and amount \"([^\"]*)\" is displayed$")
	public void i_will_be_checking_and_amount_is_displayed(String currency, String currencyval) throws Throwable {

		if (driver.findElementByXPath(Applyphase.lbl_Currency).getAttribute("innerText").equalsIgnoreCase(currency)) {
			ReportGeneration("Currency is validated successfully in Solution Information taskcard", "Pass", "Yes",
					driver);
		} else {
			ReportGeneration("Currency validation in Solution Information taskcard taskcard failed", "Fail", "Yes",
					driver);
		}

		if (driver.findElementByXPath(Applyphase.lbl_Currencyvalue).getAttribute("value")
				.equalsIgnoreCase(currencyval)) {
			ReportGeneration("Currency is validated successfully in Solution Information taskcard", "Pass", "Yes",
					driver);
		} else {
			ReportGeneration("Currency validation in Solution Information taskcard taskcard failed", "Fail", "Yes",
					driver);
		}

	}

	@Then("^i will be checking the label \"([^\"]*)\" is displayed in Rider table$")
	public void i_will_be_checking_the_label_is_displayed_in_Rider_table(String arg1) throws Throwable {
		if (driver.findElementByXPath(Applyphase.lbl_Ridercurrency).isDisplayed()) {
			ReportGeneration("Rider protection amount is displayed Solution Information taskcard", "Pass", "Yes",
					driver);
		} else {
			ReportGeneration("Rider protection amount not displayed in Solution Information taskcard taskcard failed",
					"Fail", "Yes", driver);
		}
	}

	@Then("^scroll the page$")
	public void scroll_the_page() throws Throwable {
		visualScrollPage(driver);

	}

	@Then("^I will select \"([^\"]*)\" for Polcy year date question$")
	public void i_will_select_for_Polcy_year_date_question(String arg1) throws Throwable {
		driver.context("WEBVIEW");
		SetPageContext("WEBVIEW_2", driver);
		ApplyPolicyYrDate(arg1, driver);

	}

	@Then("^I will enter Policy year day as '(\\d+)' month as \"([^\"]*)\" and year as \"([^\"]*)\"$")
	public void i_will_enter_Policy_year_day_as_month_as_and_year_as(int day, String month, String year)
			throws Throwable {

		Datepick(day, month, year, driver);
		
	}

	@Then("^enter number of beneficiary to create as \"([^\"]*)\" and click on the create beneficiary button$")
	public void enter_number_of_beneficiary_to_create_as_and_click_on_the_create_beneficiary_button(int benifcount)
			throws Throwable {
		driver.context("WEBVIEW");
		SetPageContext("WEBVIEW_2",driver);
		Apply_AddBenificiary(benifcount, driver);

	}

	@Then("^I will enter benificiarystatus as \"([^\"]*)\",surname as \"([^\"]*)\" and Given name as \"([^\"]*)\",relationship as \"([^\"]*)\",passport no as \"([^\"]*)\",share as \"([^\"]*)\" and select \"([^\"]*)\" for under age question for first benificary as '(\\d+)'$")
	public void i_will_enter_benificiarystatus_as_surname_as_and_Given_name_as_relationship_as_passport_no_as_share_as_and_select_for_under_age_question_for_first_benificary_as(
			String benifstatus1, String surname1, String givenname1, String relationship1, String passport1,
			String share1, String option1, int benif1) throws Throwable {

		Apply_BenificiaryDetails(benifstatus1, surname1, givenname1, relationship1, passport1, share1, option1, benif1,
				driver);
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		visualScrollPage(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
	}

	@Then("^I will enter benificiarystatus as \"([^\"]*)\",surname as \"([^\"]*)\" and Given name as \"([^\"]*)\",relationship as \"([^\"]*)\",passport no as \"([^\"]*)\",share as \"([^\"]*)\" and select \"([^\"]*)\" for under age question for second benificary as '(\\d+)'$")
	public void i_will_enter_benificiarystatus_as_surname_as_and_Given_name_as_relationship_as_passport_no_as_share_as_and_select_for_under_age_question_for_second_benificary_as(
			String benifstatus2, String surname2, String givenname2, String relationship2, String passport2,
			String share2, String option2, int benif2) throws Throwable {

		Apply_BenificiaryDetails(benifstatus2, surname2, givenname2, relationship2, passport2, share2, option2, benif2,
				driver);
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		//visualScrollPage(driver);
		
	}

	@Then("^I will enter benificiarystatus as \"([^\"]*)\",surname as \"([^\"]*)\" and Given name as \"([^\"]*)\",relationship as \"([^\"]*)\",passport no as \"([^\"]*)\",share as \"([^\"]*)\" and select \"([^\"]*)\" for under age question for third benificiary as'(\\d+)'$")
	public void i_will_enter_benificiarystatus_as_surname_as_and_Given_name_as_relationship_as_passport_no_as_share_as_and_select_for_under_age_question_for_third_benificiary_as(
			String benifstatus3, String surname3, String givenname3, String relationship3, String passport3,
			String share3, String option3, int benif3) throws Throwable {

		Apply_BenificiaryDetails(benifstatus3, surname3, givenname3, relationship3, passport3, share3, option3, benif3,
				driver);
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		
		
	}

	@Then("^I will enter benificiarystatus as \"([^\"]*)\",surname as \"([^\"]*)\" and Given name as \"([^\"]*)\",relationship as \"([^\"]*)\",passport no as \"([^\"]*)\",share as \"([^\"]*)\" and select \"([^\"]*)\" for under age question for fourth beneficiary as '(\\d+)'$")
	public void i_will_enter_benificiarystatus_as_surname_as_and_Given_name_as_relationship_as_passport_no_as_share_as_and_select_for_under_age_question_for_fourth_beneficiary_as(
			String benifstatus4, String surname4, String givenname4, String relationship4, String passport4,
			String share4, String option4, int benif4) throws Throwable {

		Apply_BenificiaryDetails(benifstatus4, surname4, givenname4, relationship4, passport4, share4, option4, benif4,
				driver);
		
		
	}

	@Then("^I will select \"([^\"]*)\" and click Done$")
	public void i_will_select_and_click_Done(String choice) throws Throwable {
		AddInvestmentChoice(choice, driver);
	}

	@Then("^enter \"([^\"]*)\" in Premium AllocationPercentage$")
	public void enter_in_Premium_AllocationPercentage(String allocpercent) throws Throwable {
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		driver.findElementByXPath(Applyphase.txt_Allocation).sendKeys(allocpercent);
	}

	@Then("^Click on Option \"([^\"]*)\" in Declaration$")
	public void click_on_Option_in_Declaration(String option) throws Throwable {
		
		Solutiondeclareoption(option, driver);

	}

	@Then("^enter wording in the Handwriting box and click Save$")
	public void enter_wording_in_the_Handwriting_box_and_click_Save() throws Throwable {

		//driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		driver.context("WEBVIEW");
		SetPageContext("WEBVIEW_2",driver);
		driver.findElementByXPath(Applyphase.lbl_Sig_Own_Handwriting).click();
		//textClick("Applicant must complete explanation in own handwriting in this box for option B selected", 15, driver);
		//driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		drawLetter("P", driver);
		driver.context("WEBVIEW");
		SetPageContext("WEBVIEW_2",driver);
		driver.findElementByXPath(Applyphase.btn_Save).click();

	}

	@Then("^I will click on Proceed button$")
	public void i_will_click_on_Proceed_button() throws Throwable {
		driver.context("NATIVE_APP");
		if (driver.findElementByXPath(Applyphase.btn_Proceed).isDisplayed()) {
			ReportGeneration("Entered valid details in solution Information taskcard", "Pass", "Yes", driver);
		} else {
			ReportGeneration("Mandatory details missing in solution Information taskcard", "Fail", "Yes", driver);
		}

		driver.findElementByXPath(Applyphase.btn_Proceed).click();

	}

	@Then("^I will be navigated to Agreements task card$")
	public void i_will_be_navigated_to_Agreements_task_card() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

}
