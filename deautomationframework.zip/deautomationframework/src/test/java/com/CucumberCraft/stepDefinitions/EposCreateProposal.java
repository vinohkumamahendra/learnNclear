package com.CucumberCraft.stepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

import com.CucumberCraft.pageObjects.EposAddFNAPage;
import com.CucumberCraft.pageObjects.EposCreateProposalPage;
import com.CucumberCraft.pageObjects.EposDrawerMenu;
import com.CucumberCraft.pageObjects.LoginEPOSAppPage;
import com.CucumberCraft.supportLibraries.DriverManager;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import io.appium.java_client.AppiumDriver;

public class EposCreateProposal extends MasterStepDefs {

	AppiumDriver driver=DriverManager.getDriver(); 

	@Given("^I am in the home page$")
	public void i_am_in_the_home_page() throws Throwable {
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^I will search for the customer for whom FNA is completed and pending for prospect$")
	public void i_will_search_for_the_customer_for_whom_FNA_is_completed_and_pending_for_prospect() throws Throwable {
	    
		driver.findElementByXPath(EposDrawerMenu.tab_Drawer_Menu).click();
		
		//To click on Customer List 
		textClick("Customer List",5,driver);
		driver.findElementByXPath(EposAddFNAPage.txt_cust).sendKeys("LIU FANG");
		driver.findElementByXPath(EposAddFNAPage.btn_Key_GO).click();
		
		//Always add a space in customer name in the parameter passed
		CustomerClick("LIU FANG",driver);
		
		//If password window pop-up
		try{
			if(driver.findElementByXPath(LoginEPOSAppPage.btn_number_1).isDisplayed()){
				driver.findElementByXPath(LoginEPOSAppPage.btn_number_1).click();
				Thread.sleep(3000);
				driver.findElementByXPath(LoginEPOSAppPage.btn_number_1).click();
				Thread.sleep(3000);
				driver.findElementByXPath(LoginEPOSAppPage.btn_number_1).click();
				Thread.sleep(3000);
				driver.findElementByXPath(LoginEPOSAppPage.btn_number_1).click();
				Thread.sleep(3000);
			}
		}catch(Exception e){
		//do nothing		
				
			}
		
	    
	}

	@Then("^click on drawer menu and navigate to Proposal$")
	public void click_on_drawer_menu_and_navigate_to_Proposal() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElementByXPath(EposCreateProposalPage.tab_Drawer_Menu).click();
	    
	}

	@Then("^click on create prospect button$")
	public void click_on_create_prospect_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElementByXPath(EposCreateProposalPage.tab_Proposal).click();
		
		//To handle download button
		try
		{
			
			if(driver.findElementByXPath(EposCreateProposalPage.btn_Download).isDisplayed()){
				driver.findElementByXPath(EposCreateProposalPage.btn_Download).click();
			}
			
		}catch(Exception ex){
			
		}
		//To handle sync time
		try
		{
			
			do
			{
				Thread.sleep(100);
			} while(driver.findElementByXPath(EposCreateProposalPage.ldg_Create_Prop).isDisplayed());
		}catch(Exception e){
			//Do nothing
		}
		driver.findElementByXPath(EposCreateProposalPage.btn_Create_Proposal).click();
	    
	}

	@Then("^enter valid password and click on login button in Compprop$")
	public void enter_valid_password_and_click_on_login_button_in_Compprop() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		//Loading time for Comprop
		try{
			do{
				Thread.sleep(100);
			}while(driver.findElementByXPath(EposCreateProposalPage.Ldg_Comp_Prop).isDisplayed());
		}catch(Exception e){
			//Do nothing
		}
				
		//Function to login Comprop Application
		CompropLogin("Abcd1234",driver);
				   
	}

	@Then("^enter iD/Passport# as \"([^\"]*)\" Smoker status as Non-Smoker and click on Basic Plan tab$")
	public void enter_iD_Passport_as_Smoker_status_as_Non_Smoker_and_click_on_Basic_Plan_tab(String passport) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.context("WEBVIEW");
		//To handle Pop-Up message
		try{
			if (driver.findElementByXPath(EposCreateProposalPage.btn_Popup).isDisplayed()){
				driver.findElementByXPath(EposCreateProposalPage.btn_Popup).click();
			}	
		}catch(Exception e){
			
		}
		
		
		driver.findElementByXPath(EposCreateProposalPage.txt_Passport).sendKeys(passport);
		
		//Hide the keyboard
		try{
			if(driver.findElementByXPath(EposDrawerMenu.btn_Hide_Keyb).isDisplayed()){
				driver.findElementByXPath(EposDrawerMenu.btn_Hide_Keyb).click();
			}
		}catch(Exception e){}
			
		
		
		
		//driver.findElementByXPath(EposCreateProposalPage.btn_Smoker).click();
		driver.findElementByXPath(EposCreateProposalPage.btn_Smoker_Stat).sendKeys("Non-Smoker");
		
		//Smoker details for dependant
		//driver.findElementByXPath(EposCreateProposalPage.btn_Dep_Smoker).click();
		driver.findElementByXPath(EposCreateProposalPage.btn_Dep_Smoker_Stat).sendKeys("Non-Smoker");
	}

	@Then("^Select Basic Plan as \"([^\"]*)\" Notional amount as \"([^\"]*)\" and click calculate button$")
	public void select_Basic_Plan_as_Notional_amount_as_and_click_calculate_button(String plan, String amount) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElementByXPath(EposCreateProposalPage.tab_Basic_Plan).click();
		Plan_Selector_Comprop("Alpha Regular Investor 20",driver);
		
		driver.context("WEBVIEW");
		driver.findElement(By.name("planned_prem")).sendKeys("24000");
		//driver.findElementByXPath("//*[@name=\"planned_prem\"]").sendKeys("12000");
		//driver.findElementByXPath("//*[@name=\'planned_prem\']").sendKeys("24000");
		//driver.findElementByXPath("//*[@name=\'planned_prem\']").sendKeys("24000");
		
		//driver.findElementByXPath(EposCreateProposalPage.txt_Amount).clear();
		//driver.findElementByXPath(EposCreateProposalPage.txt_Amount).sendKeys(amount);
		
		//Hide the keyboard
		try{
		driver.findElementByXPath(EposDrawerMenu.btn_Hide_Keyb).click();
		}catch(Exception ex){}
		
		driver.findElementByXPath(EposCreateProposalPage.btn_Preview).click();
	}

	@Then("^click on Premium summary tab$")
	public void click_on_Premium_summary_tab() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
	    
	}

	@Then("^click on Print button$")
	public void click_on_Print_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElementByXPath(EposCreateProposalPage.btn_print).click();
	}

	@Then("^navigated to Print options tab$")
	public void navigated_to_Print_options_tab() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 
	}

	@Then("^select Proposal language as English and click on Print button$")
	public void select_Proposal_language_as_English_and_click_on_Print_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElementByXPath(EposCreateProposalPage.btn_English).click();
		driver.findElementByXPath(EposCreateProposalPage.btn_Save).click();
		try{
			driver.context("NATIVE");	
			driver.findElementByXPath(EposCreateProposalPage.btn_Popup).click();
		}catch(Exception ex){}
		
		driver.findElementByXPath(EposCreateProposalPage.btn_print).click();
	}

	@Then("^displayed with PDF and click on back button in the PDF page$")
	public void displayed_with_PDF_and_click_on_back_button_in_the_PDF_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElementByXPath(EposCreateProposalPage.btn_Close).click();
	    
	}

	@Then("^displayed with a Proposal List$")
	public void displayed_with_a_Proposal_List() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
	    
	}

	@Then("^click on Apply/Regenerate button$")
	public void click_on_Apply_Regenerate_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElementByXPath(EposCreateProposalPage.btn_Apply_Regn).click();
	    
	}

	@Then("^displayed with FNA selection page$")
	public void displayed_with_FNA_selection_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^select the displayed FNA and click on Apply button$")
	public void select_the_displayed_FNA_and_click_on_Apply_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^navigated to PICS screen$")
	public void navigated_to_PICS_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^click on Confirm & proceed button$")
	public void click_on_Confirm_proceed_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^click on proceed button after entering missing details$")
	public void click_on_proceed_button_after_entering_missing_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^select \"([^\"]*)\" for questions A and B in replacement declaration screen and click on next button$")
	public void select_for_questions_A_and_B_in_replacement_declaration_screen_and_click_on_next_button(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^select \"([^\"]*)\" for question in identifying third-party interest screen and click on next button$")
	public void select_for_question_in_identifying_third_party_interest_screen_and_click_on_next_button(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^navigated to e-closure screen$")
	public void navigated_to_e_closure_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^click proceed button at the top right corner$")
	public void click_proceed_button_at_the_top_right_corner() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^click generate results button$")
	public void click_generate_results_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^navigated to Supporting Documents screen$")
	public void navigated_to_Supporting_Documents_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^upload mandatory document and click on proceed button$")
	public void upload_mandatory_document_and_click_on_proceed_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^enter Payment mode as Annual Third party payment as  No Payment currency as HKD Payment method as Cash and click on proceed button$")
	public void enter_Payment_mode_as_Annual_Third_party_payment_as_No_Payment_currency_as_HKD_Payment_method_as_Cash_and_click_on_proceed_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^navigated to Signature screen$")
	public void navigated_to_Signature_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^enter witness name as \"([^\"]*)\" and click on next button$")
	public void enter_witness_name_as_and_click_on_next_button(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^sign in Financial Needs Analysis screen and click on next button$")
	public void sign_in_Financial_Needs_Analysis_screen_and_click_on_next_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^enter MCV refernce as \"([^\"]*)\" in declaration form and click next button$")
	public void enter_MCV_refernce_as_in_declaration_form_and_click_next_button(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^click on submit application button$")
	public void click_on_submit_application_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

		
	}

