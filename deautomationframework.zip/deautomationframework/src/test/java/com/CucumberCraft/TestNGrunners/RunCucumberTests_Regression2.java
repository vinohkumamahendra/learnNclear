package com.CucumberCraft.TestNGrunners;

import java.io.File;
import java.io.IOException;
import java.util.Properties;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.apache.commons.io.FileUtils;

import com.CucumberCraft.supportLibraries.Settings;
import com.CucumberCraft.supportLibraries.TimeStamp;
import com.CucumberCraft.supportLibraries.Util;
import com.github.mkolisnyk.cucumber.reporting.CucumberResultsOverview;
import com.github.mkolisnyk.cucumber.runner.ExtendedCucumberOptions;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@ExtendedCucumberOptions(jsonReport = "target/cucumber-report/Regresssion/cucumber.json", jsonUsageReport = "target/cucumber-report/Regresssion/cucumber-usage.json", outputFolder = "target/cucumber-report/Regresssion", detailedReport = true, detailedAggregatedReport = true, overviewReport = true, usageReport = true)

/**
 * Please notice that com.CucumberCraft.stepDefinations.CukeHooks class is in
 * the same package as the steps definitions. It has two methods that are
 * executed before or after scenario. I'm using to take a screenshot if scenario
 * fails.
 */

 //@CucumberOptions(features = "src/test/resources/features",

// Path for running ARI scenarios

  @CucumberOptions(features = {"src/test/resources/features/ARI/a.Login/Login.feature",
		  						"src/test/resources/features/ARI/b.Add_Prospect/EPOS_Add_Prospect.feature",
	  							"src/test/resources/features/ARI/c.Goal_Setting/a.EPOSIntroAndGoals.feature",
	  							"src/test/resources/features/ARI/c.Goal_Setting/b.EPOSRevisitGoals.feature",
	  							"src/test/resources/features/ARI/d.FNA_Creation/CreateFNA.feature",
	  							"src/test/resources/features/ARI/e.Create_Proposal/CreateProposal.feature",
	  							"src/test/resources/features/ARI/f.Apply/Apply1.feature",
	  							"src/test/resources/features/ARI/f.Apply/Apply2.feature",
	  							"src/test/resources/features/ARI/f.Apply/Apply3.feature",
	  							"src/test/resources/features/ARI/f.Apply/Apply4.feature",
	  							"src/test/resources/features/ARI/f.Apply/Apply5.feature",
  								"src/test/resources/features/ARI/f.Apply/Apply6.feature"},


// Path for running La Vie scenarios
/*
    @CucumberOptions(features = {"src/test/resources/features/La Vie/a.Login/EPoslogin.feature",
  								 "src/test/resources/features/La Vie/b.Add_Prospect/EposAddProspect.feature",
       							 "src/test/resources/features/La Vie/d.FNA_Creation/EposCreateFNA.feature",
								 "src/test/resources/features/La Vie/c.Goal_Setting/EPOSGoals.feature",
                                 "src/test/resources/features/La Vie/e.Create_Proposal/CreateProposal_1.feature",
								 "src/test/resources/features/La Vie/e.Create_Proposal/CreateProposal_2.feature",
								 "src/test/resources/features/La Vie/e.Create_Proposal/FNAErrorValidation.feature",
							     "src/test/resources/features/La Vie/e.Create_Proposal/FNAValidationClearCase.feature",
								 "src/test/resources/features/La Vie/f.Apply/Apply1.feature",
                                 "src/test/resources/features/La Vie/f.Apply/Apply2.feature",
                                 "src/test/resources/features/La Vie/f.Apply/Apply3.feature",
								 "src/test/resources/features/La Vie/f.Apply/Apply4.feature",
								 "src/test/resources/features/La Vie/f.Apply/Apply5.feature"},


*/
// Path for running Manu-Guard scenarios
/*
@CucumberOptions(features = { "src/test/resources/features/Manu Guard/a.Login/Login.feature",
							  "src/test/resources/features/Manu Guard/b.Add_Prospect/EposAddProspect.feature",
		                      "src/test/resources/features/Manu Guard/c.Goal_Setting/EPOSGoals.feature",
		                      "src/test/resources/features/Manu Guard/d.FNA_Creation/CreateFNA.feature",
		                      "src/test/resources/features/Manu Guard/e.Create_Proposal/CreateProposal.feature",
		                      "src/test/resources/features/Manu Guard/e.Create_Proposal/FNAValidation.feature",
		                      "src/test/resources/features/Manu Guard/f.Apply/Apply1.feature",
		                      "src/test/resources/features/Manu Guard/f.Apply/Apply2.feature",
		                      "src/test/resources/features/Manu Guard/f.Apply/Apply3.feature",
		                      "src/test/resources/features/Manu Guard/f.Apply/Apply4.feature",
		                      "src/test/resources/features/Manu Guard/f.Apply/Apply5.feature"},
*/		                      
//ARI tags=@ARI_Login,@ARI_AddProspect,@ARI_Intro_and_Goals,@ARI_Revisit_Goals,@ARI_Create_FNA,@ARI_Create_Proposal,ARI_Apply1,ARI_Apply2,ARI_Apply3,ARI_Apply4,ARI_Apply5,ARI_Apply6
//La Vie tags=@LaVie_Login,@LaVie_AddProspect,@LaVie_AddGoals,@LaVie_CreateFNA,@LaVie_CreateProposal1,@LaVie_CreateProposal2,@LaVie_FNAErrorValidation,@LaVie_FNAClearcase,@LaVie_Apply1,@LaVie_Apply2,@LaVie_Apply3,@LaVie_Apply4,@LaVie_Apply5
//ManuGuard tags=@ManuGuard_Login,@ManuGuard_AddProspect,@ManuGuard_Goalsetting,@ManuGuard_FNAcreation,@ManuGuard_CreateProposal,@ManuGuard_FNAvalidation,@ManuGuard_Apply1,@ManuGuard_Apply2,@ManuGuard_Apply3,@ManuGuard_Apply4,@ManuGuard_Apply5
		glue = { "com.CucumberCraft.stepDefinitions" },

		tags = { "@ARI_AddProspect,@ARI_Intro_and_Goals,@ARI_Revisit_Goals,@ARI_Create_FNA,@ARI_Create_Proposal,@ARI_Apply1,@ARI_Apply2,@ARI_Apply3,@ARI_Apply4,@ARI_Apply5,@ARI_Apply6" },
		
		monochrome = true, plugin = { "pretty",
				"pretty:target/cucumber-report/Regresssion/pretty.txt", "html:target/cucumber-report/Regresssion",
				"json:target/cucumber-report/Regresssion/cucumber.json",
				"junit:target/cucumber-report/Regresssion/cucumber-junitreport.xml" })
				

		

public class RunCucumberTests_Regression2 extends AbstractTestNGCucumberTests {

	@AfterTest
	private void test() {
		generateCustomReports();
		copyReportsFolder();
	}

	private void generateCustomReports() {

		CucumberResultsOverview results1 = new CucumberResultsOverview();
		results1.setOutputDirectory("target");
		results1.setOutputName("cucumber-results");
		results1.setSourceFile("target/cucumber-report/Regresssion/cucumber.json");
		try {
			results1.executeFeaturesOverviewReport();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void copyReportsFolder() {

		String timeStampResultPath = TimeStamp.getInstance();

		File source = new File(Util.getTargetPath());
		File dest = new File(timeStampResultPath);

		try {
			FileUtils.copyDirectory(source, dest);
			try {
				FileUtils.cleanDirectory(source);
			} catch (Exception e) {

			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		TimeStamp.reportPathWithTimeStamp = null;

	}

	@AfterSuite
	private void copyStoredReports() {

		Properties properties = Settings.getInstance();

		if (Boolean.valueOf(properties.getProperty("TrackOldResults"))) {
			String timeStampResultPath = TimeStamp.getOldReportInstance();

			File source = new File(Util.getResultsPath());
			File dest = new File(timeStampResultPath);

			try {
				FileUtils.copyDirectory(source, dest);
			} catch (IOException e) {
				e.printStackTrace();
			}

			TimeStamp.OldreportPathWithTimeStamp = null;
		}
	}
}