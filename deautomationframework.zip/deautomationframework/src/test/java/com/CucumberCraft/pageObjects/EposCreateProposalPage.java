package com.CucumberCraft.pageObjects;

public class EposCreateProposalPage {
	
	public static String tab_Basicplan="//*[text()='Basic Plan :']";
	public static String tab_Print_Opt="//*[@name='fund activities']";
	public static String tab_Premium_Sum="//*[@name='Premium Summary']";
	public static String tab_Selected="//*[@name='tab1']";
	public static String btn_Edit_Prop="//*[@label='Edit Proposal']";
	public static String lbl_Proposal="//*[text()='Proposal List']";
	public static String btn_Supp_tab="//*[@name='rider'] | //*[@name='btnRider']";
	public static String txt_Surname = "//*[@name='primary_last_name']";
	public static String lbl_Proposallst = "//*[text()='Proposal List']";
	public static String txt_Givenname = "//*[@name='primary_given_name']";
	public static String txt_Proposalage = "//*[@name='primary_age']";
	public static String btn_Others = "//*[text()='OTHERS']";
	public static String btn_Currency_USD = "//*[text()='USD']";
	public static String btn_RCC = "//*[@name='rcc_Accidental and Disability Protection']";
	public static String tab_Proposal = "//AppiumAUT/UIAApplication[1]/UIAWindow[1]/UIAButton[7]";
	public static String tab_Supplemetary = "//*[@name='btnRider']";
	public static String tab_Basic_Plan = "//*[@name='basic_plan']|//*[@name='btnBasePlan']";
	public static String tab_Drawer_Menu = "//*[@label='icon menu']|//*[@label='icon action mainmenu green']";
	public static String tab_Rider = "//*[@name='rider']";
	public static String rdn_Proposal = "//*[@class='dot']";
	public static String txt_Pwd = "//*[@name='password']";
	public static String btn_Create_Proposal = "//*[@label='Create Proposal']";
	public static String btn_Login = "//UIALink[@label='LOGIN']";
	public static String btn_Popup = "//*[@label='OK']";
	public static String btn_Smoker_Stat = "//*[@name=\"primary_non_smoker\"]//*[text()=\"Standard\"] | //*[@name=\"primary_non_smoker\"]";
	public static String lst_Payment_Mode = "//*[text()=\"Annual\"]";
	public static String lst_Payment_Mode2 = "//*[@label='Quarterly']";
	public static String btn_Smoker1 = "//*[@label='Please Select']";
	public static String btn_Non_Smoker = "//*[@label='Non-Smoker']";
	public static String btn_Save = "//UIAWebView/UIALink[5]|//*[@id='save1']//*[@class='btn']";
	public static String btn_Save_Opt = "//*[@name=\"btnSave_2\"]";
	public static String btn_English = "//UIAWebView/UIAElement[2]|//*[@value='1']";
	public static String ldg_Create_Prop = "//*[@name='loader.png']";
	public static String Ldg_Comp_Prop = "//UIAApplication/UIAWindow[1]/UIAStaticText[13]";
	public static String btn_Dwn = "//*[@label='YES']";
	public static String btn_Download = "//*[@label='DOWNLOAD']";
	public static String btn_Dep_Smoker_Stat = "//*[@name=\"secondary_non_smoker\"]//*[text()=\"Standard\"]|//*[@name='secondary_non_smoker']";
	public static String btn_Crmp_Ok = "//*[@id='go_btn']";
	public static String btn_Plan_Selector = "//*[@value='Please Select']";
	public static String btn_Plan_Selector1 = "//*[@label='Alpha Regular Investor 10']";
	public static String btn_Preview = "//IMG[contains(@name,'Preview')]";
	public static String btn_Apply = "//*[text()='APPLY']";
	public static String btn_Apply_Regn = "//*[@label='APPLY / REGENERATE']";
	public static String btn_Close = "//*[@label='icon close']";
	public static String btn_print = "//IMG[contains(@name,'Print')] | //*[@name=\"btnPrint\"]";
	public static String btn_Print_Opt = "//*[@name=\"btnPrint\"]";
	public static String txt_Passport = "//*[@name='primary_id_passport']";
	public static String txt_Amount = "#planOpt020 > td:nth-of-type(2) > input[name='face_amount']";
	public static String lbl_Prot_Amt="//*[text()='Protection Amount']";
	// Check box in Rider tab
	public static String chk_CA475 = "//*[@name='check_box_CA475']";
	public static String chk_CIB = "//*[@name='check_box_CIB']";
	public static String chk_AAB = "//*[@name='check_box_AAB']";
	public static String chk_AH75 = "//*[@name='check_box_AH75']";
	public static String chk_AJ75 = "//*[@name='check_box_AJ75']";
	public static String chk_HQ99 = "//*[@name='check_box_HQ99']";

	// Text box in Rider tab
	public static String txt_CA475 = "//*[@name='face_amount_CA475']";
	public static String txt_CIB = "//*[@name='face_amount_CIB']";
	public static String txt_AAB = "//*[@name='face_amount_AAB']";
	public static String txt_AH75 = "//*[@name='face_amount_AH75']";
	public static String txt_AJ75 = "//*[@name='face_amount_AJ75']";

	// IPO check box
	public static String chk_IPOCA475 = "//*[@name='rider_ipo_CA475']";
	public static String chk_IPOCIB = "//*[@name='rider_ipo_CIB']";
	public static String chk_IPOAJ75 = "//*[@name='check_box_HQ99']";

}
