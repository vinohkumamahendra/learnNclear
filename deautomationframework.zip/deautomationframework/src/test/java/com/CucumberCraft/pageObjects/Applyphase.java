package com.CucumberCraft.pageObjects;

public class Applyphase {
	                                              
	public static String lbl_Error_Handed="//DIV[@id='personalInfoInsuredHandLaterality-control']/LABEL/SPAN[@class='required-msg tds-visible']";
	public static String lbl_Sig_Own_Handwriting="//*[@class='tds-signature-img']";
	public static String lbl_Occ_Err="//UIAStaticText[contains(@label,'Occupation class = 1 is')]";
	public static String btn_Lefthand="//*[text()='Left Handed']";
	public static String btn_Righthand="//*[text()='Right Handed']";
	public static String btn_Doc_Iss_Ctry="//*[@id='personalInfoPolicyownerIdentityDocumentIssueCountry-control']//*[@id='undefined_button']";
	public static String btn_Pymt_Method="//*[@class='payment-select-method category-filter ng-isolate-scope']//*[@class='selectize-input']";
	public static String lbl_Payment_Mode="//*[text()='Payment Mode']";
	public static String lbl_PICS = "//H4[contains(text(),'Please scroll down and read the PICS ')]";
	public static String lbl_PersInfo = "//*[text()='Personal Information']";
	public static String lbl_Password = "//*[text()='Enter your 4 digits passcode']";
	public static String txt_Pageno = "//DIV[contains(text(),'Step 10 of 11')]";
	public static String lbl_PDF = "//*[@label='Please read through the document and provide signature.']";
	public static String lbl_PDF_Apply = "//*[@label='Progress']/following-sibling::UIAStaticText";
	public static String lbl_MCV = "//*[@label='MCV Reference']";
	public static String btn_Edit = "//*[@class='summary-wrapper ng-scope ng-isolate-scope']/div[1]/div[1]";
	public static String Lbl_Applyheader = "//*[@class='tds-progress-label ng-binding']";
	public static String btn_Save = "//*[text()='Save']";
	public static String lbl_Currency = "//*[text()='Basic Premium']/parent::P/DIV/LABEL";
	public static String lbl_Currencyvalue = "//*[text()='Basic Premium']/parent::P/DIV/INPUT";
	public static String lbl_Ridercurrency = "//DIV[contains(text(),'Protection Amount (USD)')]";
	public static String txt_Payorsurname = "//*[@id='BasicSection.personalInfoPayorSurname']";
	public static String txt_Payorgivenname = "//*[@id='BasicSection.personalInfoPayorGivenName']";
	public static String txt_Payorsex = "//*[@id='personalInfoPayorSex-control']//*[@id='undefined_button']";
	public static String lbl_Prop_Insured = "//*[text()='Proposed Insured']";
	public static String lbl_Payor = "//*[text()='Payor']";
	public static String lst_Relationship = "//*[@id='personalInfoPolicyownerRelationshipToProposedInsured-control']//*[@id='undefined_button'] | //*[@id='personalInfoPayorRelationshipToInsured-control']//*[@id='undefined_button']";
	public static String lst_Relationship_Payor = "//*[@id='personalInfoPayorRelationshipToInsured-control']//*[@id='undefined_button']";
	public static String chk_button = "//*[@id='checkbox1'] | //*[@class='checkbox-custom-label checkboxErr-true']";
	public static String txt_Chn_Name = "//*[@id='BasicSection.personalInfoPolicyownerInsuredChineseName'] | //*[@id='BasicSection.personalInfoPolicyownerChineseName']";
	public static String btn_Date_Pick = "//*[@id='personalInfoPolicyownerInsuredDateOfBirth-control']//*[@class='date-picker-icon']";
	public static String ldg_Gen_Results = "//*[@label='Loading']";
	public static String btn_Payment = "//*[@class=\"payment-select-method subsequent-payment-select category-filter ng-isolate-scope\"]//*[@class=\"selectize-input\"]";
	public static String btn_Add_Inv_Choice = "//*[text()='Add Investment Choices']";
	public static String txt_Allocation = "//*[@id='InvestmentFundDetailsSection.solutionInfoILASFundDetailsRepeater.0.solutionInfoILASFundDetailsAllocation']";
	public static String lbl_Chinese = "//*[text()='Chinese Name'] | //*[@id='personalInfoPolicyownerChineseName-control']//*[@class='tds-label']";
	public static String txt_Health_Sug = "//*[@class='suggestion ng-binding ng-scope']";
	public static String btn_Apply_Reg = "Apply / Regenerate";
	public static String pdgSignatureNeedleAppForm = "";
	public static String ele_Ldg_PDF = "//*[@name='loader.png']";

	public static String Ele_Apply_lodg = "//*[@class='container ng-scope']";
	public static String btn_FNA = "//*[@class='dot']";
	public static String btn_Cam_OK = "//*[@label=\"Ok\"]";
	public static String btn_Apply = "//*[text()='APPLY']";
	public static String btn_Yes = "//*[@label='Yes']";
	public static String btn_Q1 = "//*[@id='AgreementsReplacementAndCPDReplacement.agreementsReplacementPolicyReplacement']//*[text()='Yes']/i[1]";
	public static String btn_Thirdparty = "//*[@id='section-1.agreementsThirdPartyInterestsFlag']//*[text()='Yes']/i[1]";
	public static String btn_CRS = "//*[@id='section-1.agreementsFATCACitizenship']//*[text()='Yes']/i[1]";
	// DOB and policy year date fields
	public static String txt_DOB = "//*[@id='BasicSection.personalInfoPolicyownerInsuredDateOfBirth'] | //*[@id='solutionInfoNonILASInsuredsBasePolicySection.solutionInfoNonILASPolicyYearDate']";
	public static String txt_Place_Birth = "//*[@id='BasicSection.personalInfoPolicyownerInsuredPlaceOfBirthCity'] | //*[@id='BasicSection.personalInfoPolicyownerPlaceOfBirthCity']";

	public static String txt_Place_Birth_Cnty = "//*[@id='personalInfoPolicyownerInsuredPlaceOfBirthCountry-control']//*[@id='undefined_button'] | //*[@id='personalInfoPolicyownerPlaceOfBirthCountry-control']//*[@id='undefined_button']";
	public static String txt_Identity_Doc = "//*[@id='personalInfoPolicyownerInsuredIdentityDocumentType-control']//*[@id='undefined_button'] | //*[@id='personalInfoPolicyownerIdentityDocumentType-control']//*[@id='undefined_button']";
	public static String txt_Identity_Doc_Ins = "//*[@id='personalInfoInsuredIdentityDocumentType-control']//*[@id='undefined_button']";
	public static String txt_Identity_Doc_Payor = "//*[@id='personalInfoPayorIdentityDocumentType-control']//*[@id='undefined_button']";
	public static String txt_Identity_Doc_no = "//*[@id='BasicSection.personalInfoPolicyownerInsuredIdentityDocumentNo'] | //*[@id='BasicSection.personalInfoPolicyownerIdentityDocumentNo']";
	public static String txt_Identity_Doc_no_Ins = "//*[@id='BasicSection.personalInfoInsuredIdentityDocumentNo']";
	public static String txt_Identity_Doc_no_Payor = "//*[@id='BasicSection.personalInfoPayorIdentityDocumentNo']";
	public static String btn_nationality = "//*[@id='personalInfoPolicyownerInsuredNationality-control']//*[@id='undefined_button'] | //*[@id='personalInfoPolicyownerNationality-control']//*[@id='undefined_button']";
	public static String btn_nationality_Ins = "//*[@id='personalInfoInsuredNationality-control']//*[@id='undefined_button']";
	public static String btn_nationality_Payor = "//*[@id='personalInfoPayorNationality-control']//*[@id='undefined_button']";
	public static String btn_Language = "//*[@id='personalInfoPolicyownerInsuredLanguagePreference-control']//*[@id='undefined_button'] | //*[@id='personalInfoPolicyownerLanguagePreference-control']//*[@id='undefined_button']";
	public static String btn_Language_Ctr_Eng = "//*[@id='BasicSection.policyContractLanguageEnglishCheckBox.item-0']//*[@class='check']";
	public static String btn_Language_Ctr_Chn = "//*[@id='BasicSection.policyContractLanguageEnglishCheckBox.item-0']//*[@class='check']";
	public static String btn_Occupation = "//*[@id='personalInfoPolicyownerInsuredOccupationButton-control'] | //*[@id='personalInfoPolicyownerOccupationButton-control']";
	public static String btn_Changeocc_Ins = "//*[@id='personalInfoInsuredChangeOccupationButton-control']//*[@class='tds-label']";
	public static String btn_Occupation_Ins = "//*[@id='personalInfoInsuredOccupationButton-control']//*[@class='tds-label']";
	public static String btn_Occupation_Payor = "//*[@id='personalInfoPayorOccupationButton-control']//*[@class='tds-label']";
	public static String btn_Sr_No = "//*[@id='JobAndIncomeSection.personalInfoPolicyownerInsuredManagementFlag']//*[text()='No']/i[1] | //*[@id='JobAndIncomeSection.personalInfoPolicyownerManagementFlag']//*[text()='No']/i[1]";
	public static String btn_Proceed = "//*[@label='Proceed']";
	public static String btn_Sr_Yes = "//*[@id='JobAndIncomeSection.personalInfoPolicyownerInsuredManagementFlag']//*[text()='Yes']/i[1]";
	public static String txt_Avg_Mnt_Inc = "//*[@id='JobAndIncomeSection.personalInfoPolicyownerInsuredAverageMonthlyIncome'] | //*[@id='JobAndIncomeSection.personalInfoPolicyownerAverageMonthlyIncomeAmount']";
	public static String txt_Avg_Mnt_Inc_Payor = "//*[@id='JobAndIncomeSection.personalInfoPayorAverageMonthlyIncome']";
	public static String txt_Avg_Mnt_Inc_Ins = "//*[@id='JobAndIncomeSection.personalInfoInsuredAverageMonthlyIncome']";
	public static String txt_Name_Emp = "//*[@id='JobAndIncomeSection.personalInfoPolicyownerInsuredNameOfEmployer'] | //*[@id='JobAndIncomeSection.personalInfoPolicyownerNameOfEmployer']";
	public static String txt_Name_Emp_Ins = "//*[@id='JobAndIncomeSection.personalInfoInsuredNameOfEmployer']";
	public static String btn_Country = "//*[@id='personalInfoPolicyownerInsuredResidentialAddressLine4-control']//*[@id='undefined_button'] | //*[@id='personalInfoPolicyownerResidentialAddressLine4-control']//*[@id='undefined_button']";
	public static String btn_Addr_lang = "//*[@id='personalInfoPolicyownerInsuredCorrespondenceAddressLang-control']//*[@id='undefined_button']";
	public static String btn_Corr_Add_Yes = "//*[@id='ContactSection.personalInfoPolicyownerInsuredAddressOnlyToThisPolicyFlag']//*[text()='Yes']/i[1]";
	public static String btn_Corr_Add_No = "//*[@id='ContactSection.personalInfoPolicyownerInsuredAddressOnlyToThisPolicyFlag']//*[text()='No']/i[1]";
	public static String btn_SMS_Yes = "//*[@id='ContactSection.personalInfoPolicyownerInsuredSMSApplicationSubmission']//*[text()='Yes']/i[1]";
	public static String btn_SMS_No = "//*[@id='ContactSection.personalInfoPolicyownerInsuredSMSApplicationSubmission']//*[text()='No']/i[1]";
	public static String btn_Statement_No = "//*[@id='ContactSection.personalInfoPolicyownerInsuredEStatementFlag']//*[text()='No']/i[1]";
	public static String btn_Statement_Yes = "//*[@id='ContactSection.personalInfoPolicyownerInsuredEStatementFlag']//*[text()='Yes']/i[1]";
	public static String btn_Smoking = "//*[@id='personalInfoPolicyownerInsuredSmokingHabitList-control']//*[@id='undefined_button']";
	public static String btn_Dateyear = "//*[@class='ui-datepicker-year']";
	public static String btn_Datemonth = "//*[@class='ui-datepicker-month']";
	public static String btn_Corr_Adr_Lang = "//*[@id='personalInfoPolicyownerInsuredCorrespondenceAddressLang-control']//*[@id='undefined_button'] | //*[@id='personalInfoPolicyownerCorrespondenceAddressLang-control']//*[@id='undefined_button']";
	// Solutiontask card
	public static String txt_Policy_Yr_Date = "//*[@id='solutionInfoNonILASInsuredsBasePolicySection.solutionInfoNonILASBackdateIndicator']//*[text()='No']/i[1]";

	// Third party fields and Direct Debit
	public static String btn_DDA ="//*[text()='DDA Section']";
	public static String txt_DirectDebit_Bankname ="//*[text()='Bank Name']/..//DIV[@class='selectize-input']";
	public static String txt_DirectDebit_Branchname ="//*[@name='branchName']";
	public static String txt_DirectDebit_Accbrno ="//*[@name='branchNo']";
	public static String txt_DirectDebit_Accno ="//*[@name='accountNo']";
	public static String txt_DirectDebit_Accname ="//*[@name='accountName']";
	public static String txt_DirectDebit_AccIDType ="//*[text()='Account Holder ID Type']/parent::DIV//DIV[@class='selectize-input']";
	public static String txt_DirectDebit_AccID ="//*[@name='accountHolderId']";
	public static String txt_DirectDebit_AccCtno ="//*[@name='accountContactNo']";
	public static String txt_DirectDebit_AccHoldpolicy ="//*[text()='Identity of Account Holder under the policy']/parent::DIV//DIV[@class='selectize-input']";
	public static String txt_DirectDebit_Subpayment ="//DIV[H2[text()='Subsequent Payment']]//DIV[@class='td-rowBoxRight subsequentPaymentSelection ng-scope']";
	public static String txt_Thirdyparty_Surname ="//*[@id='section-1.agreementsThirdPartySurname']";
	public static String txt_Thirdyparty_Gnname="//*[@id='section-1.agreementsThirdPartyGivenName']";
	public static String txt_Thirdyparty_DOB="//*[@id='section-1.agreementsThirdPartyDateOfBirth']";
	public static String txt_Thirdyparty_Passno="//*[@id='section-1.agreementsThirdPartyIdCardPassportNum']";
	public static String txt_Thirdyparty_Nationality="//*[@id='agreementsThirdPartyNationality-control']//*[@id='undefined_button']";
	public static String txt_Thirdyparty_Ctno="//*[@id='section-1.agreementsThirdPartyContactNumber']";
	public static String txt_Thirdyparty_Occ="//*[@id='section-1.agreementsThirdPartyOccupationBusiness']";
	public static String txt_Thirdyparty_ResAddr="//*[@id='section-1.agreementsThirdPartyResidentialOfficeAddress']";
	public static String txt_Thirdyparty_Rel="//*[@id='section-1.agreementsThirdPartyRelationshipToPolicyowner']";
	public static String btn_Cancel="//*[@label='Cancel']";
	public static String btn_Close="//*[@label='icon close']";
	
	
	public static String txt_Surname = "//*[@id='BeneficiariesSection.solutionInfoNonILASBeneficiariesRepeater.0.solutionInfoNonILASBeneficiarySurname']";
	public static String txt_Givenname = "//*[@id='BeneficiariesSection.solutionInfoNonILASBeneficiariesRepeater.0.solutionInfoNonILASBeneficiaryGivenName']";
	public static String txt_Share = "//*[@id='BeneficiariesSection.solutionInfoNonILASBeneficiariesRepeater.0.solutionInfoNonILASBeneficiaryAllocation']";
	public static String txt_relationship = "//*[@id='solutionInfoNonILASBeneficiaryRelationshipToInsured-control.1']//*[@id='undefined_button']";
	public static String btn_Under18 = "//*[@id='BeneficiariesSection.solutionInfoNonILASBeneficiariesRepeater.0.solutionInfoNonILASBeneficiaryYoungerThan']//*[text()='No']/i[1]";
	public static String btn_AddBenif = "//*[text()='Add Beneficiary']";
	public static String btn_Benif_Status = "//*[@id='solutionInfoNonILASBeneficiaryStatus-control.1']//*[@id='undefined_button']";
	// Agreement task card

	public static String btn_Next = "//*[@class='tds-btn-next ng-binding'] | //*[@label='Next']";
	public static String btn_Eng_Disclosure = "//*[@label='English']";

	// Phase-4
	public static String btn_Gen_Results = "//*[@label='GENERATE RESULTS']";
	public static String btn_Upload1 = "//UIATableCell[@name='Identity card/ Passport *']//*[@label='icon photo green']";
	public static String btn_Upload2 = "//UIATableCell[@name='Address proof']//*[@label='icon photo green']";
	public static String btn_Takepic = "//*[@label='Take Picture']";
	public static String btn_Usephoto = "//*[@label='Use Photo']";
	public static String btn_Qty_Payment = "//*[text()='Quarterly Premium']";
	public static String btn_yes = "//*[text()='Yes']";
	public static String btn_Direct_Bill = "//*[text()='Direct Billing']";
	public static String btn_Loading = "//*[@value='Foggy']";
	public static String txt_Witnessname = "//UIAScrollView[2]/UIATextField[1] | //UIATextField";
	public static String btn_SubmitApplication = "//*[@label='SUBMIT APPLICATION']";
	public static String Ele_Submitted = "//*[text()='You have completed all the application procedures.']";
	public static String btn_OK = "//*[@label='OK']";
	public static String btn_Confirm = "//*[@label='Confirm'] | //*[@label='CONFIRM']";
	public static String btn_Adv_Stat = "//*[text()='Advisor's Statement']";
	public static String btn_Wit_Qn = "//*[@id='section-1.advisorStatementAgentFlag']//*[text()='No']/i[1]";
	public static String btn_Fac_Qn = "//*[@id='section-1.advisorStatementOtherFactorForUWFlag']//*[text()='No']/i[1]";
	public static String txt_Rcpt_No = "//*[@id='section-1.advisorStatementSerialNoOnTemporaryReceipt']";
	public static String txt_Adv_code = "//*[@id='section-1.advisorStatementOtherAgentRepeater.0.advisorStatementAgentCodes']";
	public static String ldg_Gen_PDF = "//*[@name='loader.png']";
	public static String txt_Fatca_Addr = "//*[@id='section-1.agreementsFATCAAddress']";
	public static String txt_Fatca_City = "//*[@id='section-1.agreementsFATCAAdressCity']";
	public static String txt_Fatca_State = "//*[@id='section-1.agreementsFATCAState']";
	public static String txt_Fatca_Zip = "//*[@id='section-1.agreementsFATCAAddressZip']";
	public static String lbl_Appl_Overview = "//H2[contains(text(),'Application Information')]";
	public static String lbl_Status = "//H2[contains(text(),'Completed')]";
}
