package com.CucumberCraft.pageObjects;

public class Eposgoals {

	public static final String btn_Manage_Goals = "//*[text()='Manage Goals']";
	public static final String btn_Family_Dep = "//*[@class='goal-list scroll']/li[2]/div[1]/div[4]/div[1]";
	public static final String btn_Prep_Retr = "//*[@class='goal-list scroll']/li[6]/div[1]/div[4]/div[1]";
	public static final String btn_Save_Proceed = "//*[@class='button save  positiveButton'] | *[@class='button positiveButton save  proceed'] | //*[@class='save button positiveButton savebtn-analysis cp-button']";
	public static final String btn_Close = "//*[@label='icon close'] | //*[@class='icon close-btn']";
	public static final String Save_And_Proceed = "//BUTTON[contains(text(),'Save and Proceed')] | //BUTTON[contains(text(),'SAVE AND PROCEED')] | //BUTTON[contains(text(),'SAVE and PROCEED')]";
	public static String btn_Goal = "//*[text()='Goals']/parent::HEADER/BUTTON";
	public static String btn_Cal_Goal_Retr = "//*[@class='goal-card retirement-card']//*[@class='message']";
	public static String btn_Cal_Goal_Wellbeing = "//*[@class='goal-card protection-card']//*[@class='message']";
	public static String btn_Navigate = "//*[@class='page-next swipe-button']//span";
	public static String btn_Introduction = "//H2[contains(text(),'Introduction')]/parent::HEADER/BUTTON";
	public static String lbl_Introduction = "//*[text()='Introduction']";

}
