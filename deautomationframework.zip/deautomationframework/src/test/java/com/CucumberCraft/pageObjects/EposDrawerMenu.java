package com.CucumberCraft.pageObjects;

public class EposDrawerMenu {

	public static final String btn_logout = "//UIAApplication/UIAWindow[1]/UIAButton[16]";
	public static final String btn_Cust_list = "//UIAApplication/UIAWindow[1]/UIAButton[3]";
	public static final String tab_Drawer_Menu = "//*[@label=\"icon action mainmenu green\"]";

	// Pop-up download button
	public static final String btn_download = "//*[@label='DOWNLOAD']";
	public static final String btn_Cust_Name = "//UIATableCell[@name='Ron Test ']/UIAButton[1]";
	// UIATableCell[@name="Erty Dfgh "]/UIAButton[1]

	// native Keyboard
	public static final String btn_Hide_Keyb = "//*[@label=\"Hide keyboard\"]";

}
