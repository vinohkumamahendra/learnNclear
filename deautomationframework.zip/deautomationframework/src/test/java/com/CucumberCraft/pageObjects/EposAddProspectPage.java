package com.CucumberCraft.pageObjects;

public class EposAddProspectPage {

	public static String txt_surname = "//*[@name='surname']";
	public static String txt_givenname = "//*[@name='givenName']";
	public static String txt_countrycode = "//*[@class='dropdownValue']";
	public static String lst_Insured = "//SELECT[contains(@name,'selected_insured')]";
	public static String txt_phonenumber = "//*[@name='phone']";
	public static String txt_email = "//*[@name='email']";
	public static String txt_malegender = "//*[@label='Male'] | //*[text()='Male']";
	public static String txt_femmalegender = "//*[@label='Female'] | //*[text()='Female']";
	public static String chk_agreetext = "//*[@label=\"I have read and agree to the PICS notice.\"] | //*[@class='small']";
	public static String btn_OK = "//*[@label=\"OK\"]";
	public static String btn_Yes="//*[@label='YES']";

	// Screen name
	public static String ele_econsent_screen = "//*[@label='PUB NAME OF 303345  e-Consent']";

	// buttons
	public static String btn_addprospect = "//*[@label='ADD PROSPECT']";
	public static String btn_continue = "//*[@label='CONTINUE'] | //*[@class='cp-button button positiveButton pos-left']";
	public static String btn_submit = "//*[@label='SUBMIT']";
	public static String btn_confirm = "//*[@label='CONFIRM']";

	// link
	public static String lnk_ignore = "//*[@label='Skip this step for now'] | //*[@id='skip']";

	// heading of profile page
	public static String pge_header = "//*[@label='Profile'] | //*[text()='Profile']";

}
