package com.CucumberCraft.pageObjects;

public class LoginEPOSAppPage {

	// text fields user name and password in login page

	public static final String txt_username = "//*[@label='User account']";
	public static final String txt_password = "//*[@label='Password']";

	// sign in button and add prospect button

	public static String btn_addprospect = "//*[@label='ADD PROSPECT']";
	public static final String btn_signin = "//*[@label='Sign in']";
	public static final String btn_Eng_language = "//*[@label='ENGLISH'] | //*[text()='English']";
	public static final String btn_Eng_Agree = "//*[@label='AGREE'] | //*[@label='同意']";
	public static final String btn_Eng_Disagree = "//*[@label='DISAGREE']";

	// Chinese language

	public static final String btn_Chi_language = "//*[@label='中文（繁體）'']";
	public static final String btn_Chi_Agree = "//*[@label='同意']";
	public static final String btn_Chi_Disagree = "//*[@label='不同意']";

	// Password grid

	public static final String btn_number_1 = "//*[@label='1'] | //*[text()='1']";
	public static final String btn_number_2 = "//*[@label='2']";
	public static final String btn_number_3 = "//*[@label='3']";
	public static final String btn_number_4 = "//*[@label='4']";
	public static final String btn_number_5 = "//*[@label='5']";
	public static final String btn_number_6 = "//*[@label='6']";
	public static final String btn_number_7 = "//*[@label='7']";
	public static final String btn_number_8 = "//*[@label='8']";
	public static final String btn_number_9 = "//*[@label='9']";
	public static final String ele_enterpasscode = "//*[@label='Re-enter your 4 digits passcode']";

	// Notification

	public static final String btn_notfy_allow = "//*[@label='Allow']";
	public static final String btn_notfy_dontallow = "//*[@label='Don’t Allow']";
	public static final String img_Login_Ldg = "//*[@name='Splash.png'] | //*[@label='Data update in progress']";
}
