package com.CucumberCraft.pageObjects;

import java.sql.Driver;
import org.openqa.selenium.Dimension;

public class EposAddFNAPage {

	// Clicking on FNA tab
	public static final String lbl_FNA_Sel="//*[text()='FNA Selection']";
	public static final String lbl_Proposal_Screen = "//*[@id='logo']//img";
	public static final String lbl_FNA = "//*[text()='FNA']";
	public static final String scr_FNA = "//*[text()='FNA']";
	public static final String tab_RPQ = "//*[@label='RPQ']";
	public static final String btn_FNA_Close = "//*[@class='icon close-btn']";
	// create FNA button
	public static final String btn_FNA = "//*[@label='CREATE FNA']";
	public static final String lbl_FNApanel="//*[@class='panelz left yellow thin']//*[text()='FNA']";

	// Pop-up ok button
	public static final String btn_OK = "//*[@label=\"Ok\"]";
	                                     //*[@label="OK"] 
	// Each tabs in Page
	public static final String tab_Pers_Info = "//*[@label='Personal Information']";
	public static final String tab_Buy_Obj = "//*[@label='Buying Objectives']";
	public static final String tab_Typ_Ins_Prd = "//*[@label='Type of Insurance Product']";
	public static final String tab_Tar_Benft_Period = "//*[@label='Target Benefit / Protection Period']";
	public static final String tab_Avg_Mnt_Inc = "//*[@label='Average Monthly Income']";
	public static final String tab_Cum_Liq_Asset = "//*[@label='Cumulative Liquid Assets']";
	public static final String tab_Contr_Dur = "//*[@label='Contribution Duration']";
	public static final String tab_Aveg_Mnt_Exp = "//*[@label='Average Monthly Expenses']";
	public static final String tab_Disp_Inc = "//*[@label='Disposable Income']";
	public static final String tab_Src_Fnds = "//*[@label='Source of Funds']";

	// Personal Information
	public static final String txt_Age = "//UIAStaticText[@label='Age']/following::UIATextField[1]";
	public static final String txt_Iss_Age = "//UIAStaticText[@label='Insured Issue Age']/following::UIATextField[1]";
	public static final String txt_Phone_No = "//UIAStaticText[@label='Phone Number']/following::UIATextField[1]";

	// Occupation fields
	public static final String txt_Occupation = "//*[@label='Please Select']";
	public static final String txt_Occ_Prof = "//*[@label='Professionals']";
	public static final String txt_Occ_Car_Start = "//*[@label='Career Starter']";
	public static final String txt_Occ_Civ_Ser = "//*[@label='Civil Servants']";
	public static final String txt_Occu_Exec = "//*[@label='Executives']";
	public static final String txt_Occ_Inter_Staff = "//*[@label='Intermediate Staff']";

	public static final String btn_Surn_Mr = "//*[@label='Mr']";
	public static final String btn_Surn_Miss = "//*[@label='Miss']";
	public static final String btn_Surn_Mrs = "//*[@label='Mrs']";
	public static final String btn_Surn_Ms = "//*[@label='Ms']";

	public static final String btn_Single = "//*[@label='Single']";
	public static final String btn_Married = "//*[@label='Married']";
	public static final String btn_Divorce = "//*[@label='Divorced']";
	public static final String btn_Widowed = "//*[@label='Widowed']";

	// Number of dependents
	public static final String btn_Dep_Zero = "//*[@label='0']";
	public static final String btn_Dep_One = "//*[@label='1']";
	public static final String btn_Dep_Two = "//*[@label='2']";
	public static final String btn_Dep_Three = "//*[@label='3]";
	public static final String btn_Dep_Four = "//*[@label='4']";

	// Number type field
	public static final String btn_Numb_home = "//*[@label='Home']";
	public static final String btn_Numb_mobile = "//*[@label='Mobile']";
	public static final String btn_Numb_off = "//*[@label='Office']";

	// Higher Education Level

	public static final String btn_Univ = "//*[@label='University or Above']";
	public static final String btn_Post_sec = "//*[@label='Post-Secondary/College']";
	public static final String btn_Pri_Sch = "//*[@label='Primary school or below']";
	public static final String btn_Sec_Sch = "//*[@label='Secondary school']";

	// Buying Objectives page
	// Options-A,B,C,D,E,F

	public static final String btn_proceed = "//*[@label='Proceed']";
	public static final String btn_close = "//*[@label='close btn']";

	// public static final String
	// txt_tgt_fld1="//UIAApplication/UIAWindow[1]/UIAScrollView[1]/UIATextField[1]";
	// public static final String
	// txt_tgt_fld2="//UIAApplication/UIAWindow[1]/UIAScrollView[1]/UIATextField[2]";
	public static final String txt_tgt_fld1 = "//UIAButton[contains(@label,'A)')]/following::UIATextField[1]";
	public static final String txt_tgt_fld2 = "//UIAButton[contains(@label,'E)')]/following::UIATextField[1]";

	// Average Monthly Income
	// public static final String
	// btn_Spec_Amt="//UIAApplication/UIAWindow[1]/UIAScrollView[2]/UIAScrollView[1]/UIAButton[1]";
	public static final String btn_Spec_Amt = "//UIAButton[1]";
	// Amt field
	public static final String txt_Amt = "//UIAScrollView[1]/UIATextField[1]";
	public static final String btn_Foll_Rg = "//*[@label='In the following range']";

	// Proceed button
	public static final String btn_cmn_proceed = "//*[@label='Proceed']";
	public static final String btn_cnfr_proceed = "//*[@label='Confirm & Proceed']";

	public static final String btn_opt_1 = "//UIAScrollView[1]/UIAButton[1]";
	public static final String btn_opt_2 = "//UIAScrollView[1]/UIAButton[2]";
	public static final String btn_opt_othr = "//*[@label='Others - Please specify']";

	// Product selector page
	// check-boxes
	public static final String btn_prod_select = "//UIATableCell[@name='Universal Life']//*[@label='Icon Checkbox Unchecked 28 whi']";
	public static final String chk_Box_MPP = "//UIATableCell[@name='Universal Life']//*[@label='unchecked']";
	public static final String chk_Box_LAV = "//UIATableCell[@name='La Vie (RDB)']//*[@label='unchecked']";

	public static final String btn_prd_LAV = "//UIAScrollView//UIATableCell[@name='La Vie (RDB)']/UIAButton[1]";
	public static final String btn_opt_LAV1 = "//*[@label='La Vie  5']";
	public static final String btn_opt_LAV2 = "//*[@label='La Vie  8']";

	public static final String btn_prd_MPP = "//UIAScrollView//UIATableCell[@name='ManuPrestige Protector']/UIAButton[2]";
	public static final String btn_opt_MPP1 = "//*[@label='ManuPresitge Protector 5']";
	public static final String btn_opt_MPP2 = "//*[@label='ManuPresitge Protector 8']";

	// search box in customer list
	public static String txt_cust = "//*[@value='Input Name or Mobile Number']";

	// Keyboard button
	public static String btn_Key_GO = "//*[@label='Go']";

}
