package com.CucumberCraft.supportLibraries;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;

public class ReusableMethods {

	
	public static String Getcurrentdate(){
	//Get the current system date in database format
	Calendar c = Calendar.getInstance();
	SimpleDateFormat sd1 = new SimpleDateFormat("dd-MMM-yy");
	String CurrDate = sd1.format(new Date(c.getTimeInMillis()));
	return CurrDate;
	}
	
	public static void selectDateAndroid(AndroidDriver driver, String[] list) {
		System.out.println("Starting the process");
		for (int i = 0; i < list.length; i++) {
			System.out.println(list.length);
			MobileElement we = (MobileElement) driver.findElementByXPath("//UIAPickerWheel["+(i+1)+"]");
			we.sendKeys(list[i]);
		}
		System.out.println("Ending Process");
	}
	
	
	public static void selectDateiOS(AppiumDriver driver, String[] list) {
		System.out.println("Starting the process");
		for (int i = 0; i < list.length; i++) {
			System.out.println(list.length);
			MobileElement we = (MobileElement) driver.findElementByXPath("//UIAPickerWheel["+(i+1)+"]");
			we.sendKeys(list[i]);
		}
		System.out.println("Ending Process");
	}
}
