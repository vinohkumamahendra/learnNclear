package com.CucumberCraft.supportLibraries;

import org.apache.log4j.Logger;
import org.testng.IInvokedMethod;
import org.testng.IInvokedMethodListener;
import org.testng.ITestResult;
import org.testng.internal.BaseTestMethod;

import io.appium.java_client.AppiumDriver;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 * Will be called before every TestNG Method * @author Cognizant
 */
public class WebDriverListener implements IInvokedMethodListener {

	static Logger log = Logger.getLogger(WebDriverListener.class);

	private static Properties properties;

	private List<String> deviceInstallationList = new ArrayList<String>();
	private String deviceNameUdid;

	@Override
	public void beforeInvocation(IInvokedMethod method, ITestResult testResult) {

		SeleniumTestParameters testParameters = new SeleniumTestParameters();

		log.debug("BEGINNING: com.CucumberCraft.supportLibraries.WebDriverListener-beforeInvocation");

		if (method.isTestMethod()) {

			try {
				properties = Settings.getInstance();
				testParameters.setIsDeviceUdid(getIsDevice(method));

				setDefaultTestParameters(method, testParameters);
				DriverManager.setTestParameters(testParameters);

				if (Boolean.valueOf(properties
						.getProperty("InstallApplicationInDevice"))) {

					if (deviceInstallationList.isEmpty()) {
						// First Installation For execution
						log.info("Installing the APP");
						deviceNameUdid = installAppFromCloud(method,
								testParameters);
						deviceInstallationList.add(deviceNameUdid);

					} else {

						if (testParameters.getIsDeviceUdid()) {
							deviceNameUdid = testParameters.getDeviceName();
							checkAndInstallApp(method, testParameters,
									deviceNameUdid);
						} else {
							// To Avoid install in same Model and Manufacturer
							// Name
							deviceNameUdid = PerfectoDriverFactory
									.getPerfectoDeviceUdidForModel(testParameters);
							checkAndInstallApp(method, testParameters,
									deviceNameUdid);
						}

					}
				}

			} catch (Exception ex) {
				log.error(ex.getMessage());
				ex.printStackTrace();
			}

		} else {
			log.warn("Provided method is NOT a TestNG testMethod!!!");
		}
		log.debug("END: org.stng.jbehave.LocalWebDriverListener.beforeInvocation");

	}

	private void checkAndInstallApp(IInvokedMethod method,
			SeleniumTestParameters testParameters, String deviceNameUdid) {
		if (deviceInstallationList.contains(deviceNameUdid)) {

			log.info("App Already Installed for same Device");

		} else {
			log.info("New device, Installing the APP");
			deviceNameUdid = installAppFromCloud(method, testParameters);
			deviceInstallationList.add(deviceNameUdid);
		}
	}

	@Override
	public void afterInvocation(IInvokedMethod method, ITestResult testResult) {
		
		log.debug("BEGINNING: WebDriverListener.afterInvocation");
		/*
		 * change the name of the test method that will appear in the report to
		 * one that will contain very handy when analysing results.
		 */
		if (method.isTestMethod()) {
			try {
				BaseTestMethod bm = (BaseTestMethod) testResult.getMethod();
				Field f = bm.getClass().getSuperclass()
						.getDeclaredField("m_methodName");
				f.setAccessible(true);
				String newTestName = testResult.getTestContext()
						.getCurrentXmlTest().getName()
						+ " - " + bm.getMethodName() + " - ";
				log.info("Renaming test method name from: '"
						+ bm.getMethodName() + "' to: '" + newTestName);
				f.set(bm, newTestName);

			} catch (Exception ex) {
				System.out.println("afterInvocation exception:\n"
						+ ex.getMessage());
				ex.printStackTrace();
			}
		}
		log.debug("END: WebDriverListener.afterInvocation");
	}

	private void setDefaultTestParameters(IInvokedMethod method,
			SeleniumTestParameters testParameters) {
		try {

			properties = Settings.getInstance();

			if (method.getTestMethod().getXmlTest().getLocalParameters()
					.get("ExecutionMode") == null) {
				testParameters
						.setExecutionMode(ExecutionMode.valueOf(properties
								.getProperty("DefaultExecutionMode")));
			} else {
				String executionMode = method.getTestMethod().getXmlTest()
						.getLocalParameters().get("ExecutionMode");
				testParameters.setExecutionMode(ExecutionMode
						.valueOf(executionMode));
			}

			if (method.getTestMethod().getXmlTest().getLocalParameters()
					.get("MobileExecutionPlatform") == null) {
				testParameters.setMobileToolName(MobileToolName
						.valueOf(properties
								.getProperty("DefaultMobileToolName")));
			} else {
				String mobileExecutionPlatform = method.getTestMethod()
						.getXmlTest().getLocalParameters()
						.get("MobileExecutionPlatform");
				testParameters
						.setMobileExecutionPlatform(MobileExecutionPlatform
								.valueOf(mobileExecutionPlatform));
			}

			if (testParameters.getIsDeviceUdid()) {

				testParameters.setDeviceName(method.getTestMethod()
						.getXmlTest().getLocalParameters().get("DeviceName"));

			} else {
				testParameters.setModelName(method.getTestMethod().getXmlTest()
						.getLocalParameters().get("ModelName"));
				testParameters.setManuFacturerName(method.getTestMethod()
						.getXmlTest().getLocalParameters()
						.get("ManufacturerName"));

			}

		} catch (Exception ex) {
			log.error(ex.getMessage());
		}
	}

	@SuppressWarnings("rawtypes")
	private String installAppFromCloud(IInvokedMethod method,
			SeleniumTestParameters testParameters) {

		String UDID = null;
		AppiumDriver driver = null;
		properties = Settings.getInstance();

		try {
			driver = PerfectoDriverFactory
					.getPerfectoAppiumDrivertoInstall(testParameters);

			UDID = driver.getCapabilities().getCapability("deviceName")
					.toString();

			/*
			 * To Check if the APP is Completely Installed in the respective
			 * Device
			 */
			int i = 0;
			boolean flag = false;
			while (!flag) {
				Thread.sleep(10000);
				if (testParameters.getMobileExecutionPlatform().equals(
						MobileExecutionPlatform.ANDROID)) {
					flag = driver.isAppInstalled(properties
							.getProperty("Application_Package_Name"));
				} else {
					flag = driver.isAppInstalled(properties
							.getProperty("PerfecttoIosBundleID"));
				}

				/* avoid infinite loop */
				i = i + 1;
				if (i >= 10) {
					break;
				}
			}

		} catch (Exception e) {
			log.error("Failed to install the App " + e.getMessage());
		} finally {
			driver.quit();
		}
		return UDID;
	}

	private boolean getIsDevice(IInvokedMethod method) {
		boolean isDeviceorModel = false;
		if (method.getTestMethod().getXmlTest().getLocalParameters()
				.get("DeviceName") == null) {
			isDeviceorModel = false;
		} else if (method.getTestMethod().getXmlTest().getLocalParameters()
				.get("ModelName") == null) {
			isDeviceorModel = true;
		}
		return isDeviceorModel;
	}
}