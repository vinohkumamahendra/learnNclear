package com.CucumberCraft.supportLibraries;

import org.apache.log4j.Logger;

import io.appium.java_client.AppiumDriver;

import java.util.concurrent.TimeUnit;

/**
 * A generic WebDriver manager, which handles multiple instances of WebDriver.
 * 
 * @author Cognizant
 */
public class DriverManager {

	/*
	 * Used for Multithreading of WebDriver Object
	 */
	@SuppressWarnings("rawtypes")
	private static ThreadLocal<AppiumDriver> driver = new ThreadLocal<AppiumDriver>();
	private static ThreadLocal<SeleniumTestParameters> testParameters = new ThreadLocal<SeleniumTestParameters>();
	
	static Logger log;

	static {
		log = Logger.getLogger(DriverManager.class);
	}

	@SuppressWarnings("rawtypes")
	public static AppiumDriver getDriver() {
		
		if (driver.get() == null) {
			// this is need when running tests from IDE
			log.info("Thread has no WedDriver, creating new one");
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			setWebDriver(DriverFactory.createInstance(null));
		}
		log.debug("Getting instance of remote driver" + driver.get().getClass());
		return driver.get();
	}

	@SuppressWarnings("rawtypes")
	public static void setWebDriver(AppiumDriver driver) {
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		DriverManager.driver.set(driver);
	}

	public static void setTestParameters(SeleniumTestParameters testParameters) {
		DriverManager.testParameters.set(testParameters);

	}

	public static SeleniumTestParameters getTestParameters() {
		return testParameters.get();
	}
}